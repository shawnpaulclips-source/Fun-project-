-- ReplicatedStorage.client.controllers.CurrencyDropController
-- class: ModuleScript
-- hash: 48b44ffd53499f50cd2fc63d279b367525c925dcdf74960abaa303805804a597d2263b9c46a68c095e48b6211d9c05b8

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local barrier_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("barrier_tag"));
local CurrencyConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("economy"):FindFirstChild("CurrencyConfig"));
local CurrencyDropConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("economy"):FindFirstChild("CurrencyDropConfig"));
local dummy_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("dummy_tag"));
local Styles = require(script.Parent.Parent:FindFirstChild("ui"):FindFirstChild("Styles"));
local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("game"):FindFirstChild("types"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local LocalPlayer = Players.LocalPlayer;
local max_fall_speed = CurrencyDropConfig.max_fall_speed;
local home_activation_radius = CurrencyDropConfig.home_activation_radius;
local home_base_speed = CurrencyDropConfig.home_base_speed;
local home_accel = CurrencyDropConfig.home_accel;
local home_max_speed = CurrencyDropConfig.home_max_speed;

local function get_drops_folder() -- Line: 99
    local CurrencyDrops = workspace:FindFirstChild("CurrencyDrops");

    if CurrencyDrops then
        return CurrencyDrops;
    end;

    local Folder = Instance.new("Folder");
    Folder.Name = "CurrencyDrops";
    Folder.Parent = workspace;

    return Folder;
end;

return {
    SoundsController = loader.use(require(script.Parent:FindFirstChild("SoundsController"))),
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),

    init = function(p1) -- Line: 114, Name: init
        -- upvalues: signal (copy)
        p1.active_drops = {};
        p1.parts_buffer = {};
        p1.cframes_buffer = {};
        p1.elapsed = 0;
        p1.void_y = -500;
        p1.ignore_dirty = true;
        p1.heartbeat_connection = nil;
        p1.spawn_disconnect = nil;
        p1.collected = signal();
        p1.collect_flush = {};
        p1.collect_flush_pos = nil;
        p1.raycast_params = RaycastParams.new();
        p1.raycast_params.FilterType = Enum.RaycastFilterType.Exclude;
        p1.raycast_params.IgnoreWater = true;
        p1.raycast_params.RespectCanCollide = true;
    end,

    start = function(u2) -- Line: 136, Name: start
        -- upvalues: zap (copy)
        u2.void_y = workspace.FallenPartsDestroyHeight;
        print("[CurrencyDropController] FallenPartsDestroyHeight =", u2.void_y);
        u2.spawn_disconnect = zap.currency_drop_spawn.set_callback(function(p3: number, p4: string, p5: vector, p6: number) -- Line: 143
            -- upvalues: u2 (copy)
            u2:spawn_drop(p3, p4, p5, p6);
        end);
        u2:watch_ignore_sources();
        u2.GameStateController.life_state_changed:connect(function(p7) -- Line: 152
            -- upvalues: u2 (copy)
            if p7 == "Lobby" then
                u2:clear_all();
            end;
        end);
    end,

    spawn_drop = function(p8: any, p9: number, p10: string, p11: vector, p12: number) -- Line: 166, Name: spawn_drop
        -- upvalues: CurrencyConfig (copy), Styles (copy)
        local v13 = CurrencyConfig[p10];

        if v13 == nil then
            return;
        end;

        local Part = Instance.new("Part");
        Part.Name = "CurrencyDrop";
        Part.Size = Vector3.new(1, 1, 1);
        Part.Anchored = true;
        Part.CanCollide = false;
        Part.CanQuery = false;
        Part.CanTouch = false;
        Part.Transparency = 1;
        Part.CFrame = CFrame.new(p11);
        local BillboardGui = Instance.new("BillboardGui");
        BillboardGui.Name = "CurrencyDropGui";
        BillboardGui.Adornee = Part;
        BillboardGui.Size = UDim2.fromScale(3.5, 3.5);
        BillboardGui.AlwaysOnTop = false;
        BillboardGui.Brightness = 1.3;
        BillboardGui.LightInfluence = 0;
        BillboardGui.MaxDistance = 250;
        BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Global;
        BillboardGui.Parent = Part;
        local ImageLabel = Instance.new("ImageLabel");
        ImageLabel.Name = "Sunray";
        ImageLabel.BackgroundTransparency = 1;
        ImageLabel.Image = "rbxassetid://77832124691004";
        ImageLabel.ImageTransparency = 0.35;
        ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5);
        ImageLabel.Position = UDim2.fromScale(0.5, 0.5);
        ImageLabel.Size = UDim2.fromScale(1, 1);
        ImageLabel.ZIndex = 1;
        ImageLabel.Parent = BillboardGui;
        local ImageLabel2 = Instance.new("ImageLabel");
        ImageLabel2.Name = "Icon";
        ImageLabel2.BackgroundTransparency = 1;
        ImageLabel2.Image = v13.drop_icon or v13.icon;
        ImageLabel2.ScaleType = Enum.ScaleType.Fit;
        ImageLabel2.AnchorPoint = Vector2.new(0.5, 0.5);
        ImageLabel2.Position = UDim2.fromScale(0.5, 0.5);
        ImageLabel2.Size = UDim2.fromScale(0.7, 0.7);
        ImageLabel2.ZIndex = 3;
        ImageLabel2.Parent = BillboardGui;
        local ImageLabel3 = Instance.new("ImageLabel");
        ImageLabel3.Name = "IconShadow";
        ImageLabel3.BackgroundTransparency = 1;
        ImageLabel3.Image = v13.drop_icon or v13.icon;
        ImageLabel3.ImageColor3 = Color3.new();
        ImageLabel3.ScaleType = Enum.ScaleType.Fit;
        ImageLabel3.AnchorPoint = Vector2.new(0.5, 0.5);
        ImageLabel3.Position = UDim2.fromScale(0.5, 0.55);
        ImageLabel3.Size = UDim2.fromScale(1, 1);
        ImageLabel3.ZIndex = 2;
        ImageLabel3.Parent = ImageLabel2;
        local v14 = "x" .. p12;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Amount";
        TextLabel.AnchorPoint = Vector2.new(1, 1);
        TextLabel.AutoLocalize = false;
        TextLabel.BackgroundTransparency = 1;
        TextLabel.FontFace = Styles.fonts.blackItalic;
        TextLabel.Position = UDim2.fromScale(0.85, 0.8);
        TextLabel.RichText = true;
        TextLabel.Size = UDim2.fromScale(0.34, 0.26);
        TextLabel.Text = v14;
        TextLabel.TextColor3 = Color3.new(1, 1, 1);
        TextLabel.TextScaled = true;
        TextLabel.ZIndex = 4;
        TextLabel.Parent = BillboardGui;
        local UIGradient = Instance.new("UIGradient");
        UIGradient.Color = Styles.gradients.whiteShine;
        UIGradient.Rotation = -90;
        UIGradient.Parent = TextLabel;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize;
        UIStroke.Thickness = 0.1;
        UIStroke.Parent = TextLabel;
        local TextLabel2 = Instance.new("TextLabel");
        TextLabel2.Name = "AmountShadow";
        TextLabel2.AnchorPoint = Vector2.new(0.5, 0.5);
        TextLabel2.AutoLocalize = false;
        TextLabel2.BackgroundTransparency = 1;
        TextLabel2.FontFace = Styles.fonts.blackItalic;
        TextLabel2.Position = UDim2.fromScale(0.5, 0.55);
        TextLabel2.RichText = true;
        TextLabel2.Size = UDim2.fromScale(1, 1);
        TextLabel2.Text = v14;
        TextLabel2.TextColor3 = Color3.new(1, 1, 1);
        TextLabel2.TextScaled = true;
        TextLabel2.ZIndex = 3;
        TextLabel2.Parent = TextLabel;
        local UIGradient2 = Instance.new("UIGradient");
        UIGradient2.Color = Styles.gradients.whiteShine;
        UIGradient2.Rotation = -90;
        UIGradient2.Parent = TextLabel2;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize;
        UIStroke2.Thickness = 0.1;
        UIStroke2.Parent = TextLabel2;
        local CurrencyDrops = workspace:FindFirstChild("CurrencyDrops");

        if not CurrencyDrops then
            CurrencyDrops = Instance.new("Folder");
            CurrencyDrops.Name = "CurrencyDrops";
            CurrencyDrops.Parent = workspace;
        end;

        Part.Parent = CurrencyDrops;
        p8.active_drops[Part] = {
            velocity = 0,
            state = "falling",
            currency = p10,
            drop_id = p9,
            amount = p12,
            spawn_clock = os.clock(),
            sunray = ImageLabel,
            billboard = BillboardGui
        };
        p8:ensure_loop();
    end,

    ensure_loop = function(u15) -- Line: 306, Name: ensure_loop
        -- upvalues: RunService (copy)
        if u15.heartbeat_connection then
            return;
        end;

        u15.heartbeat_connection = RunService.Heartbeat:Connect(function(p16: number) -- Line: 310
            -- upvalues: u15 (copy)
            u15:step(p16);
        end);
    end,

    step = function(p17: any, p18: number) -- Line: 319, Name: step
        -- upvalues: LocalPlayer (copy), max_fall_speed (copy), home_activation_radius (copy), home_base_speed (copy), home_accel (copy), home_max_speed (copy)
        p17.elapsed = p17.elapsed + p18;

        if next(p17.active_drops) == nil then
            if p17.heartbeat_connection then
                p17.heartbeat_connection:Disconnect();
                p17.heartbeat_connection = nil;
            end;

            return;
        end;

        debug.profilebegin("currency_drops");

        if p17.ignore_dirty then
            p17:rebuild_ignore();
        end;

        local Character = LocalPlayer.Character;
        local v19;

        if Character then
            v19 = Character:FindFirstChild("HumanoidRootPart");
        else
            v19 = nil;
        end;

        local v20;

        if v19 then
            v20 = v19.Position;
        else
            v20 = nil;
        end;

        local parts_buffer = p17.parts_buffer;
        local cframes_buffer = p17.cframes_buffer;
        table.clear(parts_buffer);
        table.clear(cframes_buffer);
        local os_clock_ret = os.clock();
        local v21 = p17.elapsed * 45 % 360;

        for i, v in p17.active_drops do
            if os_clock_ret - v.spawn_clock > 60 or i.Position.Y < p17.void_y then
                p17:remove_drop(i);
            else
                local v22, v23;
                local v24 = 0;

                while true do
                    if v24 == 0 then
                        v24 = -1;
                        v.sunray.Rotation = v21;

                        if v.state ~= "collecting" and (v20 and (i.Position - v20).Magnitude <= 5) then
                            v.state = "collecting";
                            v.collect_start = os_clock_ret;
                            v.collect_from = i.Position;
                        end;

                        v22 = i.CFrame.Position;
                        v23 = i.CFrame;

                        if v.state == "falling" then
                            v.velocity = math.min(v.velocity + p18 * 140, max_fall_speed);
                            local v25 = v.velocity * p18;
                            local v26 = workspace:Raycast(v22, Vector3.new(0, -(v25 + 2.5), 0), p17.raycast_params);

                            if v26 then
                                local Vector3_new_ret = Vector3.new(v22.X, v26.Position.Y + 2.5, v22.Z);
                                v.rest_pos = Vector3_new_ret;
                                v.land_clock = os_clock_ret;
                                v.state = "landing";
                                v23 = CFrame.new(Vector3_new_ret);
                            else
                                v23 = CFrame.new(v22 - Vector3.new(0, v25, 0));
                            end;

                            v24 = 2;
                            continue;
                        end;

                        if v.state == "landing" then
                            v24 = 1;
                            continue;
                        end;

                        if v.state == "resting" then
                            local v27 = v.rest_pos or v22;

                            if v20 and (v22 - v20).Magnitude <= home_activation_radius then
                                v.state = "homing";
                                v.home_elapsed = 0;
                                v23 = CFrame.new(v27);
                            else
                                local v28 = math.sin(p17.elapsed * 3) * 0.35;
                                v23 = CFrame.new(v27 + Vector3.new(0, v28, 0));
                            end;

                            v24 = 2;
                            continue;
                        end;

                        if v.state == "homing" then
                            if v20 == nil then
                                v23 = i.CFrame;
                            else
                                local v29 = v20 - v22;
                                local Magnitude = v29.Magnitude;

                                if home_activation_radius < Magnitude then
                                    v.state = "resting";
                                    v.home_elapsed = nil;
                                    v.rest_pos = v22;
                                    v23 = i.CFrame;
                                else
                                    v.home_elapsed = (v.home_elapsed or 0) + p18;
                                    local v30 = math.min(home_base_speed + home_accel * v.home_elapsed, home_max_speed) * p18;
                                    local math_min_ret = math.min(v30, Magnitude);

                                    if Magnitude <= math_min_ret then
                                        v.state = "collecting";
                                        v.collect_start = os_clock_ret;
                                        v.collect_from = i.Position;
                                    else
                                        v23 = CFrame.new(v22 + v29.Unit * math_min_ret);
                                    end;
                                end;
                            end;

                            v24 = 2;
                            continue;
                        end;

                        if v.state ~= "collecting" then
                            v24 = 2;
                            continue;
                        end;

                        if v20 == nil then
                            v.state = "resting";
                            v.rest_pos = v.rest_pos or v22;
                            v.billboard.Size = UDim2.fromScale(3.5, 3.5);
                            v24 = 2;
                            continue;
                        end;

                        local v31 = v.collect_from or v22;
                        local math_min_ret = math.min((os_clock_ret - (v.collect_start or os_clock_ret)) / 0.22, 1);
                        local v32 = (1 - math_min_ret * 0.85) * 3.5;
                        v.billboard.Size = UDim2.fromScale(v32, v32);

                        if math_min_ret < 1 then
                            v23 = CFrame.new(v31:Lerp(v20, math_min_ret));
                            v24 = 2;
                            continue;
                        end;

                        p17:collect_drop(i, v);
                        v24 = 3;
                        continue;
                    elseif v24 == 1 then
                        v24 = -1;
                        local v33 = v.rest_pos or v22;
                        local v34 = os_clock_ret - (v.land_clock or os_clock_ret);
                        local v35 = math.exp(-9 * v34) * 1.6 * math.sin(22 * v34);
                        v23 = CFrame.new(v33 + Vector3.new(0, v35, 0));

                        if v34 >= 0.55 then
                            v.state = "resting";
                        end;

                        v24 = 2;
                        continue;
                    elseif v24 == 2 then
                        v24 = -1;
                        table.insert(parts_buffer, i);
                        table.insert(cframes_buffer, v23);
                        v24 = 3;
                        continue;
                    elseif v24 == 3 then
                        v24 = -1;
                        break;
                    else
                        break;
                    end;
                end;
            end;
        end;

        if #parts_buffer > 0 then
            workspace:BulkMoveTo(parts_buffer, cframes_buffer);
        end;

        p17:flush_collect_feedback();
        debug.profileend();
    end,

    collect_drop = function(p36: any, p37: userdata, p38: table) -- Line: 481, Name: collect_drop
        -- upvalues: zap (copy)
        p36.active_drops[p37] = nil;
        zap.currency_drop_collect.fire(p38.drop_id);
        p36.collect_flush[p38.currency] = (p36.collect_flush[p38.currency] or 0) + p38.amount;
        p36.collect_flush_pos = p37.Position;
        p37:Destroy();
    end,

    flush_collect_feedback = function(p39) -- Line: 495, Name: flush_collect_feedback
        if next(p39.collect_flush) == nil then
            return;
        end;

        local collect_flush_pos = p39.collect_flush_pos;

        if collect_flush_pos then
            p39.SoundsController:play_sound({
                sound = "pop",
                position = collect_flush_pos
            });
        end;

        for i, v in p39.collect_flush do
            p39.collected:fire(i, v);
        end;

        table.clear(p39.collect_flush);
        p39.collect_flush_pos = nil;
    end,

    remove_drop = function(p40: any, p41: userdata) -- Line: 510, Name: remove_drop
        p40.active_drops[p41] = nil;
        p41:Destroy();
    end,

    clear_all = function(p42) -- Line: 517, Name: clear_all
        for i in p42.active_drops do
            i:Destroy();
        end;

        table.clear(p42.active_drops);
        table.clear(p42.collect_flush);
        p42.collect_flush_pos = nil;
    end,

    rebuild_ignore = function(p43) -- Line: 533, Name: rebuild_ignore
        -- upvalues: Players (copy), CollectionService (copy), dummy_tag (copy), barrier_tag (copy)
        p43.ignore_dirty = false;
        local v44 = {};

        for _, v in Players:GetPlayers() do
            local Character = v.Character;

            if Character then
                table.insert(v44, Character);
            end;
        end;

        for _, v in CollectionService:GetTagged(dummy_tag) do
            table.insert(v44, v);
        end;

        for _, v in CollectionService:GetTagged(barrier_tag) do
            table.insert(v44, v);
        end;

        local Corpses = workspace:FindFirstChild("Corpses");

        if Corpses then
            table.insert(v44, Corpses);
        end;

        local CurrencyDrops = workspace:FindFirstChild("CurrencyDrops");

        if CurrencyDrops then
            table.insert(v44, CurrencyDrops);
        end;

        p43.raycast_params.FilterDescendantsInstances = v44;
    end,

    watch_ignore_sources = function(u45) -- Line: 564, Name: watch_ignore_sources
        -- upvalues: CollectionService (copy), dummy_tag (copy), barrier_tag (copy), Players (copy)
        local function mark_dirty() -- Line: 565
            -- upvalues: u45 (copy)
            u45.ignore_dirty = true;
        end;

        CollectionService:GetInstanceAddedSignal(dummy_tag):Connect(mark_dirty);
        CollectionService:GetInstanceRemovedSignal(dummy_tag):Connect(mark_dirty);
        CollectionService:GetInstanceAddedSignal(barrier_tag):Connect(mark_dirty);
        CollectionService:GetInstanceRemovedSignal(barrier_tag):Connect(mark_dirty);
        Players.PlayerAdded:Connect(function(p46: userdata) -- Line: 574
            -- upvalues: u45 (copy), mark_dirty (copy)
            u45.ignore_dirty = true;
            p46.CharacterAdded:Connect(mark_dirty);
        end);
        Players.PlayerRemoving:Connect(mark_dirty);

        for _, v in Players:GetPlayers() do
            v.CharacterAdded:Connect(mark_dirty);
        end;
    end
};