-- ReplicatedStorage.client.controllers.CustomKnockbackController
-- class: ModuleScript
-- hash: 8e8671b50d3ab20f1c15b6868f3cc586104320df8eb8c4bfc292828895058351deabba57a7767e6c2c9c078a70a2b7ee

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local launch_gravity_factor = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("launch_gravity_factor"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local LocalPlayer = Players.LocalPlayer;

local function angle_between(p1: vector, p2: vector) -- Line: 30
    local v3 = p2:Dot(p1) / p2.Magnitude / p1.Magnitude;
    local math_clamp_ret = math.clamp(v3, -1, 1);

    return math.acos(math_clamp_ret);
end;

local function is_within_part(p4: userdata, p5: vector, p6: vector) -- Line: 35
    local v7 = p4.CFrame:PointToObjectSpace(p5);
    local v8 = (p4.Size + p6) / 2;
    local v9;

    if math.abs(v7.X) <= v8.X and math.abs(v7.Y) <= v8.Y then
        v9 = math.abs(v7.Z) <= v8.Z;
    else
        v9 = false;
    end;

    return v9;
end;

return {
    MovementController = loader.use(require(script.Parent:FindFirstChild("MovementController"))),
    ViewmodelController = loader.use(require(script.Parent:FindFirstChild("ViewmodelController"))),
    SoundsController = loader.use(require(script.Parent:FindFirstChild("SoundsController"))),

    init = function(p10) -- Line: 54, Name: init
        p10.tracked = {};
        p10.next_math_update = 0;
    end,

    start = function(u11) -- Line: 59, Name: start
        -- upvalues: CollectionService (copy), RunService (copy)
        CollectionService:GetInstanceAddedSignal("CustomKnockbackPart"):Connect(function(p12: userdata) -- Line: 60
            -- upvalues: u11 (copy)
            if p12:IsA("BasePart") then
                u11:add_object(p12);
            end;
        end);
        CollectionService:GetInstanceRemovedSignal("CustomKnockbackPart"):Connect(function(p13: userdata) -- Line: 65
            -- upvalues: u11 (copy)
            if p13:IsA("BasePart") then
                u11:remove_object(p13);
            end;
        end);

        for _, v in CollectionService:GetTagged("CustomKnockbackPart") do
            if v:IsA("BasePart") then
                task.defer(function() -- Line: 73
                    -- upvalues: u11 (copy), v (copy)
                    u11:add_object(v);
                end);
            end;
        end;

        RunService.Heartbeat:Connect(function() -- Line: 79
            -- upvalues: u11 (copy)
            u11:update();
        end);
    end,

    update = function(p14) -- Line: 87, Name: update
        -- upvalues: LocalPlayer (copy)
        if os.clock() < p14.next_math_update then
            return;
        end;

        p14.next_math_update = os.clock() + 0.25;
        local Character = LocalPlayer.Character;
        local v15;

        if Character then
            v15 = Character:FindFirstChild("HumanoidRootPart");
        else
            v15 = nil;
        end;

        if not v15 then
            return;
        end;

        for i, v in p14.tracked do
            if v.math_hitbox_enabled then
                local v16 = i.CFrame:PointToObjectSpace(v15.Position);
                local v17 = (i.Size + Vector3.new(2, 2, 2)) / 2;
                local v18;

                if math.abs(v16.X) <= v17.X and math.abs(v16.Y) <= v17.Y then
                    v18 = math.abs(v16.Z) <= v17.Z;
                else
                    v18 = false;
                end;

                if v18 then
                    task.spawn(v.touched_callback, v15, true);
                end;
            end;
        end;
    end,

    add_object = function(u19: any, u20: userdata) -- Line: 110, Name: add_object
        -- upvalues: LocalPlayer (copy), launch_gravity_factor (copy)
        if u19.tracked[u20] then
            return;
        end;

        local v21 = {};
        local u22 = {};
        local u23 = u19.SoundsController:attach_resident_sound(u20, "jump_pad");

        local function touched_callback(p24: userdata, p25: boolean?) -- Line: 124
            -- upvalues: LocalPlayer (ref), u22 (copy), u20 (copy), u19 (copy), launch_gravity_factor (ref), u23 (copy)
            local v26 = p24.AssemblyRootPart or p24;

            if p24.Parent ~= LocalPlayer.Character then
                return;
            end;

            if os.clock() < (u22[v26] or 0) then
                return;
            end;

            local Character = LocalPlayer.Character;
            local v27;

            if Character then
                v27 = Character:FindFirstChildWhichIsA("Humanoid");
            else
                v27 = nil;
            end;

            if not v27 or v27.Health <= 0 then
                return;
            end;

            local Attribute = u20:GetAttribute("Velocity");
            local Attribute2 = u20:GetAttribute("LocalTo");

            if Attribute2 then
                Attribute = u20.CFrame[Attribute2] * Attribute;
            end;

            local Attribute3 = u20:GetAttribute("MinimumYVelocity");

            if Attribute3 then
                if math.abs(Attribute.Y) >= 0.001 then
                    local math_abs_ret = math.abs(Attribute.Y);
                    Attribute3 = math.max(Attribute3, math_abs_ret) * math.sign(Attribute.Y);
                end;

                Attribute = Vector3.new(Attribute.X, Attribute3, Attribute.Z);
            end;

            local Attribute4 = u20:GetAttribute("HasToBeInFront");
            local v28;

            if typeof(Attribute4) == "CFrame" then
                v28 = Attribute4;
            else
                v28 = CFrame.identity;
            end;

            if p25 == nil or not p25 then
                if Attribute4 == nil then
                    p25 = true;
                else
                    local Unit = (v26.Position - (u20.CFrame * v28).Position).Unit;
                    local Unit2 = Attribute.Unit;
                    local v29 = Unit2:Dot(Unit) / Unit2.Magnitude / Unit.Magnitude;
                    local math_clamp_ret = math.clamp(v29, -1, 1);
                    p25 = math.acos(math_clamp_ret) <= 1.5707963267948966;
                end;
            end;

            if not p25 then
                return;
            end;

            u22[v26] = os.clock() + (u20:GetAttribute("Cooldown") or 0.5);
            local v30 = u20:GetAttribute("SpringSpeed") or 12;
            local v31 = (Vector3.new(0, 1, 0)):Dot(Attribute) / (Vector3.new(0, 1, 0)).Magnitude / Attribute.Magnitude;
            local math_clamp_ret = math.clamp(v31, -1, 1);
            local v32;

            if math.acos(math_clamp_ret) < 0.08726646259971647 then
                v32 = true;
            else
                local v33 = (Vector3.new(0, -1, 0)):Dot(Attribute) / (Vector3.new(0, -1, 0)).Magnitude / Attribute.Magnitude;
                local math_clamp_ret2 = math.clamp(v33, -1, 1);
                v32 = math.acos(math_clamp_ret2) < 0.08726646259971647;
            end;

            local v34;

            if v32 then
                local AssemblyLinearVelocity = v26.AssemblyLinearVelocity;
                v34 = AssemblyLinearVelocity.Unit * math.max((AssemblyLinearVelocity * (Vector3.new(1, 0, 1)).Unit).Magnitude, v27.WalkSpeed);
            else
                v34 = nil;
            end;

            if v34 ~= nil and (v34 ~= v34 or v34.Magnitude <= 0.001) then
                v34 = nil;
            end;

            if u20:GetAttribute("Override") then
                u19.MovementController:cancel_launch();
            end;

            u19.MovementController:launch(Attribute * launch_gravity_factor(), v30, v34);
            local workspace_CurrentCamera = workspace.CurrentCamera;

            if workspace_CurrentCamera then
                local v35 = -workspace_CurrentCamera.CFrame:VectorToObjectSpace(Attribute) * 0.3;

                if v35.Magnitude > 6 then
                    v35 = v35.Unit * 6;
                end;

                u19.ViewmodelController:apply_impulse(v35);
            end;

            u23:Play();
        end;

        table.insert(v21, u20.Touched:Connect(function(p36: userdata) -- Line: 209
            -- upvalues: touched_callback (copy)
            touched_callback(p36);
        end));
        table.insert(v21, u20.TouchEnded:Connect(function(p37: userdata) -- Line: 215
            -- upvalues: touched_callback (copy)
            touched_callback(p37);
        end));
        u19.tracked[u20] = {
            connections = v21,
            cooldowns = u22,
            math_hitbox_enabled = u20:GetAttribute("MathHitboxCheckEnabled"),
            touched_callback = touched_callback,
            launch_sound = u23
        };
    end,

    remove_object = function(p38: any, p39: userdata) -- Line: 229, Name: remove_object
        local v40 = p38.tracked[p39];

        if not v40 then
            return;
        end;

        for _, v in v40.connections do
            v:Disconnect();
        end;

        v40.launch_sound:Destroy();
        p38.tracked[p39] = nil;
    end
};