-- ReplicatedStorage.client.controllers.FriendPromptController
-- class: ModuleScript
-- hash: b97f1e343f6cf65ac77bb0e36e5e86f98407872c04031c98435dfecd259e38f70eeb6531334a77a0327ef6b254305574

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local SocialService = game:GetService("SocialService");
local v1 = {
    NotificationsController = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader")).use(require(script.Parent:FindFirstChild("NotificationsController")))
};

local function canSendGameInvite(u2: userdata, u3: number?) -- Line: 9
    -- upvalues: SocialService (copy)
    local success, result = pcall(function() -- Line: 10
        -- upvalues: SocialService (ref), u2 (copy), u3 (copy)
        return SocialService:CanSendGameInviteAsync(u2, u3);
    end);

    return success and result;
end;

function v1.init(p4) -- Line: 16
end;

function v1.start(p5) -- Line: 18
end;

function v1.prompt_invite(p6) -- Line: 20
    -- upvalues: Players (copy), SocialService (copy)
    local LocalPlayer = Players.LocalPlayer;
    local CurrentPage = Players:GetFriendsAsync(LocalPlayer.UserId):GetCurrentPage();
    local v7 = {};

    for _, v in CurrentPage do
        if v.IsOnline then
            table.insert(v7, v);
        end;
    end;

    if not LocalPlayer:IsDescendantOf(Players) then
        return;
    end;

    local v8;

    if v7[1] then
        v8 = v7[math.random(1, #v7)];
    else
        v8 = CurrentPage[math.random(1, (math.clamp(#CurrentPage, 1, 10)))];
    end;

    if not v8 then
        return;
    end;

    local ExperienceInviteOptions = Instance.new("ExperienceInviteOptions");
    ExperienceInviteOptions.PromptMessage = `Invite {v8.DisplayName} for OP rewards!`;
    ExperienceInviteOptions.InviteUser = v8.Id;
    local Id = v8.Id;
    local success, result = pcall(function() -- Line: 10
        -- upvalues: SocialService (ref), LocalPlayer (copy), Id (copy)
        return SocialService:CanSendGameInviteAsync(LocalPlayer, Id);
    end);

    if success and result then
        SocialService:PromptGameInvite(LocalPlayer, ExperienceInviteOptions);

        return;
    end;

    p6.NotificationsController:notify({
        Text = "Failed to prompt friend invite",
        Duration = 5,
        NotificationType = "Error"
    });
end;

return v1;