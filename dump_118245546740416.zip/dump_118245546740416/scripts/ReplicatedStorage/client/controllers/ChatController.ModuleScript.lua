-- ReplicatedStorage.client.controllers.ChatController
-- class: ModuleScript
-- hash: f2d5e01d821bc8faa5822fbc173efb9bc1d14bfb15471364062ec8666e2798cb8255481e70e5ffae36c0d12aaf70e71b

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TextChatService = game:GetService("TextChatService");
local SkinData = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("weapons"):FindFirstChild("SkinData"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local v1 = {};
local utf8_char_ret = utf8.char(57344);
local utf8_char_ret2 = utf8.char(57345);
local utf8_char_ret3 = utf8.char(57346);
local utf8_char_ret4 = utf8.char(57347);
local u2 = {
    mythic = {
        Color3.fromHex("#ff0000"),
        Color3.fromHex("#ff8800"),
        Color3.fromHex("#00ff00"),
        Color3.fromHex("#0088ff"),
        Color3.fromHex("#aa00ff")
    },
    secret = {
        Color3.fromHex("#ff0000"),
        Color3.fromHex("#000000"),
        Color3.fromHex("#ff0000"),
        Color3.fromHex("#000000")
    },
    limited = {
        Color3.fromHex("#ffffff"),
        Color3.fromHex("#8f8f8f"),
        Color3.fromHex("#ffffff"),
        Color3.fromHex("#8f8f8f")
    },
    default = { Color3.fromHex("#b1b1b1"), Color3.fromHex("#7a7a7a") }
};

local function font_color(p3: string, p4: string) -- Line: 61
    return `<font color="{p4}">{p3}</font>`;
end;

local function bold(p5: string) -- Line: 65
    return `<b>{p5}</b>`;
end;

local function escape_rich_text(p6: string) -- Line: 69
    local string_gsub_ret = string.gsub(p6, "&", "&amp;");
    local string_gsub_ret2 = string.gsub(string_gsub_ret, "<", "&lt;");

    return string.gsub(string_gsub_ret2, ">", "&gt;");
end;

local function color3_to_hex(p7) -- Line: 76
    return string.format("#%02x%02x%02x", math.round(p7.R * 255), math.round(p7.G * 255), (math.round(p7.B * 255)));
end;

local function style_message(p8: string, p9: string) -- Line: 85
    -- upvalues: u2 (copy)
    local v10 = u2[p9] or u2.default;
    local v11 = utf8.len(p8) or #p8;
    local v12 = 0;
    local v13 = {};

    for _, v in utf8.codes(p8) do
        local v14 = (v11 <= 1 and 0 or v12 / (v11 - 1)) * (#v10 - 1);
        local v15 = math.floor(v14) + 1;
        local math_min_ret = math.min(v15 + 1, #v10);
        local v16 = v14 - math.floor(v14);
        local v17 = v10[v15]:Lerp(v10[math_min_ret], v16);
        local v18 = `<font color="{string.format("#%02x%02x%02x", math.round(v17.R * 255), math.round(v17.G * 255), (math.round(v17.B * 255)))}">{utf8.char(v)}</font>`;
        table.insert(v13, v18);
        v12 = v12 + 1;
    end;

    return table.concat(v13);
end;

local function capitalize_first(p19: string) -- Line: 109
    if p19 == "" then
        return p19;
    end;

    return string.upper((string.sub(p19, 1, 1))) .. string.sub(p19, 2);
end;

local function build_announcement_message(p20: string, p21: string, p22: string, p23: boolean) -- Line: 116
    -- upvalues: SkinData (copy), Players (copy), style_message (copy)
    local v24 = SkinData.skins[p21];

    if v24 then
        p21 = v24.display_name;
    end;

    local v25;

    if p22 == "" then
        v25 = p22;
    else
        v25 = string.upper((string.sub(p22, 1, 1))) .. string.sub(p22, 2);
    end;

    local v26;

    if p23 then
        v26 = `<b>{"<font color=\"#f0eced\">[Global]</font>"}</b>`;
    else
        v26 = `<b>{"<font color=\"#f0eced\">[Local]</font>"}</b>`;
    end;

    local v27 = `<b>{"<font color=\"#f0eced\"> WOW! </font>"}</b>`;
    local v28;

    if p20 == Players.LocalPlayer.Name then
        v28 = `<b>{"<font color=\"#27ff4b\">YOU </font>"}</b>`;
    else
        v28 = `<b>{`<font color="#ffce39">{`@{p20} `}</font>`}</b>`;
    end;

    return v26 .. v27 .. v28 .. `<b>{"<font color=\"#f0eced\">obtained a </font>"}</b>` .. `<b>{style_message(`{v25} {p21}`, p22)}</b>` .. `<b>{"<font color=\"#f0eced\">!</font>"}</b>`;
end;

local function build_purchase_message(p29: string, p30: string, p31: number, p32: boolean, p33: boolean, p34: boolean) -- Line: 143
    -- upvalues: utf8_char_ret4 (copy), utf8_char_ret2 (copy), utf8_char_ret (copy), utf8_char_ret3 (copy)
    local v35;

    if p34 then
        v35 = utf8_char_ret4;
    elseif p33 then
        v35 = utf8_char_ret2;
    else
        v35 = nil;
    end;

    local v36 = "";

    if v35 then
        v36 = v36 .. `<font color="#ffce39">{v35}</font>`;
    end;

    if p32 then
        v36 = v36 .. `<font color="#0a93ff">{utf8_char_ret}</font>`;
    end;

    if v36 ~= "" then
        v36 = v36 .. " ";
    end;

    local string_gsub_ret = string.gsub(p29, "&", "&amp;");
    local string_gsub_ret2 = string.gsub(string_gsub_ret, "<", "&lt;");
    local string_gsub_ret3 = string.gsub(string_gsub_ret2, ">", "&gt;");
    local string_gsub_ret4 = string.gsub(p30, "&", "&amp;");
    local string_gsub_ret5 = string.gsub(string_gsub_ret4, "<", "&lt;");
    local string_gsub_ret6 = string.gsub(string_gsub_ret5, ">", "&gt;");

    return v36 .. `<b>{`<font color="#ffce39">{`{string_gsub_ret3}`}</font>`}</b>` .. `<b>{"<font color=\"#d7d7d7\"> purchased a </font>"}</b>` .. `<b>{`<font color="#f9f5f5">{`{string_gsub_ret6}`}</font>`}</b>` .. `<b>{"<font color=\"#d7d7d7\"> for </font>"}</b>` .. `<b>{`<font color="#ffce39">{utf8_char_ret3 .. tostring(p31)}</font>`}</b>`;
end;

function v1.init(p37) -- Line: 178
    p37.general_channel = nil;
    p37.channel_lookup_failed = false;
    p37.announcement_queue = {};
    p37.purchase_queue = {};
end;

function v1.start(u38) -- Line: 185
    -- upvalues: TextChatService (copy), zap (copy), build_announcement_message (copy), build_purchase_message (copy)
    task.spawn(function() -- Line: 186
        -- upvalues: TextChatService (ref), u38 (copy)
        local TextChannels = TextChatService:WaitForChild("TextChannels", 15);

        if not TextChannels then
            warn("[ChatController] TextChannels not found");
            u38.channel_lookup_failed = true;
            table.clear(u38.announcement_queue);
            table.clear(u38.purchase_queue);

            return;
        end;

        local RBXGeneral = TextChannels:WaitForChild("RBXGeneral", 15);

        if RBXGeneral then
            u38.general_channel = RBXGeneral;
            u38:flush_queue();

            return;
        end;

        warn("[ChatController] RBXGeneral channel not found");
        u38.channel_lookup_failed = true;
        table.clear(u38.announcement_queue);
        table.clear(u38.purchase_queue);
    end);
    zap.item_announcement.set_callback(function(p39, p40, p41, p42, p43) -- Line: 210
        -- upvalues: u38 (copy), build_announcement_message (ref)
        local general_channel = u38.general_channel;

        if general_channel then
            general_channel:DisplaySystemMessage((build_announcement_message(p39, p41, p42, p43)));

            return;
        end;

        if not u38.channel_lookup_failed then
            table.insert(u38.announcement_queue, {
                username = p39,
                item_name = p41,
                item_rarity = p42,
                is_global = p43
            });
        end;
    end);
    zap.purchase_announcement.set_callback(function(p44, p45, p46, p47, p48, p49) -- Line: 231
        -- upvalues: u38 (copy), build_purchase_message (ref)
        local general_channel = u38.general_channel;

        if general_channel then
            general_channel:DisplaySystemMessage((build_purchase_message(p44, p45, p46, p47, p48, p49)));

            return;
        end;

        if not u38.channel_lookup_failed then
            table.insert(u38.purchase_queue, {
                username = p44,
                product_title = p45,
                price = p46,
                is_verified = p47,
                is_premium = p48,
                is_roblox_plus = p49
            });
        end;
    end);
end;

function v1.flush_queue(p50) -- Line: 263
    -- upvalues: build_announcement_message (copy), build_purchase_message (copy)
    local general_channel = p50.general_channel;

    if not general_channel then
        return;
    end;

    for _, v in p50.announcement_queue do
        general_channel:DisplaySystemMessage((build_announcement_message(v.username, v.item_name, v.item_rarity, v.is_global)));
    end;

    table.clear(p50.announcement_queue);

    for _, v in p50.purchase_queue do
        general_channel:DisplaySystemMessage((build_purchase_message(v.username, v.product_title, v.price, v.is_verified, v.is_premium, v.is_roblox_plus)));
    end;

    table.clear(p50.purchase_queue);
end;

return v1;