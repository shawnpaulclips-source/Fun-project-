-- ReplicatedStorage.client.controllers.CmdrController
-- class: ModuleScript
-- hash: a7e8d1b48bcb125e0a6215e6b0453925e6e5104a719c62c315a2d360577e4520ff1ccbee31d260b994b26b546caefecb

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local u1 = { Enum.KeyCode.F2, Enum.KeyCode.F5 };

return {
    init = function(p2) -- Line: 14, Name: init
        -- upvalues: signal (copy)
        p2.is_eligible = false;
        p2.eligibility_changed = signal();
        p2.cmdr = nil;
    end,

    start = function(u3) -- Line: 20, Name: start
        -- upvalues: ReplicatedStorage (copy), RunService (copy), u1 (copy), Players (copy), UserInputService (copy)
        u3.cmdr = require((ReplicatedStorage:WaitForChild("CmdrClient")));

        if RunService:IsStudio() then
            u3.cmdr:SetActivationKeys(u1);
            u3:set_eligible(true);

            return;
        end;

        u3.cmdr:SetActivationKeys({});
        u3:set_eligible(Players.LocalPlayer:GetAttribute("cmdr_eligible") == true);
        Players.LocalPlayer:GetAttributeChangedSignal("cmdr_eligible"):Connect(function() -- Line: 35
            -- upvalues: u3 (copy), Players (ref)
            u3:set_eligible(Players.LocalPlayer:GetAttribute("cmdr_eligible") == true);
        end);
        UserInputService.InputBegan:Connect(function(p4: userdata, p5: boolean) -- Line: 39
            -- upvalues: u3 (copy)
            if p5 then
                return;
            end;

            if p4.KeyCode == Enum.KeyCode.F2 or p4.KeyCode == Enum.KeyCode.F5 then
                u3:try_toggle();
            end;
        end);
    end,

    resolve_eligibility = function(p6) -- Line: 54, Name: resolve_eligibility
        -- upvalues: Players (copy)
        local v7 = Players.LocalPlayer:GetAttribute("cmdr_eligible") == true;

        if v7 then
            p6:set_eligible(true);
        end;

        return v7;
    end,

    set_eligible = function(p8: any, p9: boolean) -- Line: 62, Name: set_eligible
        if p8.is_eligible == p9 then
            return;
        end;

        p8.is_eligible = p9;
        p8.eligibility_changed:fire(p9);
    end,

    toggle = function(p10) -- Line: 74, Name: toggle
        if p10.is_eligible and p10.cmdr then
            p10.cmdr:Toggle();
        end;
    end,

    try_toggle = function(p11) -- Line: 80, Name: try_toggle
        if p11:resolve_eligibility() then
            p11.cmdr:Toggle();
        end;
    end
};