-- ReplicatedStorage.client.controllers.BountyController
-- class: ModuleScript
-- hash: d6de072a2739415e8a14f089d8545b6e13a895d939935ab9c1aa85129255bf8d7e7efdf63a6face72aec72f9329bc1af

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local Players = game:GetService("Players");
local BountyConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("BountyConfig"));
local react_roblox = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("react_roblox"));
local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local dummy_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("dummy_tag"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local participant_id = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("participant_id"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

local function read_tier(p1: userdata) -- Line: 47
    -- upvalues: BountyConfig (copy)
    local Attribute = p1:GetAttribute(BountyConfig.BOUNTY_TIER_ATTR);

    return typeof(Attribute) ~= "number" and 0 or Attribute;
end;

return {
    SoundsController = loader.use(require(script.Parent:FindFirstChild("SoundsController"))),

    init = function(p2) -- Line: 60, Name: init
        -- upvalues: signal (copy)
        p2.rivals = {};
        p2.bounty_bodies = {};
        p2.bot_models = {};
        p2.bot_pids = {};
        p2.body_connections = {};
        p2.kill_bonus = signal();
        p2.bounty_lost = signal();
        p2.rival_event = signal();
        p2.bounty_broadcast = signal();
        p2.rivals_changed = signal();
        p2.callout = signal();
        p2.callout_shown = signal();
        p2.marks_changed = signal();
    end,

    start = function(u3) -- Line: 87, Name: start
        -- upvalues: zap (copy), react_roblox (copy), Players (copy), CollectionService (copy), dummy_tag (copy)
        zap.kill_bonus.set_callback(function(u4: table) -- Line: 88
            -- upvalues: react_roblox (ref), u3 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 89
                -- upvalues: u3 (ref), u4 (copy)
                u3:on_kill_bonus(u4);
            end);
        end);
        zap.bounty_lost.set_callback(function(u5: table) -- Line: 94
            -- upvalues: react_roblox (ref), u3 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 95
                -- upvalues: u3 (ref), u5 (copy)
                u3.callout:fire("bounty_lost", `{u5.claimer_name} claimed`, u5.coins, u5.claimer_avatar_user_id);
                u3.bounty_lost:fire(u5);
            end);
        end);
        zap.rival_state.set_callback(function(u6: table) -- Line: 106
            -- upvalues: react_roblox (ref), u3 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 107
                -- upvalues: u6 (copy), u3 (ref)
                local v7 = {};

                for _, v in u6.rivals do
                    v7[v] = true;
                end;

                u3.rivals = v7;
                u3.rivals_changed:fire(v7);
                u3.marks_changed:fire();
            end);
        end);
        zap.rival_event.set_callback(function(u8: table) -- Line: 118
            -- upvalues: react_roblox (ref), u3 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 119
                -- upvalues: u8 (copy), u3 (ref)
                if u8.kind == "NewRival" then
                    u3.callout:fire("rival_new", u8.other_name, nil, u8.other_avatar_user_id);
                else
                    u3.callout:fire("rival_became", `{u8.other_name} is hunting you`, nil, u8.other_avatar_user_id);
                end;

                u3.rival_event:fire(u8);
            end);
        end);
        zap.bounty_broadcast.set_callback(function(u9: table) -- Line: 134
            -- upvalues: react_roblox (ref), u3 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 135
                -- upvalues: u3 (ref), u9 (copy)
                u3.SoundsController:play_sound({
                    sound = "bounty_broadcast"
                });
                u3.bounty_broadcast:fire(u9);
            end);
        end);

        local function watch_player(p10: userdata) -- Line: 141
            -- upvalues: u3 (copy)
            if p10.Character then
                u3:track_body(p10.Character);
            end;

            p10.CharacterAdded:Connect(function(p11: userdata) -- Line: 145
                -- upvalues: u3 (ref)
                u3:track_body(p11);
            end);
            p10.CharacterRemoving:Connect(function(p12: userdata) -- Line: 148
                -- upvalues: u3 (ref)
                u3:untrack_body(p12);
            end);
        end;

        for _, v in Players:GetPlayers() do
            watch_player(v);
        end;

        Players.PlayerAdded:Connect(watch_player);

        for _, v in CollectionService:GetTagged(dummy_tag) do
            if v:IsA("Model") then
                u3:track_body(v);
            end;
        end;

        CollectionService:GetInstanceAddedSignal(dummy_tag):Connect(function(p13: userdata) -- Line: 162
            -- upvalues: u3 (copy)
            if p13:IsA("Model") then
                u3:track_body(p13);
            end;
        end);
        CollectionService:GetInstanceRemovedSignal(dummy_tag):Connect(function(p14: userdata) -- Line: 167
            -- upvalues: u3 (copy)
            if p14:IsA("Model") then
                u3:untrack_body(p14);
            end;
        end);
    end,

    on_kill_bonus = function(p15: any, p16: table) -- Line: 176, Name: on_kill_bonus
        p15.kill_bonus:fire(p16);

        if p16.bounty_tier > 0 then
            local v17;

            if p16.bounty_coins > 0 then
                v17 = p16.bounty_coins;
            else
                v17 = nil;
            end;

            p15.callout:fire("bounty_claimed", p16.victim_name, v17, p16.victim_avatar_user_id);
        end;

        if p16.revenge then
            local v18;

            if p16.rival_coins > 0 then
                v18 = p16.rival_coins;
            else
                v18 = nil;
            end;

            p15.callout:fire("revenge", p16.victim_name, v18, p16.victim_avatar_user_id);
        end;
    end,

    track_body = function(u19: any, u20: userdata) -- Line: 201, Name: track_body
        -- upvalues: BountyConfig (copy), react_roblox (copy), CollectionService (copy), dummy_tag (copy)
        if u19.body_connections[u20] then
            return;
        end;

        local v21 = { u20:GetAttributeChangedSignal(BountyConfig.BOUNTY_TIER_ATTR):Connect(function() -- Line: 206
                -- upvalues: react_roblox (ref), u19 (copy), u20 (copy)
                react_roblox.unstable_batchedUpdates(function() -- Line: 207
                    -- upvalues: u19 (ref), u20 (ref)
                    u19:refresh_bounty(u20);
                end);
            end) };

        if CollectionService:HasTag(u20, dummy_tag) then
            local AttributeChangedSignal = u20:GetAttributeChangedSignal(BountyConfig.PARTICIPANT_ATTR);
            table.insert(v21, AttributeChangedSignal:Connect(function() -- Line: 215
                -- upvalues: react_roblox (ref), u19 (copy), u20 (copy)
                react_roblox.unstable_batchedUpdates(function() -- Line: 216
                    -- upvalues: u19 (ref), u20 (ref)
                    u19:refresh_bot_pid(u20);
                end);
            end));
            u19:refresh_bot_pid(u20);
        end;

        u19.body_connections[u20] = v21;
        u19:refresh_bounty(u20);
        u19.marks_changed:fire();
    end,

    untrack_body = function(p22: any, p23: userdata) -- Line: 229, Name: untrack_body
        local v24 = p22.body_connections[p23];

        if not v24 then
            return;
        end;

        for _, v in v24 do
            v:Disconnect();
        end;

        p22.body_connections[p23] = nil;
        p22.bounty_bodies[p23] = nil;
        local v25 = p22.bot_pids[p23];

        if v25 then
            p22.bot_pids[p23] = nil;

            if p22.bot_models[v25] == p23 then
                p22.bot_models[v25] = nil;
            end;
        end;

        p22.marks_changed:fire();
    end,

    refresh_bot_pid = function(p26: any, p27: userdata) -- Line: 250, Name: refresh_bot_pid
        -- upvalues: BountyConfig (copy)
        local v28 = p26.bot_pids[p27];

        if v28 and p26.bot_models[v28] == p27 then
            p26.bot_models[v28] = nil;
        end;

        local Attribute = p27:GetAttribute(BountyConfig.PARTICIPANT_ATTR);

        if typeof(Attribute) == "string" and Attribute ~= "" then
            p26.bot_pids[p27] = Attribute;
            p26.bot_models[Attribute] = p27;
        else
            p26.bot_pids[p27] = nil;
        end;

        p26.marks_changed:fire();
    end,

    refresh_bounty = function(p29: any, p30: userdata) -- Line: 267, Name: refresh_bounty
        -- upvalues: BountyConfig (copy)
        local Attribute = p30:GetAttribute(BountyConfig.BOUNTY_TIER_ATTR);
        local v31 = typeof(Attribute) ~= "number" and 0 or Attribute;

        if v31 == (p29.bounty_bodies[p30] or 0) then
            return;
        end;

        if v31 > 0 then
            p29.bounty_bodies[p30] = v31;
        else
            p29.bounty_bodies[p30] = nil;
        end;

        p29.marks_changed:fire();
    end,

    resolve_character = function(p32: any, p33: string) -- Line: 283, Name: resolve_character
        -- upvalues: participant_id (copy), Players (copy)
        local v34 = participant_id.user_id_of(p33);

        if not v34 then
            return p32.bot_models[p33];
        end;

        local PlayerByUserId = Players:GetPlayerByUserId(v34);

        if PlayerByUserId then
            return PlayerByUserId.Character;
        end;

        return nil;
    end,

    is_rival = function(p35: any, p36: userdata) -- Line: 293, Name: is_rival
        -- upvalues: Players (copy), participant_id (copy)
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(p36);
        local v37;

        if PlayerFromCharacter then
            v37 = participant_id.of_player(PlayerFromCharacter);
        else
            v37 = p35.bot_pids[p36];
        end;

        local v38;

        if v37 == nil then
            v38 = false;
        else
            v38 = p35.rivals[v37] == true;
        end;

        return v38;
    end
};