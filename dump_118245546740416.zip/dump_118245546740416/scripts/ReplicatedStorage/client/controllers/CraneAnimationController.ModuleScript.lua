-- ReplicatedStorage.client.controllers.CraneAnimationController
-- class: ModuleScript
-- hash: bf166bd67f69423f716e75febc7c2edbd6e5ad2c0428fc1c3ecb5a8a195c28106f954dfda74517dbfb31e189d4bddb0f

-- Decompiled with Potassium's decompiler.

game:GetService("CollectionService");
local Players = game:GetService("Players");
game:GetService("RunService");
local v2 = {
    init = function(p1) -- Line: 15, Name: init
        -- upvalues: Players (copy)
        p1.SPEED = 0.1;
        p1.Cranes = {};
        p1.lastAngle = nil;
        p1.player = Players.LocalPlayer;
    end
};

local function spin(p3: vector, p4: number) -- Line: 23
    return CFrame.new(p3) * CFrame.Angles(0, p4, 0) * CFrame.new(-p3);
end;

function v2.start(p5) -- Line: 27
end;

return v2;