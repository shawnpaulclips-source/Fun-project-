-- ReplicatedStorage.client.controllers.DeviceController
-- class: ModuleScript
-- hash: 5fcf2e15fde1ed7bbf5089681d8e32938b812847f6283b6231c2940fffd9a84e2cc0efdb312843d2d2b24b599f7eafb7

-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local NametagConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("nametag"):FindFirstChild("NametagConfig"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 13, Name: init
        p1.last_reported = nil;
    end,

    start = function(u2) -- Line: 17, Name: start
        -- upvalues: NametagConfig (copy), UserInputService (copy), zap (copy)
        local v3 = NametagConfig.category_from_input(UserInputService:GetLastInputType());

        if v3 then
            u2.last_reported = v3;
            zap.report_device.fire({
                category = v3
            });
        end;

        UserInputService.LastInputTypeChanged:Connect(function(p4) -- Line: 24
            -- upvalues: NametagConfig (ref), u2 (copy), zap (ref)
            local v5 = NametagConfig.category_from_input(p4);

            if v5 and v5 ~= u2.last_reported then
                u2.last_reported = v5;
                zap.report_device.fire({
                    category = v5
                });
            end;
        end);
    end
};