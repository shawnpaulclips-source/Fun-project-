-- ReplicatedStorage.client.controllers.DataController
-- class: ModuleScript
-- hash: 6899d0a7c2860876e83873e9e1f8e7eceb8eb0dc4467978c45354513576ebf0176a43901baeacff94f4c5fd1c12e06ce

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local react_roblox = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("react_roblox"));
local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local default_data = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("default_data"));
local deltacompress = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("deltacompress"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 10, Name: init
        -- upvalues: default_data (copy), signal (copy)
        p1.session_start_time = workspace:GetServerTimeNow();
        p1.is_data_loaded = false;
        p1.data = default_data.template;
        p1.data_loaded = signal();
        p1.data_changed = signal();
        p1.are_stats_loaded = false;
        p1.stats = default_data.template.stats;
        p1.stats_loaded = signal();
        p1.stats_changed = signal();
    end,

    start = function(u2) -- Line: 23, Name: start
        -- upvalues: zap (copy), react_roblox (copy)
        zap.replicate_stats.set_callback(function(p3) -- Line: 24
            -- upvalues: u2 (copy), react_roblox (ref)
            if u2.are_stats_loaded then
                u2:apply_stats_packet(p3);
            else
                u2:apply_full_stats_packet(p3);
                u2.are_stats_loaded = true;
                u2.stats_loaded:fire(u2.stats);
            end;

            react_roblox.unstable_batchedUpdates(function() -- Line: 34
                -- upvalues: u2 (ref)
                u2.stats_changed:fire(u2.stats);
            end);
        end);
        u2:apply_full_packet((zap.get_full_data.call()));
        u2.data_loaded:fire(u2.data);
        u2.is_data_loaded = true;
        u2.data_changed:fire(u2.data);
        zap.complete_onboarding_step.fire("load_data");
        zap.replicate_data.set_callback(function(p4) -- Line: 46
            -- upvalues: u2 (copy), react_roblox (ref)
            u2:apply_packet(p4);
            react_roblox.unstable_batchedUpdates(function() -- Line: 48
                -- upvalues: u2 (ref)
                u2.data_changed:fire(u2.data);
            end);
        end);
    end,

    apply_packet = function(p5: any, p6: buffer) -- Line: 54, Name: apply_packet
        -- upvalues: deltacompress (copy)
        p5.data = deltacompress.applyImmutable(p5.data, p6);
    end,

    apply_full_packet = function(p7: any, p8: buffer) -- Line: 58, Name: apply_full_packet
        -- upvalues: deltacompress (copy), Players (copy)
        p7.data = deltacompress.applyImmutable(nil, p8);
        Players.LocalPlayer:SetAttribute("Loaded", true);
    end,

    apply_stats_packet = function(p9: any, p10: buffer) -- Line: 63, Name: apply_stats_packet
        -- upvalues: deltacompress (copy)
        p9.stats = deltacompress.applyImmutable(p9.stats, p10);
    end,

    apply_full_stats_packet = function(p11: any, p12: buffer) -- Line: 67, Name: apply_full_stats_packet
        -- upvalues: deltacompress (copy)
        p11.stats = deltacompress.applyImmutable(nil, p12);
    end
};