-- ReplicatedStorage.client.controllers.EnemyHighlightController
-- class: ModuleScript
-- hash: 2cfd8290b5ae13fa5090962991f36315bfb95c7755acaf37468c00eaf43c9f868d5cdd1e9db8514634e62d123d2ed08e

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local EnemyHighlightConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("EnemyHighlightConfig"));
local dummy_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("dummy_tag"));
local LocalPlayer = Players.LocalPlayer;

local function is_character_alive(p1: userdata) -- Line: 21
    local v2 = p1:FindFirstChildWhichIsA("Humanoid");

    return not v2 and true or v2.Health > 0;
end;

local function get_root_position(p3: userdata) -- Line: 29
    local HumanoidRootPart = p3:FindFirstChild("HumanoidRootPart");

    if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
        return HumanoidRootPart.Position;
    end;

    return nil;
end;

local function gather_eligible_enemies(p4: vector) -- Line: 37
    -- upvalues: Players (copy), LocalPlayer (copy), EnemyHighlightConfig (copy), CollectionService (copy), dummy_tag (copy)
    local v5 = {};

    for _, v in Players:GetPlayers() do
        if v ~= LocalPlayer then
            local Character = v.Character;

            if Character then
                local v6 = Character:FindFirstChildWhichIsA("Humanoid");

                if (not v6 and true or v6.Health > 0) and Character:GetAttribute("InRound") == true then
                    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
                    local v7;

                    if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
                        v7 = HumanoidRootPart.Position;
                    else
                        v7 = nil;
                    end;

                    if v7 then
                        local Magnitude = (v7 - p4).Magnitude;

                        if EnemyHighlightConfig.max_distance >= Magnitude then
                            table.insert(v5, {
                                character = Character,
                                distance = Magnitude
                            });
                        end;
                    end;
                end;
            end;
        end;
    end;

    for _, v in CollectionService:GetTagged(dummy_tag) do
        if v:IsA("Model") then
            local v8 = v:FindFirstChildWhichIsA("Humanoid");

            if not v8 and true or v8.Health > 0 then
                local HumanoidRootPart = v:FindFirstChild("HumanoidRootPart");
                local v9;

                if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
                    v9 = HumanoidRootPart.Position;
                else
                    v9 = nil;
                end;

                if v9 then
                    local Magnitude = (v9 - p4).Magnitude;

                    if EnemyHighlightConfig.max_distance >= Magnitude then
                        table.insert(v5, {
                            character = v,
                            distance = Magnitude
                        });
                    end;
                end;
            end;
        end;
    end;

    table.sort(v5, function(p10, p11) -- Line: 83
        return p10.distance < p11.distance;
    end);
    local v12 = {};

    for i = 1, math.min(#v5, EnemyHighlightConfig.max_active_highlights) do
        table.insert(v12, v5[i].character);
        local _ = i;
    end;

    return v12;
end;

return {
    init = function(p13) -- Line: 97, Name: init
        -- upvalues: EnemyHighlightConfig (copy)
        p13.highlights = {};
        p13.death_connections = {};
        p13.accumulator = 0;
        p13.enabled = EnemyHighlightConfig.enabled;
    end,

    start = function(u14) -- Line: 104, Name: start
        -- upvalues: RunService (copy), EnemyHighlightConfig (copy), Players (copy)
        RunService.Heartbeat:Connect(function(p15: number) -- Line: 105
            -- upvalues: u14 (copy), EnemyHighlightConfig (ref)
            local v16 = u14;
            v16.accumulator = v16.accumulator + p15;

            if u14.accumulator >= EnemyHighlightConfig.update_interval then
                u14.accumulator = 0;
                u14:update_highlights();
            end;
        end);
        Players.PlayerRemoving:Connect(function(p17: userdata) -- Line: 113
            -- upvalues: u14 (copy)
            u14:release_player_highlight(p17);
        end);
    end,

    update_highlights = function(p18) -- Line: 122, Name: update_highlights
        -- upvalues: LocalPlayer (copy), gather_eligible_enemies (copy)
        if not p18.enabled then
            p18:release_all();

            return;
        end;

        local Character = LocalPlayer.Character;

        if Character then
            local v19 = Character:FindFirstChildWhichIsA("Humanoid");

            if not v19 and true or v19.Health > 0 then
                local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
                local v20;

                if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
                    v20 = HumanoidRootPart.Position;
                else
                    v20 = nil;
                end;

                if not v20 then
                    p18:release_all();

                    return;
                end;

                local v21 = gather_eligible_enemies(v20);
                local v22 = {};

                for _, v in v21 do
                    v22[v] = true;
                end;

                local v23 = {};

                for i in p18.highlights do
                    if not (v22[i] and i:IsDescendantOf(workspace)) then
                        table.insert(v23, i);
                    end;
                end;

                for _, v in v23 do
                    p18:release_highlight(v);
                end;

                for _, v in v21 do
                    if not p18.highlights[v] then
                        p18:apply_highlight(v);
                    end;
                end;

                return;
            end;
        end;

        p18:release_all();
    end,

    apply_highlight = function(u24: any, u25: userdata) -- Line: 164, Name: apply_highlight
        -- upvalues: EnemyHighlightConfig (copy)
        local Highlight = Instance.new("Highlight");
        Highlight.DepthMode = Enum.HighlightDepthMode.Occluded;
        Highlight.FillColor = EnemyHighlightConfig.fill_color;
        Highlight.FillTransparency = EnemyHighlightConfig.fill_transparency;
        Highlight.OutlineColor = EnemyHighlightConfig.outline_color;
        Highlight.OutlineTransparency = EnemyHighlightConfig.outline_transparency;
        Highlight.Adornee = u25;
        Highlight.Parent = u25;
        u24.highlights[u25] = Highlight;
        local v26 = u25:FindFirstChildWhichIsA("Humanoid");

        if v26 then
            u24.death_connections[u25] = v26.Died:Connect(function() -- Line: 177
                -- upvalues: u24 (copy), u25 (copy)
                u24:release_highlight(u25);
            end);
        end;
    end,

    release_highlight = function(p27: any, p28: userdata) -- Line: 183, Name: release_highlight
        local v29 = p27.highlights[p28];

        if v29 then
            v29:Destroy();
            p27.highlights[p28] = nil;
        end;

        local v30 = p27.death_connections[p28];

        if v30 then
            v30:Disconnect();
            p27.death_connections[p28] = nil;
        end;
    end,

    release_player_highlight = function(p31: any, p32: userdata) -- Line: 196, Name: release_player_highlight
        local Character = p32.Character;

        if Character then
            p31:release_highlight(Character);
        end;
    end,

    release_all = function(p33) -- Line: 203, Name: release_all
        for _, v in p33.highlights do
            v:Destroy();
        end;

        table.clear(p33.highlights);

        for _, v in p33.death_connections do
            v:Disconnect();
        end;

        table.clear(p33.death_connections);
    end,

    set_enabled = function(p34: any, p35: boolean) -- Line: 216, Name: set_enabled
        p34.enabled = p35;

        if not p35 then
            p34:release_all();
        end;
    end
};