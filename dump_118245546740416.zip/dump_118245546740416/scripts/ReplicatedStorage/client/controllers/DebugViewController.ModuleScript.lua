-- ReplicatedStorage.client.controllers.DebugViewController
-- class: ModuleScript
-- hash: 222bd951e2b3915538453a2fc4ac59623364585b87773123907b0904b0cf5e01bce357ef356a835df4948219b445c6ef

-- Decompiled with Potassium's decompiler.

local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 9, Name: init
        -- upvalues: signal (copy)
        p1.third_person = false;
        p1.third_person_changed = signal();
    end,

    start = function(u2) -- Line: 14, Name: start
        -- upvalues: zap (copy)
        zap.set_debug_third_person.set_callback(function(p3: boolean) -- Line: 15
            -- upvalues: u2 (copy)
            u2:set_third_person(p3);
        end);
    end,

    set_third_person = function(p4: any, p5: boolean) -- Line: 22, Name: set_third_person
        if p5 == p4.third_person then
            return;
        end;

        p4.third_person = p5;
        p4.third_person_changed:fire(p5);
    end
};