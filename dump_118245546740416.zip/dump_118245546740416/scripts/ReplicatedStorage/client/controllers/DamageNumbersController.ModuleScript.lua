-- ReplicatedStorage.client.controllers.DamageNumbersController
-- class: ModuleScript
-- hash: 8a790e2f9452c82b339dd49091b087c7060ef51a6c1fa29335b5fb64f496e35323162e09277c4e4f94ced23a149d554f

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local Styles = require(script.Parent.Parent:FindFirstChild("ui"):FindFirstChild("Styles"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local LocalPlayer = Players.LocalPlayer;
local white = Styles.colors.white;
local red_shiny = Styles.colors.red_shiny;

local function back_out(p1: number) -- Line: 51
    local v2 = p1 - 1;

    return v2 * 2.70158 * v2 * v2 + 1 + v2 * 1.70158 * v2;
end;

local function create_pooled_number(p3: userdata) -- Line: 74
    -- upvalues: Styles (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "DamageNumber";
    TextLabel.BackgroundTransparency = 1;
    TextLabel.AnchorPoint = Vector2.new(0.5, 0.5);
    TextLabel.AutomaticSize = Enum.AutomaticSize.XY;
    TextLabel.Size = UDim2.fromOffset(0, 0);
    TextLabel.FontFace = Styles.fonts.extraBold;
    TextLabel.TextColor3 = Styles.colors.pureWhite;
    TextLabel.TextStrokeTransparency = 1;
    TextLabel.Visible = false;
    TextLabel.Parent = p3;
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Rotation = 90;
    UIGradient.Parent = TextLabel;
    local UIScale = Instance.new("UIScale");
    UIScale.Parent = TextLabel;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextLabel;

    return {
        label = TextLabel,
        gradient = UIGradient,
        scale = UIScale,
        stroke = UIStroke
    };
end;

return {
    WeaponController = loader.use(require(script.Parent:FindFirstChild("WeaponController"))),

    init = function(p4) -- Line: 110, Name: init
        -- upvalues: LocalPlayer (copy)
        p4.pool = {};
        p4.active = {};
        p4.render_connection = nil;
        local ScreenGui = Instance.new("ScreenGui");
        ScreenGui.Name = "DamageNumbers";
        ScreenGui.ResetOnSpawn = false;
        ScreenGui.IgnoreGuiInset = false;
        ScreenGui.DisplayOrder = 100;
        ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
        p4.screen_gui = ScreenGui;
    end,

    start = function(u5) -- Line: 124, Name: start
        u5.WeaponController.damage_dealt:connect(function(p6: vector, p7: number, p8: boolean) -- Line: 126
            -- upvalues: u5 (copy)
            u5:spawn_number(p6, p7, p8);
        end);
    end,

    spawn_number = function(u9: any, p10: vector, p11: number, p12: boolean) -- Line: 136, Name: spawn_number
        -- upvalues: create_pooled_number (copy), red_shiny (copy), white (copy), RunService (copy)
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if not workspace_CurrentCamera then
            return;
        end;

        local v13 = (math.random() * 2 - 1) * 1;
        local v14 = (math.random() * 2 - 1) * 1;
        local v15 = p10 + Vector3.new(v13, 0, v14);
        local v16 = table.remove(u9.pool) or create_pooled_number(u9.screen_gui);
        local v17;

        if p12 then
            v17 = red_shiny;
        else
            v17 = white;
        end;

        local v18 = 55 * (0.85 + math.random() * 0.3);
        local v19 = 1500 * (0.85 + math.random() * 0.3);
        local v20 = -20 * (0.85 + math.random() * 0.3);
        local label = v16.label;
        local math_round_ret = math.round(p11);
        label.Text = tostring(math_round_ret);
        v16.gradient.Color = v17.gradient;
        v16.stroke.Color = v17.stroke;
        v16.scale.Scale = 0.85;
        v16.label.Rotation = 0;
        v16.label.TextTransparency = 0;
        v16.stroke.Transparency = 0;
        local v21 = workspace_CurrentCamera:WorldToScreenPoint(v15);
        v16.label.Position = UDim2.fromOffset(math.round(v21.X), (math.round(v21.Y)));
        v16.label.Visible = v21.Z > 0;
        table.insert(u9.active, {
            elapsed = 0,
            item = v16,
            world_position = v15,
            drift_speed = v18,
            gravity = v19,
            rotation_target = v20,
            is_headshot = p12
        });

        if not u9.render_connection then
            u9.render_connection = RunService.RenderStepped:Connect(function(p22: number) -- Line: 184
                -- upvalues: u9 (copy)
                u9:step(p22);
            end);
        end;
    end,

    step = function(p23: any, p24: number) -- Line: 190, Name: step
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if not workspace_CurrentCamera then
            return;
        end;

        local math_clamp_ret = math.clamp(workspace_CurrentCamera.ViewportSize.Magnitude / 1250, 1, 3);

        for i = #p23.active, 1, -1 do
            local v25 = p23.active[i];
            v25.elapsed = v25.elapsed + p24;
            local elapsed = v25.elapsed;
            local v26;

            if elapsed >= 0.75 then
                table.remove(p23.active, i);
                p23:return_to_pool(v25.item);
                v26 = i;
            else
                local item = v25.item;
                local v27 = workspace_CurrentCamera:WorldToScreenPoint(v25.world_position);

                if v27.Z <= 0 then
                    item.label.Visible = false;
                    v26 = i;
                else
                    item.label.Visible = true;
                    local v28 = v25.gravity * (0.5 * elapsed * elapsed - 0.15 * elapsed);
                    item.label.Position = UDim2.fromOffset(math.round(v27.X + -v25.drift_speed * elapsed * math_clamp_ret), (math.round(v27.Y + v28 * math_clamp_ret)));

                    if elapsed < 0.15 then
                        local v29 = elapsed / 0.15 - 1;
                        item.scale.Scale = (v29 * 2.70158 * v29 * v29 + 1 + v29 * 1.70158 * v29) * 0.29999999999999993 + 0.85;
                        item.label.Rotation = 0;
                    else
                        local v30 = (elapsed - 0.15) / 0.6;
                        item.scale.Scale = 1.15 - 0.6499999999999999 * v30 * v30;
                        item.label.Rotation = v25.rotation_target * v30;
                    end;

                    local math_clamp_ret2 = math.clamp(1 - (workspace_CurrentCamera.CFrame.Position - v25.world_position).Magnitude / 2000 * 0.9, 0.75, 1);
                    item.label.TextSize = math.round(math_clamp_ret * 26 * math_clamp_ret2 * (v25.is_headshot and 1.3 or 1));
                    item.stroke.Thickness = math_clamp_ret * 1.5;
                    local v31;

                    if elapsed > 0.45 then
                        local v32 = (elapsed - 0.45) / 0.3;
                        v31 = v32 * v32;
                    else
                        v31 = 0;
                    end;

                    item.label.TextTransparency = v31;
                    item.stroke.Transparency = v31;
                    v26 = i;
                end;
            end;
        end;

        if #p23.active == 0 and p23.render_connection then
            p23.render_connection:Disconnect();
            p23.render_connection = nil;
        end;
    end,

    return_to_pool = function(p33: any, p34: table) -- Line: 269, Name: return_to_pool
        p34.label.Visible = false;

        if #p33.pool >= 40 then
            p34.label:Destroy();

            return;
        end;

        table.insert(p33.pool, p34);
    end,

    cleanup_pool = function(p35) -- Line: 280, Name: cleanup_pool
        if p35.render_connection then
            p35.render_connection:Disconnect();
            p35.render_connection = nil;
        end;

        for _, v in p35.active do
            v.item.label:Destroy();
        end;

        table.clear(p35.active);

        for _, v in p35.pool do
            v.label:Destroy();
        end;

        table.clear(p35.pool);
    end
};