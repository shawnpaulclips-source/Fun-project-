-- ReplicatedStorage.client.controllers.CurrencyShopController
-- class: ModuleScript
-- hash: 5012bdd2826cf6a3bb2925a31bfef1737a4e6914e1f2f7b16c63819725ff17bd3cb8187d3e4c629df4583c533f2f6e67

-- Decompiled with Potassium's decompiler.

local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 24, Name: init
        p1.buying = false;
        p1.buying_daily_coin = false;
    end,

    start = function(p2) -- Line: 29, Name: start
    end,

    buy_crate = function(p3: any, p4: string, p5: string) -- Line: 36, Name: buy_crate
        -- upvalues: zap (copy)
        if p3.buying then
            return {
                ok = false,
                error = "busy"
            };
        end;

        p3.buying = true;
        local success, result = pcall(zap.buy_crate_with_currency.call, p4, p5);
        p3.buying = false;

        return not success and {
            ok = false,
            error = "network"
        } or result;
    end,

    buy_daily_coin_crate = function(p6: any, p7: string) -- Line: 59, Name: buy_daily_coin_crate
        -- upvalues: zap (copy)
        if p6.buying_daily_coin then
            return {
                ok = false,
                error = "busy"
            };
        end;

        p6.buying_daily_coin = true;
        local success, result = pcall(zap.buy_daily_coin_crate.call, p7);
        p6.buying_daily_coin = false;

        return not success and {
            ok = false,
            error = "network"
        } or result;
    end
};