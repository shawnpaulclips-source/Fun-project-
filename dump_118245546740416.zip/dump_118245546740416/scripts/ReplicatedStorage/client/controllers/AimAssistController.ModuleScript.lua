-- ReplicatedStorage.client.controllers.AimAssistController
-- class: ModuleScript
-- hash: 24695b5468926f23c39011b2765676290ca9f31ca977121094ae29523fad346070506b8228e6fbff0c49bd496472fdc4

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local UserInputService = game:GetService("UserInputService");
local AimAdjuster = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("aim_assist"):FindFirstChild("AimAdjuster"));
local AimAssistEnum = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("aim_assist"):FindFirstChild("AimAssistEnum"));
local dummy_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("dummy_tag"));
local TargetSelector = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("aim_assist"):FindFirstChild("TargetSelector"));
local get_last_input_category = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("get_last_input_category"));
local input_category_from_type = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("input_category_from_type"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local resolve_skin = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("weapons"):FindFirstChild("resolve_skin"));
local wants_aim_assist = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("wants_aim_assist"));
local WeaponConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("weapons"):FindFirstChild("WeaponConfig"));
local LocalPlayer = Players.LocalPlayer;

local function smoothstep(p1: number) -- Line: 21
    return p1 * p1 * (3 - p1 * 2);
end;

local function lerp(p2: number, p3: number, p4: number) -- Line: 25
    return p2 + (p3 - p2) * p4;
end;

local v24 = {
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),
    SettingsController = loader.use(require(script.Parent:FindFirstChild("SettingsController"))),

    init = function(p5) -- Line: 42, Name: init
        -- upvalues: TargetSelector (copy), AimAdjuster (copy), get_last_input_category (copy)
        p5.selector = TargetSelector.new();
        p5.adjuster = AimAdjuster.new();
        p5.enabled = false;
        p5.skin_connection = nil;
        p5.last_look_input_at = (-1 / 0);
        p5.input_category = get_last_input_category();
        p5.lock_instance = nil;
        p5.lock_time = 0;
        p5.lock_seen_at = (-1 / 0);
    end,

    refresh_range = function(p6) -- Line: 63, Name: refresh_range
        -- upvalues: LocalPlayer (copy), resolve_skin (copy)
        local Character = LocalPlayer.Character;
        local v7;

        if Character then
            v7 = Character:GetAttribute("equipped_skin");
        else
            v7 = nil;
        end;

        p6.selector:set_range(resolve_skin(v7).weapon.weapon_stats.range);
    end,

    start = function(u8) -- Line: 71, Name: start
        -- upvalues: WeaponConfig (copy), AimAssistEnum (copy), dummy_tag (copy), LocalPlayer (copy), UserInputService (copy), input_category_from_type (copy)
        u8.selector:set_field_of_view(WeaponConfig.aim_assist_fov);
        u8.selector:set_sorting_behavior(AimAssistEnum.sorting_behavior.angle);
        u8.selector:add_target_tag(dummy_tag);
        u8.selector:add_player_targets(true, false, { "HeadTarget", "TorsoTarget" });

        local function bind_character(p9: userdata) -- Line: 83
            -- upvalues: u8 (copy)
            u8:reset_lock();
            u8:refresh_range();

            if u8.skin_connection then
                u8.skin_connection:Disconnect();
            end;

            u8.skin_connection = p9:GetAttributeChangedSignal("equipped_skin"):Connect(function() -- Line: 91
                -- upvalues: u8 (ref)
                u8:refresh_range();
            end);
        end;

        if LocalPlayer.Character then
            bind_character(LocalPlayer.Character);
        end;

        LocalPlayer.CharacterAdded:Connect(bind_character);
        u8:apply_assist_strengths();
        u8:refresh_eligibility();
        UserInputService.LastInputTypeChanged:Connect(function(p10) -- Line: 111
            -- upvalues: input_category_from_type (ref), u8 (copy)
            if p10 == Enum.UserInputType.MouseMovement or p10 == Enum.UserInputType.MouseWheel then
                return;
            end;

            local v11 = input_category_from_type(p10);
            u8.input_category = v11;
            u8:apply_assist_strengths(v11);
            u8:refresh_eligibility(v11);
        end);
        u8.SettingsController.settings_updated:connect(function() -- Line: 125
            -- upvalues: u8 (copy)
            u8:refresh_eligibility();
        end);
    end,

    is_aiming = function(p12) -- Line: 133, Name: is_aiming
        -- upvalues: WeaponConfig (copy)
        return os.clock() - p12.last_look_input_at <= WeaponConfig.auto_shoot_aim_grace;
    end,

    refresh_eligibility = function(p13, p14) -- Line: 143, Name: refresh_eligibility
        -- upvalues: wants_aim_assist (copy)
        local v15 = wants_aim_assist(p14 or p13.input_category) and p13.SettingsController.settings.aim_assist_enabled ~= false;

        if v15 then
            p13:enable();

            return;
        end;

        p13:disable();
    end,

    apply_assist_strengths = function(p16, p17) -- Line: 176, Name: apply_assist_strengths
        -- upvalues: WeaponConfig (copy), AimAssistEnum (copy)
        local v18 = p17 or p16.input_category;
        local v19 = WeaponConfig.aim_assist_centering_by_input[v18] or WeaponConfig.aim_assist_centering;
        local v20 = WeaponConfig.aim_assist_pull_gain_by_input[v18] or WeaponConfig.aim_assist_pull_gain;
        p16.adjuster:set_method_strength(AimAssistEnum.method.friction, WeaponConfig.aim_assist_friction);
        p16.adjuster:set_method_strength(AimAssistEnum.method.centering, v19);
        p16.adjuster:set_pull_gain(v20);
    end,

    enable = function(p21) -- Line: 194, Name: enable
        p21.enabled = true;
    end,

    disable = function(p22) -- Line: 198, Name: disable
        p22.enabled = false;
        p22:reset_lock();
    end,

    reset_lock = function(p23) -- Line: 205, Name: reset_lock
        p23.lock_instance = nil;
        p23.lock_time = 0;
    end
};

local function distance_strength(p25: number) -- Line: 211
    -- upvalues: WeaponConfig (copy)
    return p25 < WeaponConfig.aim_assist_min_range and 0 or 1;
end;

local u26 = {
    slowdown = 1,
    pull = Vector2.zero
};

function v24.adjust(p27: any, p28, p29, p30: number) -- Line: 224
    -- upvalues: WeaponConfig (copy), u26 (copy), LocalPlayer (copy), get_last_input_category (copy)
    if p29.Magnitude >= WeaponConfig.aim_assist_input_epsilon then
        p27.last_look_input_at = os.clock();
    end;

    if not (p27.enabled and p27.GameStateController.is_in_game) then
        return u26;
    end;

    local v31 = p27.selector:select_target(p28);

    if not v31 then
        return u26;
    end;

    if v31.instance == LocalPlayer.Character then
        return u26;
    end;

    local v32 = v31.distance < WeaponConfig.aim_assist_min_range and 0 or 1;

    if v32 <= 0 then
        return u26;
    end;

    local UpVector = p28.UpVector;
    local aim_assist_input_epsilon = WeaponConfig.aim_assist_input_epsilon;
    local v33 = v31.best_position - p28.Position;
    local Vector2_new_ret = Vector2.new(v33:Dot(p28.RightVector), v33:Dot(UpVector));
    local Vector2_new_ret2 = Vector2.new(-p29.Y, p29.X);
    local v34 = (aim_assist_input_epsilon > Vector2_new_ret2.Magnitude or aim_assist_input_epsilon > Vector2_new_ret.Magnitude) and 0 or Vector2_new_ret2.Unit:Dot(Vector2_new_ret.Unit);
    local math_clamp_ret = math.clamp(v34 + 1, 0, 1);
    local v35 = math_clamp_ret * math_clamp_ret * (3 - math_clamp_ret * 2);
    local v36;

    if get_last_input_category() == "Touch" then
        v36 = p27.SettingsController.settings.auto_shoot ~= false;
    else
        v36 = false;
    end;

    local v37;

    if v36 then
        v37 = not p27:is_aiming();
    else
        v37 = v36;
    end;

    if v37 then
        v35 = WeaponConfig.aim_assist_touch_idle_magnet;
    end;

    local os_clock_ret = os.clock();

    if v31.instance ~= p27.lock_instance or os_clock_ret - p27.lock_seen_at > WeaponConfig.aim_assist_lock_grace then
        p27.lock_instance = v31.instance;
        p27.lock_time = 0;
    end;

    p27.lock_seen_at = os_clock_ret;
    local v38;

    if v37 then
        v38 = 1;
    else
        local v39 = p27.lock_time + math.min(p30, WeaponConfig.aim_assist_lock_max_dt) * v35;
        p27.lock_time = math.min(v39, WeaponConfig.aim_assist_lock_ramp_time);
        local v40;

        if v36 then
            v40 = WeaponConfig.aim_assist_lock_autoshoot_end_scale;
        else
            v40 = WeaponConfig.aim_assist_lock_end_scale;
        end;

        local aim_assist_lock_start_scale = WeaponConfig.aim_assist_lock_start_scale;
        local v41 = p27.lock_time / WeaponConfig.aim_assist_lock_ramp_time;
        v38 = aim_assist_lock_start_scale + (v40 - aim_assist_lock_start_scale) * (v41 * v41 * (3 - v41 * 2));
    end;

    local v42 = Vector2.new(Vector2_new_ret.X / WeaponConfig.aim_assist_friction_half_width, Vector2_new_ret.Y / WeaponConfig.aim_assist_friction_half_height).Magnitude - 1;
    local math_clamp_ret2 = math.clamp(v42, 0, 1);

    return p27.adjuster:adjust_aim({
        subject_cframe = p28,
        target_result = v31,
        delta_time = p30,
        adjustment_strength = v32,
        magnet_gate = v35,
        friction_gate = 1 - math_clamp_ret2 * math_clamp_ret2 * (3 - math_clamp_ret2 * 2),
        pull_scale = v38
    });
end;

return v24;