-- ReplicatedStorage.client.controllers.CorpseController
-- class: ModuleScript
-- hash: 88691b1063020117c3cc3ee47179edf14d9d4e635323f179cf5d3aed63f00e2f1f506fd0f801a1a153fc01c1ea0d24ef

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local BotConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("BotConfig"));
local BountyConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("BountyConfig"));
local dummy_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("dummy_tag"));
local HitboxConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("characters"):FindFirstChild("HitboxConfig"));
local NametagConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("nametag"):FindFirstChild("NametagConfig"));
local fling_ragdoll = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("fling_ragdoll"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local play_headshot_vfx = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("play_headshot_vfx"));
local LocalPlayer = Players.LocalPlayer;
local u1 = {
    Script = "destroy",
    LocalScript = "destroy",
    BillboardGui = "destroy",
    ParticleEmitter = "destroy",
    Beam = "destroy",
    Trail = "destroy",
    PointLight = "destroy",
    SpotLight = "destroy",
    SurfaceLight = "destroy",
    Humanoid = "humanoid",
    Motor6D = "motor",
    AnimationConstraint = "joint",
    BallSocketConstraint = "socket"
};
local u2 = {
    CollisionPart = true,
    Animate = true,
    CombatHighlight = true
};
local u3 = {
    Waist = true,
    Neck = true
};

for i in {
    BodyVelocity = true,
    BodyForce = true,
    BodyGyro = true,
    BodyAngularVelocity = true,
    BodyPosition = true,
    LinearVelocity = true,
    VectorForce = true,
    AngularVelocity = true,
    AlignOrientation = true,
    AlignPosition = true
} do
    u1[i] = "destroy";
end;

local u4 = {
    ParticleEmitter = "clear",
    Beam = "disable",
    Trail = "disable",
    PointLight = "disable",
    SpotLight = "disable",
    SurfaceLight = "disable"
};
local u5 = false;

local function set_characters_collision_group(p6: userdata) -- Line: 123
    p6.CollisionGroup = "Characters";
end;

local function get_corpses_folder() -- Line: 127
    local Corpses = workspace:FindFirstChild("Corpses");

    if Corpses then
        return Corpses;
    end;

    local Folder = Instance.new("Folder");
    Folder.Name = "Corpses";
    Folder.Parent = workspace;

    return Folder;
end;

local function strip_and_collect(p7: userdata) -- Line: 149
    -- upvalues: CollectionService (copy), dummy_tag (copy), NametagConfig (copy), BountyConfig (copy), u1 (copy), u2 (copy), HitboxConfig (copy), u3 (copy), u5 (ref), set_characters_collision_group (copy)
    CollectionService:RemoveTag(p7, dummy_tag);
    CollectionService:RemoveTag(p7, NametagConfig.TAG);
    p7:SetAttribute(BountyConfig.BOUNTY_ATTR, nil);
    p7:SetAttribute(BountyConfig.BOUNTY_TIER_ATTR, nil);
    p7:SetAttribute(BountyConfig.PARTICIPANT_ATTR, nil);
    p7:SetAttribute(BountyConfig.STREAK_ATTR, nil);
    local v8 = {};
    local v9 = {};
    local v10 = {};
    local v11 = nil;

    for _, descendant in p7:GetDescendants() do
        local v12 = u1[descendant.ClassName];

        if u2[descendant.Name] or (HitboxConfig.hitbox_names[descendant.Name] or v12 == "destroy") then
            descendant:Destroy();
        elseif v12 == "humanoid" then
            descendant.BreakJointsOnDeath = false;
            descendant.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
            descendant.PlatformStand = true;
            v11 = descendant;
        elseif v12 == "motor" then
            if u3[descendant.Name] then
                descendant.C0 = CFrame.new(descendant.C0.Position);
            end;

            table.insert(v10, descendant);
        elseif v12 == "joint" then
            table.insert(v10, descendant);
        elseif v12 == "socket" then
            table.insert(v9, descendant);
        elseif descendant:IsA("BasePart") then
            descendant.LocalTransparencyModifier = 0;
            descendant.CanQuery = false;
            descendant.CanTouch = false;
            descendant.Anchored = false;
            descendant.CanCollide = true;

            if u5 then
                descendant.CollisionGroup = "Characters";
            elseif pcall(set_characters_collision_group, descendant) then
                u5 = true;
            end;

            table.insert(v8, descendant);
        end;
    end;

    return {
        parts = v8,
        joints = v10,
        sockets = v9,
        humanoid = v11
    };
end;

return {
    WeaponController = loader.use(require(script.Parent:FindFirstChild("WeaponController"))),
    KillEffectsController = loader.use(require(script.Parent:FindFirstChild("KillEffectsController"))),
    QualityController = loader.use(require(script.Parent:FindFirstChild("QualityController"))),

    init = function(p13) -- Line: 248, Name: init
        p13.hidden_bodies = {};
        p13.hide_connection = nil;
        p13.corpse_queue = {};
        p13.spawn_connection = nil;
        p13.reuse_watchers = {};
    end,

    start = function(u14) -- Line: 259, Name: start
        -- upvalues: LocalPlayer (copy)
        u14.WeaponController.kill_effect:connect(function(p15: userdata, p16: string?, p17: string, p18: boolean, p19: vector, p20: vector, p21: userdata?) -- Line: 264
            -- upvalues: LocalPlayer (ref), u14 (copy)
            local v22;

            if p21 == nil then
                v22 = false;
            else
                v22 = p21 == LocalPlayer.Character;
            end;

            u14:spawn_corpse(p15, p19, p20, p18, v22);
        end);
        u14.WeaponController.dummy_kill_effect:connect(function(p23: userdata, p24: vector, p25: vector) -- Line: 282
            -- upvalues: u14 (copy)
            u14:spawn_corpse(p23, p24, p25, false, false);
        end);
    end,

    spawn_corpse = function(p26: any, p27: userdata, p28: vector, p29: vector, p30: boolean, p31: boolean) -- Line: 294, Name: spawn_corpse
        -- upvalues: HitboxConfig (copy), play_headshot_vfx (copy), u4 (copy)
        local v32 = nil;

        if p30 then
            local v33 = p27:FindFirstChild(HitboxConfig.head_name);

            if v33 and v33:IsA("BasePart") then
                v32 = v33.Position;
            end;
        end;

        p26.KillEffectsController:play(nil, p28);

        if v32 then
            play_headshot_vfx(v32);
        end;

        debug.profilebegin("corpse_register_hide");
        local v34 = {};
        local v35 = {};

        for _, descendant in p27:GetDescendants() do
            local v36 = u4[descendant.ClassName];

            if v36 == "clear" then
                if descendant.Enabled then
                    table.insert(v35, descendant);
                end;

                descendant.Enabled = false;
                descendant:Clear();
            elseif v36 == "disable" then
                if descendant.Enabled then
                    table.insert(v35, descendant);
                end;

                descendant.Enabled = false;
            elseif descendant:IsA("BasePart") then
                table.insert(v34, descendant);
            end;
        end;

        p26.hidden_bodies[p27] = {
            expiry = os.clock() + 3,
            parts = v34
        };
        p26:ensure_hide_loop();
        p26:watch_for_reuse(p27, v34, v35);
        debug.profileend();

        if not (p26.QualityController:lever_on("corpses") and (p31 or p26.QualityController:lever_on("corpses_others"))) then
            return;
        end;

        table.insert(p26.corpse_queue, {
            victim_character = p27,
            position = p28,
            direction = p29
        });
        p26:ensure_spawn_loop();
    end,

    build_corpse = function(p37: any, p38: userdata, p39: vector, p40: vector) -- Line: 383, Name: build_corpse
        -- upvalues: strip_and_collect (copy), fling_ragdoll (copy)
        if p38.Parent == nil then
            return;
        end;

        debug.profilebegin("corpse_spawn_total");
        local Archivable = p38.Archivable;
        p38.Archivable = true;
        debug.profilebegin("corpse_clone");
        local u41 = p38:Clone();
        debug.profileend();
        p38.Archivable = Archivable;

        if not u41 then
            debug.profileend();

            return;
        end;

        debug.profilebegin("corpse_strip");
        local v42 = strip_and_collect(u41);
        debug.profileend();
        u41.Name = "Corpse";
        local Corpses = workspace:FindFirstChild("Corpses");

        if not Corpses then
            Corpses = Instance.new("Folder");
            Corpses.Name = "Corpses";
            Corpses.Parent = workspace;
        end;

        u41.Parent = Corpses;

        if v42.humanoid then
            v42.humanoid.Health = 0;
        end;

        debug.profilebegin("corpse_zero_velocity");

        for _, v in v42.parts do
            v.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
            v.AssemblyAngularVelocity = Vector3.new(0, 0, 0);
        end;

        debug.profileend();
        debug.profilebegin("corpse_ragdoll");
        fling_ragdoll(u41, p40, v42.parts, v42.joints, v42.sockets);
        debug.profileend();
        p37.KillEffectsController:apply_highlight(u41);
        task.delay(1.5, function() -- Line: 443
            -- upvalues: u41 (copy)
            if u41.Parent then
                u41:Destroy();
            end;
        end);
        debug.profileend();
    end,

    ensure_hide_loop = function(u43) -- Line: 451, Name: ensure_hide_loop
        -- upvalues: RunService (copy)
        if u43.hide_connection then
            return;
        end;

        u43.hide_connection = RunService.RenderStepped:Connect(function() -- Line: 455
            -- upvalues: u43 (copy)
            u43:step_hide();
        end);
    end,

    step_hide = function(p44) -- Line: 460, Name: step_hide
        local os_clock_ret = os.clock();

        for i, v in p44.hidden_bodies do
            if i.Parent == nil or v.expiry < os_clock_ret then
                p44.hidden_bodies[i] = nil;
            else
                for _, v2 in v.parts do
                    v2.LocalTransparencyModifier = 1;
                end;
            end;
        end;

        if next(p44.hidden_bodies) == nil and p44.hide_connection then
            p44.hide_connection:Disconnect();
            p44.hide_connection = nil;
        end;
    end,

    watch_for_reuse = function(u45: any, u46: userdata, u47: table, u48: table) -- Line: 490, Name: watch_for_reuse
        -- upvalues: BotConfig (copy)
        u45:stop_reuse_watch(u46);
        local v49 = {};
        u45.reuse_watchers[u46] = v49;

        local function unhide() -- Line: 501
            -- upvalues: u47 (copy), u48 (copy), u45 (copy), u46 (copy)
            for _, v in u47 do
                v.LocalTransparencyModifier = 0;
            end;

            for _, v in u48 do
                v.Enabled = true;
            end;

            u45.hidden_bodies[u46] = nil;
            u45:stop_reuse_watch(u46);
        end;

        local AttributeChangedSignal = u46:GetAttributeChangedSignal("InRound");
        table.insert(v49, AttributeChangedSignal:Connect(function() -- Line: 514
            -- upvalues: u46 (copy), u47 (copy), u48 (copy), u45 (copy)
            if u46:GetAttribute("InRound") ~= true then
                return;
            end;

            for _, v in u47 do
                v.LocalTransparencyModifier = 0;
            end;

            for _, v in u48 do
                v.Enabled = true;
            end;

            u45.hidden_bodies[u46] = nil;
            u45:stop_reuse_watch(u46);
        end));
        local PropertyChangedSignal = u46:GetPropertyChangedSignal("Parent");
        table.insert(v49, PropertyChangedSignal:Connect(function() -- Line: 524
            -- upvalues: u46 (copy), BotConfig (ref), u47 (copy), u48 (copy), u45 (copy)
            local Parent = u46.Parent;

            if Parent and (Parent.Name == BotConfig.lobby_folder_name and Parent.Parent == workspace) then
                for _, v in u47 do
                    v.LocalTransparencyModifier = 0;
                end;

                for _, v in u48 do
                    v.Enabled = true;
                end;

                u45.hidden_bodies[u46] = nil;
                u45:stop_reuse_watch(u46);
            end;
        end));
        table.insert(v49, u46.Destroying:Connect(function() -- Line: 538
            -- upvalues: u45 (copy), u46 (copy)
            u45:stop_reuse_watch(u46);
        end));
    end,

    stop_reuse_watch = function(p50: any, p51: userdata) -- Line: 544, Name: stop_reuse_watch
        local v52 = p50.reuse_watchers[p51];

        if not v52 then
            return;
        end;

        p50.reuse_watchers[p51] = nil;

        for _, v in v52 do
            v:Disconnect();
        end;
    end,

    ensure_spawn_loop = function(u53) -- Line: 555, Name: ensure_spawn_loop
        -- upvalues: RunService (copy)
        if u53.spawn_connection then
            return;
        end;

        u53.spawn_connection = RunService.Heartbeat:Connect(function() -- Line: 559
            -- upvalues: u53 (copy)
            u53:step_spawn();
        end);
    end,

    step_spawn = function(p54) -- Line: 564, Name: step_spawn
        local table_remove_ret = table.remove(p54.corpse_queue, 1);

        if table_remove_ret then
            p54:build_corpse(table_remove_ret.victim_character, table_remove_ret.position, table_remove_ret.direction);
        end;

        if #p54.corpse_queue == 0 and p54.spawn_connection then
            p54.spawn_connection:Disconnect();
            p54.spawn_connection = nil;
        end;
    end
};