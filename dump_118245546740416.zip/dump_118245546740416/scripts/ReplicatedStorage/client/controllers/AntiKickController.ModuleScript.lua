-- ReplicatedStorage.client.controllers.AntiKickController
-- class: ModuleScript
-- hash: d9a0aa6d342f931e6be92ee699746921b28cfbccb7a62e01db3ba45b84496d1d2faa5fe032f6f9c140f831056d66faa9

-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local match_place = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("matchmaking"):FindFirstChild("match_place"));
local ranked_place = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("ranked"):FindFirstChild("ranked_place"));
local server_role = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("server_role"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    QueueController = loader.use(require(script.Parent:FindFirstChild("QueueController"))),

    init = function(p1) -- Line: 11, Name: init
        p1.LastInput = workspace:GetServerTimeNow();
        p1.AFK_TIME = 900;
        p1.rejoining = false;
    end,

    start = function(u2) -- Line: 17, Name: start
        -- upvalues: UserInputService (copy), server_role (copy), ranked_place (copy), match_place (copy), zap (copy)
        UserInputService.InputChanged:Connect(function() -- Line: 18
            -- upvalues: u2 (copy)
            u2.LastInput = workspace:GetServerTimeNow();
        end);
        UserInputService.InputBegan:Connect(function() -- Line: 21
            -- upvalues: u2 (copy)
            u2.LastInput = workspace:GetServerTimeNow();
        end);
        task.spawn(function() -- Line: 25
            -- upvalues: u2 (copy), server_role (ref), ranked_place (ref), match_place (ref), zap (ref)
            while true do
                local v3 = workspace:GetServerTimeNow() - u2.LastInput;
                local v4 = server_role.get();

                if u2.AFK_TIME < v3 and not (u2.rejoining or (v4 == "beginner" or (v4 == "tutorial" or (ranked_place.is_ranked_place() or (match_place.is_match_place() or u2.QueueController:get_state().status ~= "Idle"))))) then
                    break;
                end;

                task.wait(10);
            end;

            u2.rejoining = true;
            zap.rejoin_me.fire();
        end);
    end
};