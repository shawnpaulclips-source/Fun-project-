-- ReplicatedStorage.client.controllers.FlyController
-- class: ModuleScript
-- hash: 3d7e47431a19582e4f39771609558e632952b4be4d8e5ffedaad56890825d8220f8327bb55ba0ba7357a1a8aa0fcce5d

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local LocalPlayer = Players.LocalPlayer;

return {
    init = function(p1) -- Line: 25, Name: init
        p1.flying = false;
        p1.hrp = nil;
        p1.camera = nil;
        p1.fly_cframe = nil;
        p1.fly_connection = nil;
    end,

    start = function(u2) -- Line: 35, Name: start
        -- upvalues: LocalPlayer (copy)
        u2:set_fly(LocalPlayer:GetAttribute("fly_debug") == true);
        LocalPlayer:GetAttributeChangedSignal("fly_debug"):Connect(function() -- Line: 38
            -- upvalues: u2 (copy), LocalPlayer (ref)
            u2:set_fly(LocalPlayer:GetAttribute("fly_debug") == true);
        end);
        LocalPlayer.CharacterAdded:Connect(function() -- Line: 43
            -- upvalues: u2 (copy)
            if u2.flying then
                u2:arm();
            end;
        end);
        LocalPlayer.CharacterRemoving:Connect(function() -- Line: 51
            -- upvalues: u2 (copy)
            u2:disconnect_loop();
            u2.hrp = nil;
            u2.fly_cframe = nil;
        end);
    end,

    set_fly = function(p3: any, p4: boolean) -- Line: 60, Name: set_fly
        if p4 == p3.flying then
            return;
        end;

        p3.flying = p4;

        if p4 then
            p3:arm();

            return;
        end;

        p3:disarm();
    end,

    arm = function(u5) -- Line: 72, Name: arm
        -- upvalues: LocalPlayer (copy), RunService (copy)
        u5:disconnect_loop();
        local Character = LocalPlayer.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        u5.hrp = HumanoidRootPart;
        u5.camera = workspace.CurrentCamera;
        local v6 = HumanoidRootPart.CFrame + Vector3.new(0, 14, 0);
        u5.fly_cframe = v6;
        HumanoidRootPart.CFrame = v6;
        HumanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
        u5.fly_connection = RunService.RenderStepped:Connect(function(p7: number) -- Line: 95
            -- upvalues: u5 (copy)
            u5:step_fly(p7);
        end);
    end,

    disarm = function(p8) -- Line: 100, Name: disarm
        p8:disconnect_loop();
        p8.hrp = nil;
        p8.fly_cframe = nil;
    end,

    disconnect_loop = function(p9) -- Line: 106, Name: disconnect_loop
        if p9.fly_connection then
            p9.fly_connection:Disconnect();
            p9.fly_connection = nil;
        end;
    end,

    step_fly = function(p10: any, p11: number) -- Line: 113, Name: step_fly
        -- upvalues: UserInputService (copy)
        local hrp = p10.hrp;
        local camera = p10.camera;
        local fly_cframe = p10.fly_cframe;

        if not (hrp and (hrp.Parent and (camera and fly_cframe))) then
            return;
        end;

        if not UserInputService:GetFocusedTextBox() then
            local LookVector = camera.CFrame.LookVector;
            local RightVector = camera.CFrame.RightVector;
            local v12 = Vector3.new(0, 0, 0);

            if UserInputService:IsKeyDown(Enum.KeyCode.W) then
                v12 = v12 + LookVector;
            end;

            if UserInputService:IsKeyDown(Enum.KeyCode.S) then
                v12 = v12 - LookVector;
            end;

            if UserInputService:IsKeyDown(Enum.KeyCode.D) then
                v12 = v12 + RightVector;
            end;

            if UserInputService:IsKeyDown(Enum.KeyCode.A) then
                v12 = v12 - RightVector;
            end;

            if UserInputService:IsKeyDown(Enum.KeyCode.Space) then
                v12 = v12 + Vector3.new(0, 1, 0);
            end;

            if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
                v12 = v12 - Vector3.new(0, 1, 0);
            end;

            if v12.Magnitude >= 0.01 then
                local v13 = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) and 250 or 80;
                fly_cframe = fly_cframe + v12.Unit * v13 * p11;
                p10.fly_cframe = fly_cframe;
            end;
        end;

        hrp.CFrame = fly_cframe;
        hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
    end
};