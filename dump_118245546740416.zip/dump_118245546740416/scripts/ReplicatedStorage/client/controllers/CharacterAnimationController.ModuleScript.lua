-- ReplicatedStorage.client.controllers.CharacterAnimationController
-- class: ModuleScript
-- hash: 9f6b37e94d23ef227ef4ed5b7004313584bfb6f0397ac3b4522aa12a1079df9a89b11dd6185dd9244f34f97c9ad3e9d9

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local BotConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("BotConfig"));
local is_grounded = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("is_grounded"));
local resolve_skin = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("weapons"):FindFirstChild("resolve_skin"));
local WeaponConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("weapons"):FindFirstChild("WeaponConfig"));
local LocalPlayer = Players.LocalPlayer;
local u1 = (WeaponConfig.walk_speed_default + WeaponConfig.walk_speed_sprint) / 2;
local v5 = {
    init = function(p2) -- Line: 39, Name: init
        p2.animator = nil;
        p2.tracks = {};
        p2.equipped = false;
        p2.shoot_generation = 0;
        p2.round_takeover_character = nil;
    end,

    start = function(u3) -- Line: 52, Name: start
        -- upvalues: LocalPlayer (copy)
        local function on_character(u4: userdata) -- Line: 53
            -- upvalues: u3 (copy)
            u3:reload_animator(u4);
            u4:GetAttributeChangedSignal("equipped_skin"):Connect(function() -- Line: 59
                -- upvalues: u3 (ref), u4 (copy)
                u3:reload_animator(u4);
            end);
            u3:drive_round_locomotion(u4);
        end;

        if LocalPlayer.Character then
            on_character(LocalPlayer.Character);
        end;

        LocalPlayer.CharacterAdded:Connect(on_character);
    end
};

local function get_animator(p6: userdata) -- Line: 74
    local v7 = p6:FindFirstChildWhichIsA("Humanoid") or p6:WaitForChild("Humanoid", 10);

    if v7 then
        return v7:FindFirstChildWhichIsA("Animator") or v7:WaitForChild("Animator", 10);
    end;

    return nil;
end;

local function load_track(u8: userdata, p9: string, p10: any, p11: boolean) -- Line: 84
    if p9 == "" or p9 == "rbxassetid://0" then
        return nil;
    end;

    local Animation = Instance.new("Animation");
    Animation.AnimationId = p9;
    local success, result = pcall(function() -- Line: 95
        -- upvalues: u8 (copy), Animation (copy)
        return u8:LoadAnimation(Animation);
    end);

    if not (success and result) then
        return nil;
    end;

    result.Priority = p10;
    result.Looped = p11;

    return result;
end;

local function get_template_animation_id(p12: string) -- Line: 112
    -- upvalues: ReplicatedStorage (copy), BotConfig (copy)
    local assets = ReplicatedStorage:FindFirstChild("assets");

    if assets then
        assets = assets:FindFirstChild(BotConfig.rig_template_name);
    end;

    if not (assets and assets:IsA("Model")) then
        return nil;
    end;

    local v13 = assets:FindFirstChildOfClass("Humanoid");

    if v13 then
        v13 = v13:FindFirstChildOfClass("Animator");
    end;

    if not v13 then
        return nil;
    end;

    local v14 = v13:FindFirstChild(p12);

    if v14 and v14:IsA("Animation") then
        return v14.AnimationId;
    end;

    return nil;
end;

local function get_animate_clip_id(p15: userdata, p16: string, p17: string) -- Line: 136
    local Animate = p15:FindFirstChild("Animate");

    if not (Animate and Animate:IsA("LocalScript")) then
        return nil;
    end;

    local v18 = Animate:FindFirstChild(p16);

    if v18 then
        v18 = v18:FindFirstChild(p17);
    end;

    if v18 and v18:IsA("Animation") then
        return v18.AnimationId;
    end;

    return nil;
end;

local function reconcile_locomotion_track(p19: userdata?, p20: userdata?) -- Line: 158
    if not p19 then
        return;
    end;

    if p19 == p20 then
        if not p19.IsPlaying then
            p19:Play(0.2);
        end;
    elseif p19.IsPlaying then
        p19:Stop(0.2);
    end;
end;

function v5.reload_animator(u21: any, p22: userdata) -- Line: 175
    -- upvalues: resolve_skin (copy), load_track (copy)
    for _, v in u21.tracks do
        if v then
            v:Stop(0);
        end;
    end;

    table.clear(u21.tracks);
    u21.animator = nil;
    local v23 = p22:FindFirstChildWhichIsA("Humanoid") or p22:WaitForChild("Humanoid", 10);
    local v24;

    if v23 then
        v24 = v23:FindFirstChildWhichIsA("Animator") or v23:WaitForChild("Animator", 10);
    else
        v24 = nil;
    end;

    if not v24 then
        return;
    end;

    u21.animator = v24;
    local v25 = resolve_skin((p22:GetAttribute("equipped_skin")));
    local character_animations = v25.weapon.viewmodel.character_animations;
    u21.tracks.idle = load_track(v24, character_animations.idle, Enum.AnimationPriority.Idle, true);
    local idle = u21.tracks.idle;

    if idle then
        idle.Stopped:Connect(function() -- Line: 207
            -- upvalues: u21 (copy)
            task.defer(function() -- Line: 208
                -- upvalues: u21 (ref)
                u21:start_idle();
            end);
        end);
    end;

    u21.tracks.shoot = load_track(v24, character_animations.shoot, Enum.AnimationPriority.Action2, false);
    u21.tracks.reload = load_track(v24, character_animations.reload, Enum.AnimationPriority.Action, false);
    u21.tracks.slide = load_track(v24, character_animations.slide, Enum.AnimationPriority.Movement, true);
    u21.equipped = p22:FindFirstChild(v25.weapon.third_person.model_name) ~= nil;
    u21:start_idle();
end;

function v5.drive_round_locomotion(u26: any, u27: userdata) -- Line: 246
    -- upvalues: is_grounded (copy), u1 (copy), get_template_animation_id (copy), resolve_skin (copy), get_animate_clip_id (copy), load_track (copy), RunService (copy)
    local u28 = nil;
    local u29 = nil;
    local u30 = nil;
    local u31 = nil;

    local function suppress_foreign_locomotion(p32: userdata) -- Line: 265
        -- upvalues: u30 (ref)
        local v33 = u30;

        if not v33 then
            return;
        end;

        if p32 == v33.idle or (p32 == v33.walk or (p32 == v33.run or p32 == v33.fall)) then
            return;
        end;

        if p32.Priority == Enum.AnimationPriority.Core then
            p32:Stop(0);
        end;
    end;

    local function step() -- Line: 286
        -- upvalues: u31 (ref), u27 (copy), u30 (ref), is_grounded (ref), u1 (ref)
        local v34 = u31;

        if not v34 or v34.Parent == nil then
            v34 = u27:FindFirstChild("HumanoidRootPart");
            u31 = v34;
        end;

        local v35 = u30;

        if not (v34 and v35) then
            return;
        end;

        local AssemblyLinearVelocity = v34.AssemblyLinearVelocity;
        local math_sqrt_ret = math.sqrt(AssemblyLinearVelocity.X * AssemblyLinearVelocity.X + AssemblyLinearVelocity.Z * AssemblyLinearVelocity.Z);
        local v36;

        if is_grounded(v34) then
            if math_sqrt_ret < 1 then
                v36 = v35.idle;
            elseif math_sqrt_ret < u1 then
                v36 = v35.walk;
            else
                v36 = v35.run or v35.walk;
            end;
        else
            v36 = v35.fall;
        end;

        if v36 == nil then
            if math_sqrt_ret < 1 then
                v36 = v35.idle;
            else
                v36 = v35.walk;
            end;
        end;

        local idle = v35.idle;

        if idle then
            if idle == v36 then
                if not idle.IsPlaying then
                    idle:Play(0.2);
                end;
            elseif idle.IsPlaying then
                idle:Stop(0.2);
            end;
        end;

        local walk = v35.walk;

        if walk then
            if walk == v36 then
                if not walk.IsPlaying then
                    walk:Play(0.2);
                end;
            elseif walk.IsPlaying then
                walk:Stop(0.2);
            end;
        end;

        local run = v35.run;

        if run then
            if run == v36 then
                if not run.IsPlaying then
                    run:Play(0.2);
                end;
            elseif run.IsPlaying then
                run:Stop(0.2);
            end;
        end;

        local fall = v35.fall;

        if not fall then
            return;
        end;

        if fall == v36 then
            if not fall.IsPlaying then
                fall:Play(0.2);
            end;
        elseif fall.IsPlaying then
            fall:Stop(0.2);
        end;
    end;

    local function engage() -- Line: 325
        -- upvalues: u26 (copy), u27 (copy), u30 (ref), get_template_animation_id (ref), resolve_skin (ref), get_animate_clip_id (ref), load_track (ref), u29 (ref), suppress_foreign_locomotion (copy), u28 (ref), RunService (ref), step (copy)
        if u26.round_takeover_character == u27 then
            return;
        end;

        local v37 = u27;
        local v38 = v37:FindFirstChildWhichIsA("Humanoid") or v37:WaitForChild("Humanoid", 10);
        local v39;

        if v38 then
            v39 = v38:FindFirstChildWhichIsA("Animator") or v38:WaitForChild("Animator", 10);
        else
            v39 = nil;
        end;

        if not v39 or u27.Parent == nil then
            return;
        end;

        if not u30 then
            local v40 = get_template_animation_id("Walk");

            if not v40 then
                return;
            end;

            local v41 = get_template_animation_id("Run") or resolve_skin((u27:GetAttribute("equipped_skin"))).weapon.viewmodel.character_animations.sprint;
            local v42 = get_template_animation_id("Idle");
            local v43 = get_animate_clip_id(u27, "fall", "FallAnim");
            u30 = {
                idle = load_track(v39, v42 or "", Enum.AnimationPriority.Core, true),
                walk = load_track(v39, v40, Enum.AnimationPriority.Core, true),
                run = load_track(v39, v41 or "", Enum.AnimationPriority.Core, true),
                fall = load_track(v39, v43 or "", Enum.AnimationPriority.Core, true)
            };
        end;

        u26.round_takeover_character = u27;
        local Animate = u27:FindFirstChild("Animate");

        if Animate and Animate:IsA("LocalScript") then
            Animate.Disabled = true;
        end;

        if u29 then
            u29:Disconnect();
        end;

        u29 = v39.AnimationPlayed:Connect(suppress_foreign_locomotion);

        for _, v in v39:GetPlayingAnimationTracks() do
            local v44 = u30;

            if v44 then
                if v ~= v44.idle and (v ~= v44.walk and v ~= v44.run) then
                    if v ~= v44.fall then
                        if v.Priority == Enum.AnimationPriority.Core then
                            v:Stop(0);
                        end;
                    end;
                end;
            end;
        end;

        if u28 then
            u28:Disconnect();
        end;

        u28 = RunService.Heartbeat:Connect(step);
    end;

    local function disengage() -- Line: 381
        -- upvalues: u28 (ref), u29 (ref), u26 (copy), u27 (copy), u30 (ref)
        if u28 then
            u28:Disconnect();
            u28 = nil;
        end;

        if u29 then
            u29:Disconnect();
            u29 = nil;
        end;

        if u26.round_takeover_character ~= u27 then
            return;
        end;

        u26.round_takeover_character = nil;
        local v45 = u30;

        if v45 then
            local idle = v45.idle;

            if idle then
                if idle == nil then
                    if not idle.IsPlaying then
                        idle:Play(0.2);
                    end;
                elseif idle.IsPlaying then
                    idle:Stop(0.2);
                end;
            end;

            local walk = v45.walk;

            if walk then
                if walk == nil then
                    if not walk.IsPlaying then
                        walk:Play(0.2);
                    end;
                elseif walk.IsPlaying then
                    walk:Stop(0.2);
                end;
            end;

            local run = v45.run;

            if run then
                if run == nil then
                    if not run.IsPlaying then
                        run:Play(0.2);
                    end;
                elseif run.IsPlaying then
                    run:Stop(0.2);
                end;
            end;

            local fall = v45.fall;

            if fall then
                if fall == nil then
                    if not fall.IsPlaying then
                        fall:Play(0.2);
                    end;
                elseif fall.IsPlaying then
                    fall:Stop(0.2);
                end;
            end;
        end;

        local Animate = u27:FindFirstChild("Animate");

        if Animate and Animate:IsA("LocalScript") then
            Animate.Disabled = false;
        end;
    end;

    u27:GetAttributeChangedSignal("InRound"):Connect(function() -- Line: 410
        -- upvalues: u27 (copy), engage (copy), disengage (copy)
        if u27:GetAttribute("InRound") == true then
            engage();

            return;
        end;

        disengage();
    end);
    u27.Destroying:Connect(disengage);

    if u27:GetAttribute("InRound") == true then
        engage();
    end;
end;

function v5.equip(p46) -- Line: 426
    p46.equipped = true;
    p46:start_idle();
end;

function v5.unequip(p47) -- Line: 433
    p47.equipped = false;

    for _, v in p47.tracks do
        if v then
            v:Stop(0.1);
        end;
    end;
end;

function v5.start_idle(p48) -- Line: 447
    local idle = p48.tracks.idle;

    if not (p48.equipped and (idle and not idle.IsPlaying)) then
        return;
    end;

    idle:Play(0.2);
end;

function v5.play_shoot(u49) -- Line: 458
    local shoot = u49.tracks.shoot;

    if not (u49.equipped and shoot) then
        return;
    end;

    shoot:Play(0.05);
    shoot.TimePosition = 0;
    u49.shoot_generation = u49.shoot_generation + 1;
    local shoot_generation = u49.shoot_generation;
    task.delay(shoot.Length, function() -- Line: 470
        -- upvalues: u49 (copy), shoot_generation (copy)
        if u49.equipped and u49.shoot_generation == shoot_generation then
            u49:play_reload();
        end;
    end);
end;

function v5.play_reload(p50) -- Line: 479
    local reload = p50.tracks.reload;

    if not (p50.equipped and reload) then
        return;
    end;

    if reload.IsPlaying then
        reload:Stop(0);
    end;

    reload:Play(0);
end;

function v5.set_sliding(p51: any, p52: boolean) -- Line: 491
    local slide = p51.tracks.slide;

    if not slide then
        return;
    end;

    if p52 and p51.equipped then
        if not slide.IsPlaying then
            slide:Play(0.1);
        end;
    elseif slide.IsPlaying then
        slide:Stop(0.1);
    end;
end;

return v5;