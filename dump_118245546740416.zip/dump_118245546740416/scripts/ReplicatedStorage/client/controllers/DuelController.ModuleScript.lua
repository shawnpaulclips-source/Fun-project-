-- ReplicatedStorage.client.controllers.DuelController
-- class: ModuleScript
-- hash: 99bdacbb8b8cb845b8dbd44987a24cad1bf8c6cef906ae0b35fb1b4d88cbbb0dc212e11817b13168afc6a7ac3fbba376

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local StarterGui = game:GetService("StarterGui");
local DuelConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("game"):FindFirstChild("DuelConfig"));
local react_roblox = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("react_roblox"));
local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("duel"):FindFirstChild("types"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local match_place = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("matchmaking"):FindFirstChild("match_place"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local LocalPlayer = Players.LocalPlayer;

local function disable_reset_button() -- Line: 90
    -- upvalues: StarterGui (copy)
    for i = 1, 120 do
        if pcall(StarterGui.SetCore, StarterGui, "ResetButtonCallback", false) then
            return;
        end;

        task.wait(1);
        local _ = i;
    end;
end;

return {
    ModifierController = loader.use(require(script.Parent:FindFirstChild("ModifierController"))),

    init = function(p1) -- Line: 122, Name: init
        -- upvalues: signal (copy)
        p1.state = nil;
        p1.state_changed = signal();
        p1.summary = nil;
        p1.summary_changed = signal();
        p1.rematch = nil;
        p1.rematch_changed = signal();
        p1.kill_coins = signal();
        p1.edge_reached = signal();
        p1.lock_applied = false;
        p1.edge_threads = {};
        p1.round_ended = signal();
        p1.last_round_called = nil;
        p1.wait = nil;
        p1.wait_changed = signal();
        p1.client_ready_sent = false;
        p1.map_vote = nil;
        p1.map_vote_changed = signal();
    end,

    start = function(u2) -- Line: 145, Name: start
        -- upvalues: zap (copy), react_roblox (copy), match_place (copy), disable_reset_button (copy)
        zap.duel_state.set_callback(function(p3) -- Line: 146
            -- upvalues: u2 (copy), react_roblox (ref)
            local u4 = {
                phase = p3.phase,
                round = p3.round,
                score_a = p3.score_a,
                score_b = p3.score_b,
                go_at = p3.go_at,
                ends_at = p3.ends_at,
                reveal_from = p3.reveal_from,
                sudden_death = p3.sudden_death,
                last_outcome = p3.last_outcome,
                decided = p3.decided
            };
            local state = u2.state;
            u2.state = u4;
            local u5 = (u4.phase == "Waiting" or u4.phase == "MapVote") and true or u4.phase == "Intro";
            local u6;

            if u2.summary == nil then
                u6 = false;
            else
                u6 = u5;
            end;

            if u6 then
                u2.summary = nil;
                u2.last_round_called = nil;
            end;

            if u2.rematch == nil then
                u5 = false;
            end;

            if u5 then
                u2.rematch = nil;
            end;

            local u7;

            if u2.map_vote == nil then
                u7 = false;
            else
                u7 = (u4.phase == "Waiting" or u4.phase == "Intro") and true or u4.phase == "Ended";
            end;

            if u7 then
                u2.map_vote = nil;
            end;

            local u8;

            if u4.phase == "RoundEnd" then
                u8 = u4.round ~= u2.last_round_called;
            else
                u8 = false;
            end;

            if u8 then
                u2.last_round_called = u4.round;
            end;

            local sudden_death = u4.sudden_death;

            if sudden_death then
                if state then
                    state = state.sudden_death;
                end;

                sudden_death = not state;
            end;

            u2:schedule_edges(u4);
            u2:refresh_lock();
            react_roblox.unstable_batchedUpdates(function() -- Line: 194
                -- upvalues: u2 (ref), u4 (copy), u6 (copy), u5 (copy), u7 (copy), u8 (copy), sudden_death (copy)
                u2.state_changed:fire(u4);

                if u6 then
                    u2.summary_changed:fire(nil);
                end;

                if u5 then
                    u2.rematch_changed:fire(nil);
                end;

                if u7 then
                    u2.map_vote_changed:fire(nil);
                end;

                if u8 then
                    u2.round_ended:fire(u4, sudden_death == true);
                end;
            end);
        end);
        zap.match_summary.set_callback(function(p9) -- Line: 211
            -- upvalues: u2 (copy), react_roblox (ref)
            local u10 = {
                result = p9.result,
                forfeit = p9.forfeit,
                nc_reason = p9.nc_reason,
                score_a = p9.score_a,
                score_b = p9.score_b,
                rounds = p9.rounds,
                my_side = p9.my_side,
                opponent_id = p9.opponent_id,
                opponent_name = p9.opponent_name,
                kills = p9.kills,
                headshots = p9.headshots,
                opp_kills = p9.opp_kills,
                xp_earned = p9.xp_earned,
                coins_earned = p9.coins_earned,
                currency_id = p9.currency_id,
                currency_earned = p9.currency_earned,
                auto_exit_at = p9.auto_exit_at
            };
            u2.summary = u10;
            react_roblox.unstable_batchedUpdates(function() -- Line: 232
                -- upvalues: u2 (ref), u10 (copy)
                u2.summary_changed:fire(u10);
            end);
        end);
        zap.rematch_state.set_callback(function(p11) -- Line: 237
            -- upvalues: u2 (copy), react_roblox (ref)
            local u12 = {
                available = p11.available,
                votes = p11.votes,
                voted = p11.voted
            };
            u2.rematch = u12;
            react_roblox.unstable_batchedUpdates(function() -- Line: 244
                -- upvalues: u2 (ref), u12 (copy)
                u2.rematch_changed:fire(u12);
            end);
        end);
        zap.duel_map_vote.set_callback(function(p13) -- Line: 249
            -- upvalues: u2 (copy), react_roblox (ref)
            local v14 = {};

            for _, v in p13.options do
                local v15 = {
                    map = v.map,
                    voters = table.clone(v.voters)
                };
                table.insert(v14, v15);
            end;

            local u16 = {
                options = v14,
                ends_at = p13.ends_at,
                winner = p13.winner
            };
            u2.map_vote = u16;
            react_roblox.unstable_batchedUpdates(function() -- Line: 260
                -- upvalues: u2 (ref), u16 (copy)
                u2.map_vote_changed:fire(u16);
            end);
        end);
        zap.duel_kill_coins.set_callback(function(u17) -- Line: 265
            -- upvalues: react_roblox (ref), u2 (copy)
            react_roblox.unstable_batchedUpdates(function() -- Line: 266
                -- upvalues: u2 (ref), u17 (copy)
                u2.kill_coins:fire(u17.coins);
            end);
        end);
        zap.duel_wait.set_callback(function(p18) -- Line: 271
            -- upvalues: u2 (copy), react_roblox (ref)
            local v19 = {};
            local players = p18.players;

            if players then
                for _, v in players do
                    table.insert(v19, {
                        user_id = v.user_id,
                        phase = v.phase
                    });
                end;
            end;

            local u20 = {
                deadline = p18.deadline,
                players = v19
            };
            u2.wait = u20;
            react_roblox.unstable_batchedUpdates(function() -- Line: 284
                -- upvalues: u2 (ref), u20 (copy)
                u2.wait_changed:fire(u20);
            end);
        end);

        if match_place.is_match_place() then
            u2:watch_client_ready();
            task.spawn(disable_reset_button);
        end;

        zap.post_match_timer.set_callback(function(p21) -- Line: 294
            -- upvalues: u2 (copy), react_roblox (ref)
            local summary = u2.summary;

            if summary == nil then
                return;
            end;

            local table_clone_ret = table.clone(summary);
            table_clone_ret.auto_exit_at = p21.auto_exit_at;
            u2.summary = table_clone_ret;
            react_roblox.unstable_batchedUpdates(function() -- Line: 302
                -- upvalues: u2 (ref), table_clone_ret (copy)
                u2.summary_changed:fire(table_clone_ret);
            end);
        end);
    end,

    watch_client_ready = function(u22) -- Line: 310, Name: watch_client_ready
        -- upvalues: LocalPlayer (copy), zap (copy)
        local function try_send() -- Line: 311
            -- upvalues: u22 (copy), LocalPlayer (ref), zap (ref)
            if u22.client_ready_sent or LocalPlayer:GetAttribute("LoadingFadeStarted") ~= true then
                return;
            end;

            u22.client_ready_sent = true;
            zap.match_client_ready.fire();
        end;

        local u23 = nil;
        u23 = LocalPlayer:GetAttributeChangedSignal("LoadingFadeStarted"):Connect(function() -- Line: 319
            -- upvalues: u22 (copy), LocalPlayer (ref), zap (ref), u23 (ref)
            if not u22.client_ready_sent and LocalPlayer:GetAttribute("LoadingFadeStarted") == true then
                u22.client_ready_sent = true;
                zap.match_client_ready.fire();
            end;

            if u22.client_ready_sent then
                u23:Disconnect();
            end;
        end);

        if not u22.client_ready_sent and LocalPlayer:GetAttribute("LoadingFadeStarted") == true then
            u22.client_ready_sent = true;
            zap.match_client_ready.fire();
        end;

        if u22.client_ready_sent then
            u23:Disconnect();
        end;
    end,

    cast_map_vote = function(p24: any, p25: string) -- Line: 333, Name: cast_map_vote
        -- upvalues: zap (copy)
        zap.cast_duel_vote.fire(p25);
    end,

    is_movement_locked = function(p26) -- Line: 341, Name: is_movement_locked
        local state = p26.state;

        if state == nil then
            return false;
        end;

        local phase = state.phase;

        if phase == "Intro" or phase == "Spawning" then
            return true;
        end;

        if phase ~= "Countdown" then
            return false;
        end;

        local go_at = state.go_at;

        return go_at == nil and true or workspace:GetServerTimeNow() < go_at;
    end,

    is_fire_locked = function(p27) -- Line: 360, Name: is_fire_locked
        local state = p27.state;

        if state == nil then
            return false;
        end;

        local phase = state.phase;

        if phase == "Live" or phase == "Settle" then
            return false;
        end;

        if phase ~= "Countdown" then
            return true;
        end;

        local go_at = state.go_at;

        return go_at == nil and true or workspace:GetServerTimeNow() < go_at;
    end,

    is_reveal_active = function(p28) -- Line: 379, Name: is_reveal_active
        local state = p28.state;

        if state == nil then
            return false;
        end;

        local ServerTimeNow = workspace:GetServerTimeNow();
        local phase = state.phase;

        if phase == "Countdown" then
            local v29;

            if state.go_at == nil then
                v29 = false;
            else
                v29 = ServerTimeNow < state.go_at;
            end;

            return v29;
        end;

        if phase ~= "Live" and phase ~= "Settle" then
            return false;
        end;

        if state.sudden_death then
            return true;
        end;

        local v30;

        if phase == "Live" and state.reveal_from ~= nil then
            v30 = state.reveal_from <= ServerTimeNow;
        else
            v30 = false;
        end;

        return v30;
    end,

    get_local_side = function(p31) -- Line: 399, Name: get_local_side
        -- upvalues: LocalPlayer (copy), DuelConfig (copy)
        local Attribute = LocalPlayer:GetAttribute(DuelConfig.player_attr_side);

        if Attribute == "A" or Attribute == "B" then
            return Attribute;
        end;

        return nil;
    end,

    schedule_edges = function(p32: any, p33: table) -- Line: 409, Name: schedule_edges
        for _, v in p32.edge_threads do
            task.cancel(v);
        end;

        table.clear(p32.edge_threads);

        for _, v in { p33.go_at, p33.reveal_from } do
            if v then
                p32:schedule_edge(v);
            end;
        end;
    end,

    schedule_edge = function(u34: any, u35: number) -- Line: 423, Name: schedule_edge
        local v36 = u35 - workspace:GetServerTimeNow();

        if v36 <= 0 then
            return;
        end;

        table.insert(u34.edge_threads, task.delay(v36, function() -- Line: 430
            -- upvalues: u35 (copy), u34 (copy)
            if workspace:GetServerTimeNow() < u35 then
                u34:schedule_edge(u35);

                return;
            end;

            u34:refresh_lock();
            u34.edge_reached:fire();
        end));
    end,

    refresh_lock = function(p37) -- Line: 443, Name: refresh_lock
        local v38 = p37:is_movement_locked();

        if v38 == p37.lock_applied then
            return;
        end;

        p37.lock_applied = v38;
        p37.ModifierController:set_modifier("WalkSpeed", "duel_lock", v38 and 0 or nil, 1000);
    end
};