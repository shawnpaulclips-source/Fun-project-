-- ReplicatedStorage.client.controllers.CombatHighlightController
-- class: ModuleScript
-- hash: 35bcc4bb8ec4f2a10a8d942bad93648dc468bd7ddf687255f4f269c0760c8b19cf54eb30a15c12bf2613e21150b85e48

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local BountyConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("BountyConfig"));
local DuelConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("game"):FindFirstChild("DuelConfig"));
local is_spawn_protected_visual = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("is_spawn_protected_visual"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local match_place = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("matchmaking"):FindFirstChild("match_place"));
local vfx_allowed = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("vfx_allowed"));
local LocalPlayer = Players.LocalPlayer;

local function is_character_alive(p1: userdata) -- Line: 37
    local v2 = p1:FindFirstChildWhichIsA("Humanoid");

    return not v2 and true or v2.Health > 0;
end;

local function get_root_position(p3: userdata) -- Line: 45
    local HumanoidRootPart = p3:FindFirstChild("HumanoidRootPart");

    if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
        return HumanoidRootPart.Position;
    end;

    return nil;
end;

local function apply_style(p4: userdata, p5: string) -- Line: 53
    -- upvalues: DuelConfig (copy), BountyConfig (copy)
    if p5 == "reveal" then
        p4.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop;
        p4.FillColor = DuelConfig.reveal_fill_color;
        p4.FillTransparency = DuelConfig.reveal_fill_transparency;
        p4.OutlineColor = DuelConfig.reveal_outline_color;
        p4.OutlineTransparency = DuelConfig.reveal_outline_transparency;

        return;
    end;

    local v6;

    if p5 == "rival" then
        v6 = BountyConfig.RIVAL_HIGHLIGHT;
    else
        v6 = BountyConfig.BOUNTY_HIGHLIGHT;
    end;

    local v7;

    if p5 == "rival" then
        v7 = Enum.HighlightDepthMode.AlwaysOnTop;
    else
        v7 = Enum.HighlightDepthMode.Occluded;
    end;

    p4.DepthMode = v7;
    p4.FillColor = v6.fill_color;
    p4.FillTransparency = v6.fill_transparency;
    p4.OutlineColor = v6.outline_color;
    p4.OutlineTransparency = v6.outline_transparency;
end;

return {
    BountyController = loader.use(require(script.Parent:FindFirstChild("BountyController"))),
    DuelController = loader.use(require(script.Parent:FindFirstChild("DuelController"))),
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),
    SpectateController = loader.use(require(script.Parent:FindFirstChild("SpectateController"))),

    init = function(p8) -- Line: 82, Name: init
        p8.highlights = {};
        p8.kinds = {};
        p8.death_connections = {};
        p8.accumulator = 0;
        p8.dirty = false;
    end,

    start = function(u9) -- Line: 90, Name: start
        -- upvalues: RunService (copy)
        u9.BountyController.marks_changed:connect(function() -- Line: 91
            -- upvalues: u9 (copy)
            u9.dirty = true;
        end);
        u9.GameStateController.life_state_changed:connect(function() -- Line: 94
            -- upvalues: u9 (copy)
            u9.dirty = true;
        end);
        u9.DuelController.state_changed:connect(function() -- Line: 98
            -- upvalues: u9 (copy)
            u9.dirty = true;
        end);
        u9.DuelController.edge_reached:connect(function() -- Line: 101
            -- upvalues: u9 (copy)
            u9.dirty = true;
        end);
        RunService.Heartbeat:Connect(function(p10: number) -- Line: 105
            -- upvalues: u9 (copy)
            local v11 = u9;
            v11.accumulator = v11.accumulator + p10;

            if u9.dirty or u9.accumulator >= 0.2 then
                u9.accumulator = 0;
                u9.dirty = false;
                u9:update_highlights();
            end;
        end);
    end,

    is_eligible = function(p12: any, p13: userdata) -- Line: 117, Name: is_eligible
        -- upvalues: LocalPlayer (copy), is_spawn_protected_visual (copy)
        if p13 == LocalPlayer.Character or not p13:IsDescendantOf(workspace) then
            return false;
        end;

        local SpectateController = p12.SpectateController;

        if SpectateController.spectating and SpectateController.target_character == p13 then
            return false;
        end;

        local v14;

        if p13:GetAttribute("InRound") == true then
            local v15 = p13:FindFirstChildWhichIsA("Humanoid");
            v14 = (not v15 and true or v15.Health > 0) and not is_spawn_protected_visual(p13);
        else
            v14 = false;
        end;

        return v14;
    end,

    update_highlights = function(p16) -- Line: 133, Name: update_highlights
        -- upvalues: match_place (copy), Players (copy), BountyConfig (copy), DuelConfig (copy), LocalPlayer (copy), vfx_allowed (copy), apply_style (copy)
        local BountyController = p16.BountyController;
        local v17 = {};
        local v18 = 0;
        local _life_state = p16.GameStateController:get_life_state();
        local v19 = _life_state == "Deployed" and true or _life_state == "Spectating";

        if v19 and (match_place.is_match_place() and p16.DuelController:is_reveal_active()) then
            local _local_side = p16.DuelController:get_local_side();

            for _, v in Players:GetPlayers() do
                if BountyConfig.MAX_HIGHLIGHTS <= v18 then
                    break;
                end;

                local Attribute = v:GetAttribute(DuelConfig.player_attr_side);
                local Character = v.Character;

                if v ~= LocalPlayer and (_local_side ~= nil and (Attribute ~= nil and (Attribute ~= _local_side and (Character and p16:is_eligible(Character))))) then
                    v17[Character] = "reveal";
                    v18 = v18 + 1;
                end;
            end;
        end;

        for i in not v19 and {} or BountyController.rivals do
            if BountyConfig.MAX_HIGHLIGHTS <= v18 then
                break;
            end;

            local v20 = BountyController:resolve_character(i);

            if v20 and (not v17[v20] and p16:is_eligible(v20)) then
                v17[v20] = "rival";
                v18 = v18 + 1;
            end;
        end;

        if v19 and (v18 < BountyConfig.MAX_HIGHLIGHTS and (next(BountyController.bounty_bodies) ~= nil and vfx_allowed())) then
            local workspace_CurrentCamera = workspace.CurrentCamera;
            local v21 = not workspace_CurrentCamera and Vector3.new(0, 0, 0) or workspace_CurrentCamera.CFrame.Position;
            local v22 = {};

            for i in BountyController.bounty_bodies do
                if not v17[i] and p16:is_eligible(i) then
                    local HumanoidRootPart = i:FindFirstChild("HumanoidRootPart");
                    local v23;

                    if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
                        v23 = HumanoidRootPart.Position;
                    else
                        v23 = nil;
                    end;

                    if v23 then
                        table.insert(v22, {
                            character = i,
                            distance = (v23 - v21).Magnitude
                        });
                    end;
                end;
            end;

            table.sort(v22, function(p24: table, p25: table) -- Line: 201
                return p24.distance < p25.distance;
            end);

            for _, v in v22 do
                if BountyConfig.MAX_HIGHLIGHTS <= v18 then
                    break;
                end;

                v17[v.character] = "bounty";
                v18 = v18 + 1;
            end;
        end;

        local v26 = {};

        for i in p16.highlights do
            if not v17[i] then
                table.insert(v26, i);
            end;
        end;

        for _, v in v26 do
            p16:release_highlight(v);
        end;

        for i, v in v17 do
            local v27 = p16.highlights[i];

            if v27 then
                if p16.kinds[i] ~= v then
                    apply_style(v27, v);
                    p16.kinds[i] = v;
                end;
            else
                p16:apply_highlight(i, v);
            end;
        end;
    end,

    apply_highlight = function(u28: any, u29: userdata, p30: string) -- Line: 235, Name: apply_highlight
        -- upvalues: apply_style (copy)
        local Highlight = Instance.new("Highlight");
        Highlight.Name = "CombatHighlight";
        apply_style(Highlight, p30);
        Highlight.Adornee = u29;
        Highlight.Parent = u29;
        u28.highlights[u29] = Highlight;
        u28.kinds[u29] = p30;
        local v31 = u29:FindFirstChildWhichIsA("Humanoid");

        if v31 then
            u28.death_connections[u29] = v31.Died:Connect(function() -- Line: 250
                -- upvalues: u28 (copy), u29 (copy)
                u28:release_highlight(u29);
            end);
        end;
    end,

    release_highlight = function(p32: any, p33: userdata) -- Line: 257, Name: release_highlight
        local v34 = p32.highlights[p33];

        if v34 then
            v34:Destroy();
            p32.highlights[p33] = nil;
        end;

        p32.kinds[p33] = nil;
        local v35 = p32.death_connections[p33];

        if v35 then
            v35:Disconnect();
            p32.death_connections[p33] = nil;
        end;
    end
};