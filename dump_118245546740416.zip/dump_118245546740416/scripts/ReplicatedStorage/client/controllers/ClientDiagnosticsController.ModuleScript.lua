-- ReplicatedStorage.client.controllers.ClientDiagnosticsController
-- class: ModuleScript
-- hash: 21e5d82ec4f5146348146d9b5830491bd60cfab9e260939a62dcac094a470fbb727d3e47904f82944181ea7596e56bea

-- Decompiled with Potassium's decompiler.

local diagnostic_probes = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("diagnostic_probes"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local debug_info = debug.info;

local function read_info(p1) -- Line: 20
    -- upvalues: debug_info (copy)
    local v2, v3, v4 = pcall(debug_info, p1, "sl");

    if v2 then
        return v3, v4;
    end;

    return nil, nil;
end;

return {
    WeaponController = loader.use(require(script.Parent:FindFirstChild("WeaponController"))),
    CameraController = loader.use(require(script.Parent:FindFirstChild("CameraController"))),
    AimAssistController = loader.use(require(script.Parent:FindFirstChild("AimAssistController"))),

    init = function(u5) -- Line: 34, Name: init
        -- upvalues: zap (copy)
        u5.readers = {
            ["weapon.request_fire"] = function() -- Line: 36
                -- upvalues: u5 (copy)
                return u5.WeaponController.request_fire;
            end,

            ["weapon.get_shot_cooldown"] = function() -- Line: 39
                -- upvalues: u5 (copy)
                return u5.WeaponController.get_shot_cooldown;
            end,

            ["weapon.compute_effective_radius"] = function() -- Line: 42
                -- upvalues: u5 (copy)
                return u5.WeaponController.compute_effective_radius;
            end,

            ["weapon.compute_player_radius"] = function() -- Line: 45
                -- upvalues: u5 (copy)
                return u5.WeaponController.compute_player_radius;
            end,

            ["weapon.compute_bot_radius"] = function() -- Line: 48
                -- upvalues: u5 (copy)
                return u5.WeaponController.compute_bot_radius;
            end,

            ["weapon.has_target_in_crosshair"] = function() -- Line: 51
                -- upvalues: u5 (copy)
                return u5.WeaponController.has_target_in_crosshair;
            end,

            ["camera.add_recoil"] = function() -- Line: 54
                -- upvalues: u5 (copy)
                return u5.CameraController.add_recoil;
            end,

            ["camera.get_look_cframe"] = function() -- Line: 57
                -- upvalues: u5 (copy)
                return u5.CameraController.get_look_cframe;
            end,

            ["camera.step"] = function() -- Line: 60
                -- upvalues: u5 (copy)
                return u5.CameraController.step;
            end,

            ["aim.adjust"] = function() -- Line: 63
                -- upvalues: u5 (copy)
                return u5.AimAssistController.adjust;
            end,

            ["net.shoot"] = function() -- Line: 66
                -- upvalues: zap (ref)
                return zap.shoot.fire;
            end
        };
        u5.snapshots = {};
        u5.reported = {};
    end,

    start = function(u6) -- Line: 74, Name: start
        -- upvalues: diagnostic_probes (copy), debug_info (copy)
        for i, v in diagnostic_probes.LABELS do
            local v7 = u6.readers[v];
            local v8 = `ClientDiagnosticsController: no reader for probe "{v}"`;
            assert(v7 ~= nil, v8);
            local v9 = v7();
            local v10, v11, v12 = pcall(debug_info, v9, "sl");

            if not v10 then
                v11 = nil;
                v12 = nil;
            end;

            u6.snapshots[i] = {
                ref = v9,
                source = v11,
                line = v12
            };
        end;

        task.spawn(function() -- Line: 84
            -- upvalues: u6 (copy)
            while true do
                task.wait(5);
                u6:probe_all();
            end;
        end);
    end,

    probe_all = function(p13) -- Line: 94, Name: probe_all
        -- upvalues: diagnostic_probes (copy), debug_info (copy), zap (copy)
        for i, v in diagnostic_probes.LABELS do
            if not p13.reported[i] then
                local v14 = p13.snapshots[i];
                local v15 = p13.readers[v]();
                local v16 = nil;

                if v15 == v14.ref then
                    local v17, v18, v19 = pcall(debug_info, v15, "sl");

                    if not v17 then
                        v18 = nil;
                        v19 = nil;
                    end;

                    if v18 ~= v14.source or v19 ~= v14.line then
                        v16 = diagnostic_probes.CODE_HOOKED;
                    end;
                else
                    v16 = diagnostic_probes.CODE_REPLACED;
                end;

                if v16 ~= nil then
                    p13.reported[i] = true;
                    pcall(zap.client_diagnostics.fire, {
                        probe = i,
                        code = v16
                    });
                end;
            end;
        end;
    end
};