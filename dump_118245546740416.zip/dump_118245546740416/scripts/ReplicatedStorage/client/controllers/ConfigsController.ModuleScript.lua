-- ReplicatedStorage.client.controllers.ConfigsController
-- class: ModuleScript
-- hash: 1b629aae16c81b61f35ccbbfbbacfcf1c517e3901791fdab0f0c8d97a34c4e039589faf3b7595da28ed24236833c2b02

-- Decompiled with Potassium's decompiler.

local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 6, Name: init
        -- upvalues: signal (copy)
        p1.live_data = {};
        p1.config_changed = signal();
    end,

    start = function(u2) -- Line: 11, Name: start
        -- upvalues: zap (copy)
        zap.replicate_live_configs.set_callback(function(p3: table) -- Line: 12
            -- upvalues: u2 (copy)
            local live_data = u2.live_data;
            u2.live_data = p3;

            for i, v in p3 do
                if live_data[i] ~= v then
                    u2.config_changed:fire(i, v);
                end;
            end;
        end);
    end,

    get_value = function(p4: any, p5: string) -- Line: 26, Name: get_value
        return p4.live_data[p5];
    end
};