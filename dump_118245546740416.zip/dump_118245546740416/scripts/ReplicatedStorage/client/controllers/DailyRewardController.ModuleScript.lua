-- ReplicatedStorage.client.controllers.DailyRewardController
-- class: ModuleScript
-- hash: 736e82c52bf14485f69d0b12bf15698241568a066c835489b0d449dd1466c6c1abb9236072ca268902884a72a19c6d63

-- Decompiled with Potassium's decompiler.

local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 16, Name: init
        p1.claiming = false;
    end,

    start = function(p2) -- Line: 20, Name: start
    end,

    claim_day = function(p3) -- Line: 26, Name: claim_day
        -- upvalues: zap (copy)
        if p3.claiming then
            return {
                ok = false,
                error = "busy"
            };
        end;

        p3.claiming = true;
        local v4 = zap.claim_daily_reward.call();
        p3.claiming = false;

        return v4;
    end
};