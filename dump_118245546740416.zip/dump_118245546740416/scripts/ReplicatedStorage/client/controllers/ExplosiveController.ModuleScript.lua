-- ReplicatedStorage.client.controllers.ExplosiveController
-- class: ModuleScript
-- hash: 4240c502dec7cec979b6bedbe6fea5fdf09b7ccf4bd600add48bef56a22707bb8d51f03bbdc4fc952c01480a599adfc7

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local ContentProvider = game:GetService("ContentProvider");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local explosive_tag = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("combat"):FindFirstChild("explosive_tag"));
local ExplosiveConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("combat"):FindFirstChild("ExplosiveConfig"));
local emit_vfx = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("emit_vfx"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local play_vfx = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("play_vfx"));
local vfx_allowed = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("vfx_allowed"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local Color3_fromRGB_ret = Color3.fromRGB(18, 16, 15);

local function get_vfx_template() -- Line: 56
    -- upvalues: ReplicatedStorage (copy), ExplosiveConfig (copy)
    local assets = ReplicatedStorage:FindFirstChild("assets");
    local v1;

    if assets then
        v1 = assets:FindFirstChild("vfx");
    else
        v1 = nil;
    end;

    if v1 then
        return v1:FindFirstChild(ExplosiveConfig.vfx_name);
    end;

    return nil;
end;

return {
    SoundsController = loader.use(require(script.Parent:FindFirstChild("SoundsController"))),

    init = function(p2) -- Line: 65, Name: init
        p2.debris_folder = nil;
        p2.barrel_fx = {};
    end,

    start = function(u3) -- Line: 70, Name: start
        -- upvalues: zap (copy), CollectionService (copy), explosive_tag (copy), ReplicatedStorage (copy), ExplosiveConfig (copy), ContentProvider (copy)
        zap.explosive_triggered.set_callback(function(p4) -- Line: 71
            -- upvalues: u3 (copy)
            u3:on_explosive_triggered(p4);
        end);
        CollectionService:GetInstanceAddedSignal(explosive_tag):Connect(function(p5: userdata) -- Line: 77
            -- upvalues: u3 (copy)
            if p5:IsA("Model") then
                u3:inject_barrel_fx(p5);
            end;
        end);

        for _, v in CollectionService:GetTagged(explosive_tag) do
            if v:IsA("Model") then
                task.defer(function() -- Line: 85
                    -- upvalues: u3 (copy), v (copy)
                    u3:inject_barrel_fx(v);
                end);
            end;
        end;

        task.spawn(function() -- Line: 93
            -- upvalues: ReplicatedStorage (ref), ExplosiveConfig (ref), ContentProvider (ref)
            local assets = ReplicatedStorage:FindFirstChild("assets");
            local v6;

            if assets then
                v6 = assets:FindFirstChild("vfx");
            else
                v6 = nil;
            end;

            local u7;

            if v6 then
                u7 = v6:FindFirstChild(ExplosiveConfig.vfx_name);
            else
                u7 = nil;
            end;

            if u7 then
                pcall(function() -- Line: 96
                    -- upvalues: ContentProvider (ref), u7 (copy)
                    ContentProvider:PreloadAsync({ u7 });
                end);
            end;
        end);
    end,

    inject_barrel_fx = function(u8: any, u9: userdata) -- Line: 108, Name: inject_barrel_fx
        -- upvalues: ReplicatedStorage (copy), ExplosiveConfig (copy)
        if u8.barrel_fx[u9] then
            return;
        end;

        local PrimaryPart = u9.PrimaryPart;

        if not PrimaryPart then
            return;
        end;

        local assets = ReplicatedStorage:FindFirstChild("assets");
        local v10;

        if assets then
            v10 = assets:FindFirstChild("vfx");
        else
            v10 = nil;
        end;

        local v11;

        if v10 then
            v11 = v10:FindFirstChild(ExplosiveConfig.vfx_name);
        else
            v11 = nil;
        end;

        if not v11 then
            return;
        end;

        local Part = Instance.new("Part");
        Part.Name = "__BarrelFx";
        Part.Anchored = true;
        Part.Transparency = 1;
        Part.CanCollide = false;
        Part.CanQuery = false;
        Part.CanTouch = false;
        Part.Massless = true;
        Part.Size = Vector3.new(1, 1, 1);
        Part.CFrame = PrimaryPart.CFrame;
        Part.Parent = PrimaryPart;
        local v12 = u8.SoundsController:attach_resident_sound(Part, ExplosiveConfig.sound_name);
        local v13 = v11:Clone();

        if v13:IsA("Attachment") then
            v13.Parent = Part;
            v13.WorldPosition = PrimaryPart.Position;
        elseif v13:IsA("BasePart") then
            v13.Anchored = true;
            v13.CFrame = PrimaryPart.CFrame;
            v13.Parent = Part;
        elseif v13:IsA("PVInstance") then
            v13:PivotTo(PrimaryPart.CFrame);
            v13.Parent = Part;
        else
            v13.Parent = Part;
        end;

        for _, descendant in v13:GetDescendants() do
            if descendant:IsA("ParticleEmitter") or (descendant:IsA("Beam") or descendant:IsA("Light")) then
                descendant.Enabled = false;
            end;
        end;

        u8.barrel_fx[u9] = {
            sound = v12,
            vfx_container = Part
        };
        local u14 = nil;
        u14 = u9.Destroying:Connect(function() -- Line: 167
            -- upvalues: u8 (copy), u9 (copy), u14 (ref)
            u8.barrel_fx[u9] = nil;
            u14:Disconnect();
        end);
    end,

    on_explosive_triggered = function(p15: any, p16: table) -- Line: 177, Name: on_explosive_triggered
        -- upvalues: vfx_allowed (copy), emit_vfx (copy), ReplicatedStorage (copy), ExplosiveConfig (copy), play_vfx (copy), Color3_fromRGB_ret (copy), Debris (copy)
        local model = p16.model;

        if not (model and model:IsA("Model")) then
            model = nil;
        end;

        local v17;

        if model then
            v17 = p15.barrel_fx[model];
        else
            v17 = nil;
        end;

        if v17 then
            v17.sound:Play();

            if vfx_allowed() then
                emit_vfx(v17.vfx_container);
            end;
        else
            local assets = ReplicatedStorage:FindFirstChild("assets");
            local v18;

            if assets then
                v18 = assets:FindFirstChild("vfx");
            else
                v18 = nil;
            end;

            local v19;

            if v18 then
                v19 = v18:FindFirstChild(ExplosiveConfig.vfx_name);
            else
                v19 = nil;
            end;

            if v19 then
                play_vfx(v19, p16.position, {
                    lifetime = 2
                });
            end;

            p15.SoundsController:play_sound({
                sound = ExplosiveConfig.sound_name,
                position = p16.position
            });
        end;

        if not model then
            return;
        end;

        if not model.PrimaryPart then
            return;
        end;

        local v20 = model:Clone();
        local __BarrelFx = v20:FindFirstChild("__BarrelFx", true);

        if __BarrelFx then
            __BarrelFx:Destroy();
        end;

        local PrimaryPart = v20.PrimaryPart;

        if not PrimaryPart then
            v20:Destroy();

            return;
        end;

        for _, descendant in model:GetDescendants() do
            if descendant:IsA("BasePart") then
                descendant.LocalTransparencyModifier = 1;
            elseif descendant:IsA("Decal") then
                descendant.Transparency = 1;
            end;
        end;

        local _debris_folder = p15:get_debris_folder();

        for _, descendant in v20:GetDescendants() do
            if descendant:IsA("BasePart") then
                descendant.Anchored = false;
                descendant.Color = Color3_fromRGB_ret;
                descendant.Reflectance = 0;
                descendant.CanQuery = false;
                descendant.CanTouch = false;

                if descendant == PrimaryPart then
                    descendant.CanCollide = true;
                    pcall(function() -- Line: 249
                        -- upvalues: descendant (copy)
                        descendant.CollisionGroup = "Characters";
                    end);
                else
                    descendant.CanCollide = false;
                end;
            elseif descendant:IsA("Decal") then
                descendant:Destroy();
            end;
        end;

        v20.Parent = _debris_folder;
        local Vector3_new_ret = Vector3.new(p16.hit_direction.X, 0, p16.hit_direction.Z);
        local v21 = Vector3_new_ret.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or Vector3_new_ret.Unit;
        local v22 = ExplosiveConfig.barrel_out_speed * 0.3;
        local v23 = (math.random() * 2 - 1) * v22;
        local v24 = (math.random() * 2 - 1) * v22;
        local Vector3_new_ret2 = Vector3.new(v23, 0, v24);
        PrimaryPart.AssemblyLinearVelocity = Vector3.new(0, 1, 0) * ExplosiveConfig.barrel_up_speed + v21 * ExplosiveConfig.barrel_out_speed + Vector3_new_ret2;
        local v25 = (math.random() * 2 - 1) * ExplosiveConfig.barrel_spin_speed;
        local v26 = (math.random() * 2 - 1) * ExplosiveConfig.barrel_spin_speed;
        local v27 = (math.random() * 2 - 1) * ExplosiveConfig.barrel_spin_speed;
        PrimaryPart.AssemblyAngularVelocity = Vector3.new(v25, v26, v27);
        local Attachment = Instance.new("Attachment");
        Attachment.Parent = PrimaryPart;
        local VectorForce = Instance.new("VectorForce");
        VectorForce.Attachment0 = Attachment;
        VectorForce.RelativeTo = Enum.ActuatorRelativeTo.World;
        VectorForce.ApplyAtCenterOfMass = true;
        VectorForce.Force = Vector3.new(0, PrimaryPart.AssemblyMass * workspace.Gravity * ExplosiveConfig.barrel_float_gravity_cancel, 0);
        VectorForce.Parent = PrimaryPart;
        task.delay(ExplosiveConfig.barrel_float_duration, function() -- Line: 292
            -- upvalues: VectorForce (copy), Attachment (copy)
            VectorForce:Destroy();
            Attachment:Destroy();
        end);
        task.delay(ExplosiveConfig.barrel_collide_time, function() -- Line: 299
            -- upvalues: PrimaryPart (copy)
            if PrimaryPart.Parent then
                PrimaryPart.CanCollide = false;
            end;
        end);
        Debris:AddItem(v20, ExplosiveConfig.barrel_despawn_time);
    end,

    get_debris_folder = function(p28) -- Line: 309, Name: get_debris_folder
        local debris_folder = p28.debris_folder;

        if debris_folder and debris_folder.Parent then
            return debris_folder;
        end;

        local Folder = Instance.new("Folder");
        Folder.Name = "ExplosiveDebris";
        Folder.Parent = workspace;
        p28.debris_folder = Folder;

        return Folder;
    end
};