-- ReplicatedStorage.client.controllers.CensusController
-- class: ModuleScript
-- hash: 0fdee42ebcca401ab40bc6b6b50fbb5a37bead30c48c08139ab619ae997eb1b5af4fb6eee656ef98b60745b5cbb95a25

-- Decompiled with Potassium's decompiler.

local signal = require(game:GetService("ReplicatedStorage"):FindFirstChild("packages"):FindFirstChild("signal"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));

return {
    init = function(p1) -- Line: 6, Name: init
        -- upvalues: signal (copy)
        p1.counts = {};
        p1.counts_changed = signal();
        p1.cache_ttl_seconds = 60;
    end,

    start = function(u2) -- Line: 12, Name: start
        -- upvalues: zap (copy)
        zap.replicate_census_counts.set_callback(function(p3) -- Line: 13
            -- upvalues: u2 (copy)
            for i, v in p3 do
                if type(v) == "table" then
                    local v4 = i;

                    for i2, v2 in v do
                        if type(v2) == "number" then
                            u2:update_cache(v4, i2, v2);
                        end;
                    end;
                end;
            end;
        end);
    end,

    update_cache = function(p5: any, p6: string, p7: string, p8: number) -- Line: 29, Name: update_cache
        local v9 = p5.counts[p6];

        if not v9 then
            v9 = {};
            p5.counts[p6] = v9;
        end;

        v9[p7] = {
            value = p8,
            expires_at = os.time() + p5.cache_ttl_seconds
        };
        p5.counts_changed:fire(p6, p7, p8);
    end,

    get_cached_count = function(p10: any, p11: string, p12: string) -- Line: 43, Name: get_cached_count
        local v13 = p10.counts[p11];

        if not v13 then
            return nil;
        end;

        local v14 = v13[p12];

        if not v14 then
            return nil;
        end;

        if os.time() >= v14.expires_at then
            return nil;
        end;

        return v14.value;
    end,

    request_count = function(p15: any, p16: string, p17: string) -- Line: 63, Name: request_count
        -- upvalues: zap (copy)
        local _cached_count = p15:get_cached_count(p16, p17);

        if _cached_count ~= nil then
            return _cached_count;
        end;

        local v18 = zap.request_census_count.call(p16, p17);

        if v18 == nil then
            return nil;
        end;

        p15:update_cache(p16, p17, v18);

        return v18;
    end
};