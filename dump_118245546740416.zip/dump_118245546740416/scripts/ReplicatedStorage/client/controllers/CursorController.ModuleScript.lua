-- ReplicatedStorage.client.controllers.CursorController
-- class: ModuleScript
-- hash: 0053d0970188b5e1308af950a4e198d6559a3cf7b7a9110c1a7079b762d2e6718ba4b923562ac4cb6a718d90808bf0f2

-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local u1 = { Enum.KeyCode.Tab, Enum.KeyCode.LeftAlt, Enum.KeyCode.ButtonSelect };

return {
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),

    init = function(p2) -- Line: 22, Name: init
        p2.unlocked = false;
        p2.last_behavior = nil;
        p2.relocked = false;
        p2.editor_free = false;
        p2.modal_free = false;
    end,

    start = function(u3) -- Line: 39, Name: start
        -- upvalues: UserInputService (copy), u1 (copy), RunService (copy)
        UserInputService.InputBegan:Connect(function(p4: userdata) -- Line: 42
            -- upvalues: u1 (ref), u3 (copy)
            for _, v in u1 do
                if p4.KeyCode == v then
                    u3:set_unlocked(true);

                    return;
                end;
            end;
        end);
        UserInputService.InputEnded:Connect(function(p5: userdata) -- Line: 51
            -- upvalues: u1 (ref), u3 (copy)
            for _, v in u1 do
                if p5.KeyCode == v then
                    u3:set_unlocked(false);

                    return;
                end;
            end;
        end);
        UserInputService.WindowFocusReleased:Connect(function() -- Line: 61
            -- upvalues: u3 (copy)
            u3:set_unlocked(false);
        end);
        RunService:BindToRenderStep("FpsCursorUnlock", Enum.RenderPriority.Camera.Value + 2, function() -- Line: 65
            -- upvalues: u3 (copy)
            u3:apply();
        end);
    end,

    set_unlocked = function(p6: any, p7: boolean) -- Line: 71, Name: set_unlocked
        if p7 == p6.unlocked then
            return;
        end;

        p6.unlocked = p7;
    end,

    set_editor_free = function(p8: any, p9: boolean) -- Line: 80, Name: set_editor_free
        p8.editor_free = p9;
    end,

    set_modal_free = function(p10: any, p11: boolean) -- Line: 86, Name: set_modal_free
        p10.modal_free = p11;
    end,

    consume_relock = function(p12) -- Line: 93, Name: consume_relock
        if not p12.relocked then
            return false;
        end;

        p12.relocked = false;

        return true;
    end,

    apply = function(p13) -- Line: 106, Name: apply
        -- upvalues: UserInputService (copy)
        local GameStateController = p13.GameStateController;
        local v14 = not (GameStateController.is_in_game or GameStateController.match_view_held) or p13.unlocked or (p13.editor_free or p13.modal_free);
        local v15;

        if v14 then
            v15 = Enum.MouseBehavior.Default;
        else
            v15 = Enum.MouseBehavior.LockCenter;
        end;

        if v15 == Enum.MouseBehavior.LockCenter or v15 ~= p13.last_behavior then
            if v15 == Enum.MouseBehavior.LockCenter and p13.last_behavior ~= Enum.MouseBehavior.LockCenter then
                p13.relocked = true;
            end;

            UserInputService.MouseBehavior = v15;
            UserInputService.MouseIconEnabled = v14;
            p13.last_behavior = v15;
        end;
    end
};