-- ReplicatedStorage.client.controllers.AutoShootController
-- class: ModuleScript
-- hash: 4a448f232ed14d0d76342145e0db31c51802be934c8c686a40913fddcb403feb48b19dcc8dce8f38891bb87448848c4a

-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("game"):FindFirstChild("types"));
local get_last_input_category = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("get_last_input_category"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local WeaponConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("weapons"):FindFirstChild("WeaponConfig"));

return {
    WeaponController = loader.use(require(script.Parent:FindFirstChild("WeaponController"))),
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),
    SettingsController = loader.use(require(script.Parent:FindFirstChild("SettingsController"))),
    MobileControlsController = loader.use(require(script.Parent:FindFirstChild("MobileControlsController"))),
    AimAssistController = loader.use(require(script.Parent:FindFirstChild("AimAssistController"))),

    init = function(p1) -- Line: 26, Name: init
        p1.target_since = nil;
        p1.reaction_delay = nil;
        p1.dry_time = 0;
    end,

    start = function(u2) -- Line: 39, Name: start
        -- upvalues: UserInputService (copy), RunService (copy)
        if not UserInputService.TouchEnabled then
            return;
        end;

        RunService.Heartbeat:Connect(function(p3: number) -- Line: 48
            -- upvalues: u2 (copy)
            u2:step(p3);
        end);
        u2.GameStateController.phase_changed:connect(function(p4) -- Line: 54
            -- upvalues: u2 (copy)
            if p4 == "Active" then
                u2.dry_time = 0;
            end;
        end);
        u2.WeaponController.local_kill:connect(function() -- Line: 62
            -- upvalues: u2 (copy)
            u2.dry_time = 0;
        end);
    end,

    step = function(p5: any, p6: number) -- Line: 71, Name: step
        -- upvalues: get_last_input_category (copy), WeaponConfig (copy)
        if p5.GameStateController.is_in_game then
            p5.dry_time = p5.dry_time + p6;
        end;

        if not (p5.GameStateController.is_in_game and (get_last_input_category() == "Touch" and (p5.SettingsController.settings.auto_shoot and (not p5.MobileControlsController.editing and p5.AimAssistController:is_aiming())))) then
            p5.target_since = nil;
            p5.reaction_delay = nil;

            return;
        end;

        if not p5.WeaponController:has_target_in_crosshair() then
            p5.target_since = nil;
            p5.reaction_delay = nil;

            return;
        end;

        local os_clock_ret = os.clock();
        local target_since = p5.target_since;

        if target_since then
            if os_clock_ret - target_since >= (p5.reaction_delay or WeaponConfig.auto_shoot_reaction_time) then
                p5.WeaponController:request_fire();
            end;

            return;
        end;

        local auto_shoot_dry_ramp_seconds = WeaponConfig.auto_shoot_dry_ramp_seconds;
        local v7 = auto_shoot_dry_ramp_seconds <= 0 and 0 or math.clamp(p5.dry_time / auto_shoot_dry_ramp_seconds, 0, 1);
        local v8 = 1 + (WeaponConfig.auto_shoot_dry_min_multiplier - 1) * v7;
        p5.target_since = os_clock_ret;
        p5.reaction_delay = (WeaponConfig.auto_shoot_reaction_time + math.random() * WeaponConfig.auto_shoot_reaction_jitter) * v8;
    end
};