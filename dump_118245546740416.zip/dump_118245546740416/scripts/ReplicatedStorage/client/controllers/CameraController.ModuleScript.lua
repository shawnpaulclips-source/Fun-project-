-- ReplicatedStorage.client.controllers.CameraController
-- class: ModuleScript
-- hash: 42546f51014f4cf82dad0ed9bf6cb177ee92fb2505497bafe283d77128ef9adc8744a40fac22a96ef9fb9ec981817a8c

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local UserGameSettings = UserSettings():GetService("UserGameSettings");
local CameraFeel = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("feel"):FindFirstChild("CameraFeel"));
local CameraRecoiler = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("aim_assist"):FindFirstChild("CameraRecoiler"));
local CameraShaker = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("feel"):FindFirstChild("CameraShaker"));
local FeelConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("feel"):FindFirstChild("FeelConfig"));
local NewPlayerExperimentConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("game"):FindFirstChild("NewPlayerExperimentConfig"));
local SettingsConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("SettingsConfig"));
require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("default_data"));
local get_experiment_arm = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("get_experiment_arm"));
local get_last_input_category = require(script.Parent.Parent:FindFirstChild("utility"):FindFirstChild("get_last_input_category"));
local is_grounded = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("is_grounded"));
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local WeaponConfig = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("data"):FindFirstChild("weapons"):FindFirstChild("WeaponConfig"));
local zap = require(script.Parent.Parent:FindFirstChild("zap"));
local LocalPlayer = Players.LocalPlayer;
local look = NewPlayerExperimentConfig.experiments.look;

if look then
    for _, v in look.arms do
        local v1 = FeelConfig.camera.look_profiles[v];
        local v2 = `FeelConfig.camera.look_profiles is missing arm {v}`;
        assert(v1, v2);
    end;
end;

local dip_offset = FeelConfig.fov_punch.dip_offset;
local dip_duration = FeelConfig.fov_punch.dip_duration;
local peak_offset = FeelConfig.fov_punch.peak_offset;
local rise_duration = FeelConfig.fov_punch.rise_duration;
local settle_duration = FeelConfig.fov_punch.settle_duration;
local math_rad_ret = math.rad(FeelConfig.camera.pitch_limit_deg);
local gamepad_accel_max = FeelConfig.camera.gamepad_accel_max;
local gamepad_accel_ramp_time = FeelConfig.camera.gamepad_accel_ramp_time;
local gamepad_accel_threshold = FeelConfig.camera.gamepad_accel_threshold;

local function sanitize_menu_sensitivity(p3) -- Line: 73
    return (typeof(p3) ~= "number" or p3 <= 0) and 1 or p3;
end;

return {
    MovementController = loader.use(require(script.Parent:FindFirstChild("MovementController"))),
    AimAssistController = loader.use(require(script.Parent:FindFirstChild("AimAssistController"))),
    ViewmodelController = loader.use(require(script.Parent:FindFirstChild("ViewmodelController"))),
    ModifierController = loader.use(require(script.Parent:FindFirstChild("ModifierController"))),
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),
    CursorController = loader.use(require(script.Parent:FindFirstChild("CursorController"))),
    SettingsController = loader.use(require(script.Parent:FindFirstChild("SettingsController"))),
    DebugViewController = loader.use(require(script.Parent:FindFirstChild("DebugViewController"))),
    DataController = loader.use(require(script.Parent:FindFirstChild("DataController"))),

    init = function(p4) -- Line: 103, Name: init
        -- upvalues: FeelConfig (copy), CameraFeel (copy), CameraShaker (copy), CameraRecoiler (copy)
        p4.rotation = Vector2.zero;
        p4.look_profile = FeelConfig.camera.look_profiles[FeelConfig.camera.default_look_profile];
        p4.mouse_look_scale = Vector2.zero;
        p4.touch_look_scale = Vector2.zero;
        p4.gamepad_look_rate = Vector2.zero;
        p4.look_onboarding_steps = nil;
        p4.gamepad_menu_sensitivity = 1;
        p4.pending_look_delta = Vector2.zero;
        p4.feel = CameraFeel.new();
        p4.shaker = CameraShaker.new();
        p4.recoiler = CameraRecoiler.new();
        p4.gamepad_look = Vector2.zero;
        p4.gamepad_raw_deflection = 0;
        p4.gamepad_look_ramp = 0;
        p4.was_airborne = false;
        p4.aiming = false;
        p4.spectating = false;
        p4.spectate_target = nil;
        p4.spectate_cframe = nil;
        p4.aim_report_accum = 0;
        p4.inspecting = false;
        p4.inspect_cframe = CFrame.identity;
    end,

    start = function(u5) -- Line: 143, Name: start
        -- upvalues: UserGameSettings (copy), LocalPlayer (copy), UserInputService (copy), RunService (copy)
        u5:resolve_look_profile(u5.DataController.data);
        u5.DataController.data_changed:connect(function(p6) -- Line: 147
            -- upvalues: u5 (copy)
            u5:resolve_look_profile(p6);
        end);
        pcall(function() -- Line: 153
            -- upvalues: UserGameSettings (ref)
            UserGameSettings:SetGamepadCameraSensitivityVisible();
        end);
        local GamepadCameraSensitivity = UserGameSettings.GamepadCameraSensitivity;
        u5.gamepad_menu_sensitivity = (typeof(GamepadCameraSensitivity) ~= "number" or GamepadCameraSensitivity <= 0) and 1 or GamepadCameraSensitivity;
        UserGameSettings:GetPropertyChangedSignal("GamepadCameraSensitivity"):Connect(function() -- Line: 158
            -- upvalues: u5 (copy), UserGameSettings (ref)
            local GamepadCameraSensitivity2 = UserGameSettings.GamepadCameraSensitivity;
            u5.gamepad_menu_sensitivity = (typeof(GamepadCameraSensitivity2) ~= "number" or GamepadCameraSensitivity2 <= 0) and 1 or GamepadCameraSensitivity2;
        end);
        local Character = LocalPlayer.Character;

        if Character then
            task.spawn(function() -- Line: 166
                -- upvalues: u5 (copy), Character (copy)
                u5:setup_character(Character);
            end);
        end;

        LocalPlayer.CharacterAdded:Connect(function(p7: userdata) -- Line: 170
            -- upvalues: u5 (copy)
            u5:setup_character(p7);
        end);
        u5.GameStateController.in_game_changed:connect(function(p8: boolean) -- Line: 178
            -- upvalues: LocalPlayer (ref)
            local Character2 = LocalPlayer.Character;

            if Character2 then
                Character2 = Character2:FindFirstChildWhichIsA("Humanoid");
            end;

            if Character2 then
                Character2.AutoRotate = not p8;
            end;
        end);
        UserInputService.InputChanged:Connect(function(p9: userdata, p10: boolean) -- Line: 189
            -- upvalues: u5 (copy)
            if p10 or (u5.CursorController.unlocked or (u5.CursorController.editor_free or u5.CursorController.modal_free)) then
                return;
            end;

            if not u5.GameStateController.is_in_game then
                return;
            end;

            local UserInputType = p9.UserInputType;

            if UserInputType ~= Enum.UserInputType.MouseMovement and UserInputType ~= Enum.UserInputType.Touch then
                if p9.KeyCode == Enum.KeyCode.Thumbstick2 then
                    local Vector2_new_ret = Vector2.new(p9.Position.X, p9.Position.Y);
                    local Magnitude = Vector2_new_ret.Magnitude;
                    u5.gamepad_raw_deflection = Magnitude;
                    local gamepad_deadzone = u5.look_profile.gamepad_deadzone;

                    if Magnitude <= gamepad_deadzone then
                        u5.gamepad_look = Vector2.zero;

                        return;
                    end;

                    u5.gamepad_look = Vector2_new_ret.Unit * ((Magnitude - gamepad_deadzone) / (1 - gamepad_deadzone)) ^ u5.look_profile.gamepad_expo;
                end;

                return;
            end;

            if u5.CursorController:consume_relock() then
                return;
            end;

            local v11 = UserInputType == Enum.UserInputType.MouseMovement;
            local v12;

            if v11 then
                v12 = u5.mouse_look_scale;
            else
                v12 = u5.touch_look_scale;
            end;

            local v13 = Vector2.new(p9.Delta.Y, p9.Delta.X) * v12 * u5:get_ads_scale(v11 and "mouse" or "touch") * -1;
            local v14 = u5;
            v14.pending_look_delta = v14.pending_look_delta + v13;
        end);
        RunService:BindToRenderStep("FpsCameraPipeline", Enum.RenderPriority.Camera.Value + 1, function(p15) -- Line: 246
            -- upvalues: u5 (copy)
            u5:step(p15);
        end);
    end,

    step = function(p16: any, p17: number) -- Line: 252, Name: step
        -- upvalues: LocalPlayer (copy), zap (copy), is_grounded (copy), WeaponConfig (copy), get_last_input_category (copy), gamepad_accel_threshold (copy), gamepad_accel_ramp_time (copy), gamepad_accel_max (copy)
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if not workspace_CurrentCamera then
            return;
        end;

        if p16.spectating then
            workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
            local spectate_target = p16.spectate_target;
            local v18 = spectate_target and spectate_target:FindFirstChild("HumanoidRootPart");

            if v18 then
                workspace_CurrentCamera.CameraSubject = spectate_target:FindFirstChildWhichIsA("Humanoid");
                local Attribute = spectate_target:GetAttribute("AimYaw");

                if typeof(Attribute) ~= "number" then
                    local v19;
                    v19, Attribute = v18.CFrame:ToOrientation();
                end;

                local Attribute2 = spectate_target:GetAttribute("AimPitch");
                local v20 = typeof(Attribute2) ~= "number" and 0 or Attribute2;
                local v21 = CFrame.new(v18.Position + Vector3.new(0, 1.5, 0)) * CFrame.Angles(0, Attribute, 0) * CFrame.Angles(v20, 0, 0);

                if p16.spectate_cframe then
                    local v22 = 1 - math.exp(p17 * -30);
                    v21 = p16.spectate_cframe:Lerp(v21, v22);
                end;

                p16.spectate_cframe = v21;
                workspace_CurrentCamera.CFrame = v21;
                p16.ViewmodelController:update(v21, p17, spectate_target);
            end;

            return;
        end;

        if p16.inspecting then
            workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
            workspace_CurrentCamera.CFrame = p16.inspect_cframe;

            return;
        end;

        if not p16.GameStateController.is_in_game then
            if p16.GameStateController.match_view_held then
                workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;

                return;
            end;

            workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
            local Character = LocalPlayer.Character;

            if Character then
                Character = Character:FindFirstChildWhichIsA("Humanoid");
            end;

            if Character then
                workspace_CurrentCamera.CameraSubject = Character;
            end;

            return;
        end;

        local Character = LocalPlayer.Character;
        local v23, v24;

        if Character then
            v23 = Character:FindFirstChild("HumanoidRootPart");
            v24 = Character:FindFirstChildWhichIsA("Humanoid");
        else
            v24 = nil;
            v23 = nil;
        end;

        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        workspace_CurrentCamera.CameraSubject = v24;

        if not (v23 and v24) then
            return;
        end;

        if p16.DebugViewController.third_person then
            workspace_CurrentCamera.CFrame = CFrame.lookAt(v23.Position + Vector3.new(0, 5, 12), v23.Position + Vector3.new(0, 2, 0));

            if v24.Health > 0 then
                v23.CFrame = CFrame.new(v23.Position) * CFrame.Angles(0, p16.rotation.Y, 0);
            end;

            return;
        end;

        p16.aim_report_accum = p16.aim_report_accum + p17;

        if p16.aim_report_accum >= 0.05 then
            p16.aim_report_accum = 0;
            zap.report_aim.fire(p16.rotation.X, p16.rotation.Y % 6.283185307179586);
        end;

        local AssemblyLinearVelocity = v23.AssemblyLinearVelocity;
        local v25 = is_grounded(v23);
        local Magnitude = (AssemblyLinearVelocity * Vector3.new(1, 0, 1)).Magnitude;

        if p16.was_airborne and v25 then
            p16.shaker:shake("land");
        end;

        p16.was_airborne = not v25;
        local v26 = WeaponConfig.fov_speed_scale * math.max(0, Magnitude - WeaponConfig.walk_speed_default);
        local math_clamp_ret = math.clamp(v26, 0, WeaponConfig.fov_speed_max);
        p16.ModifierController:set_offset("FOV", "speed", math_clamp_ret);
        local v27 = v23.Position + Vector3.new(0, 1.5, 0) + CFrame.Angles(0, p16.rotation.Y, 0):VectorToWorldSpace(v24.CameraOffset);

        if get_last_input_category() == "Gamepad" and not (p16.CursorController.unlocked or (p16.CursorController.editor_free or p16.CursorController.modal_free)) then
            if gamepad_accel_threshold <= p16.gamepad_raw_deflection then
                p16.gamepad_look_ramp = math.min(p16.gamepad_look_ramp + p17, gamepad_accel_ramp_time);
            else
                p16.gamepad_look_ramp = 0;
            end;

            local v28 = 1 + (gamepad_accel_max - 1) * (p16.gamepad_look_ramp / gamepad_accel_ramp_time);
            local v29 = Vector2.new(p16.gamepad_look.Y, -p16.gamepad_look.X) * p16.gamepad_look_rate;
            p16.pending_look_delta = p16.pending_look_delta + v29 * v28 * p16.gamepad_menu_sensitivity * p16:get_ads_scale("gamepad") * p17;
        else
            p16.gamepad_look_ramp = 0;
            p16.gamepad_look = Vector2.zero;
            p16.gamepad_raw_deflection = 0;
        end;

        local v30 = CFrame.new(v27) * p16:get_look_cframe();
        local v31 = p16.AimAssistController:adjust(v30, p16.pending_look_delta, p17);
        p16:apply_rotation_delta(p16.pending_look_delta * v31.slowdown);
        p16:set_rotation(p16.rotation + v31.pull);
        p16.pending_look_delta = Vector2.zero;
        local v32 = CFrame.new(v27) * p16:get_look_cframe();
        local v33 = p16.recoiler:apply(v32, p17);
        local v34 = p16.feel:apply(v33, p17, {
            velocity = AssemblyLinearVelocity,
            walk_speed = WeaponConfig.walk_speed_default,
            grounded = v25,
            sliding = p16.MovementController.is_sliding,
            aiming = p16.aiming
        });
        local v35 = p16.shaker:update(p17);

        if p16.SettingsController.settings.screen_shake_enabled ~= false then
            local _, _, v36 = v35:ToEulerAnglesYXZ();
            v34 = v34 * CFrame.new(v35.Position) * CFrame.Angles(0, 0, v36);
        end;

        workspace_CurrentCamera.CFrame = v34;
        p16.ViewmodelController:update(v34, p17);

        if v24.Health > 0 then
            v23.CFrame = CFrame.new(v23.Position) * CFrame.Angles(0, p16.rotation.Y, 0);
        end;
    end,

    setup_character = function(p37: any, p38: userdata) -- Line: 483, Name: setup_character
        local Humanoid = p38:WaitForChild("Humanoid", 5);
        local HumanoidRootPart = p38:WaitForChild("HumanoidRootPart", 5);

        if Humanoid then
            Humanoid.AutoRotate = not p37.GameStateController.is_in_game;
        end;

        if HumanoidRootPart then
            local _, v39 = HumanoidRootPart.CFrame:ToOrientation();
            p37:set_rotation(Vector2.new(0, v39));
        end;
    end,

    resolve_look_profile = function(p40, p41) -- Line: 505, Name: resolve_look_profile
        -- upvalues: FeelConfig (copy), get_experiment_arm (copy)
        if p41.onboarding_steps == p40.look_onboarding_steps then
            return;
        end;

        p40.look_onboarding_steps = p41.onboarding_steps;
        local look_profiles = FeelConfig.camera.look_profiles;
        local default_look_profile = FeelConfig.camera.default_look_profile;
        local v42 = look_profiles[get_experiment_arm(p41, "look") or default_look_profile] or look_profiles[default_look_profile];
        p40.look_profile = v42;
        p40.mouse_look_scale = Vector2.new(v42.mouse_pitch_ratio, 1) * math.rad(v42.mouse_deg_per_px);
        p40.touch_look_scale = Vector2.new(v42.touch_pitch_ratio, 1) * math.rad(v42.touch_deg_per_px);
        p40.gamepad_look_rate = Vector2.new(v42.gamepad_pitch_ratio, 1) * math.rad(v42.gamepad_deg_per_sec);
    end,

    get_ads_scale = function(p43: any, p44: string) -- Line: 528, Name: get_ads_scale
        -- upvalues: SettingsConfig (copy), FeelConfig (copy)
        return not p43.aiming and 1 or (p43.SettingsController.settings.camera_sensitivity_ads or SettingsConfig.camera_sensitivity_ads.default) * FeelConfig.camera.ads_device_scale[p44];
    end,

    set_rotation = function(p45: any, p46) -- Line: 537, Name: set_rotation
        -- upvalues: math_rad_ret (copy)
        p45.rotation = Vector2.new(math.clamp(p46.X, -math_rad_ret, math_rad_ret), p46.Y);
    end,

    apply_rotation_delta = function(p47: any, p48) -- Line: 547, Name: apply_rotation_delta
        local settings = p47.SettingsController.settings;
        local v49 = settings.camera_sensitivity or 1;
        local Vector2_new_ret = Vector2.new(p48.X * v49 * (settings.camera_sensitivity_y or 1) * (settings.camera_invert_y == true and -1 or 1), p48.Y * v49 * (settings.camera_sensitivity_x or 1) * (settings.camera_invert_x == true and -1 or 1));
        p47:set_rotation(p47.rotation + Vector2_new_ret);
    end,

    get_look_cframe = function(p50) -- Line: 561, Name: get_look_cframe
        return CFrame.Angles(0, p50.rotation.Y, 0) * CFrame.Angles(p50.rotation.X, 0, 0);
    end,

    set_spectate_target = function(p51: any, p52: userdata?) -- Line: 569, Name: set_spectate_target
        p51.spectate_target = p52;
        p51.spectate_cframe = nil;
    end,

    set_spectating = function(p53: any, p54: boolean) -- Line: 578, Name: set_spectating
        p53.spectating = p54;

        if p54 then
            p53.spectate_cframe = nil;
        end;
    end,

    set_inspecting = function(p55: any, p56: boolean) -- Line: 588, Name: set_inspecting
        p55.inspecting = p56;
    end,

    set_inspect_view = function(p57: any, p58) -- Line: 594, Name: set_inspect_view
        p57.inspect_cframe = p58;
    end,

    add_recoil = function(p59: any, p60) -- Line: 600, Name: add_recoil
        p59.recoiler:add_recoil(p60);
    end,

    set_aiming = function(p61: any, p62: boolean) -- Line: 606, Name: set_aiming
        -- upvalues: WeaponConfig (copy)
        p61.aiming = p62;

        if p62 then
            p61.ModifierController:set_modifier("FOV", "aim", WeaponConfig.default_field_of_view - WeaponConfig.fov_decrease_aim, 110);

            return;
        end;

        p61.ModifierController:set_modifier("FOV", "aim", nil);
    end,

    shake = function(p63, p64) -- Line: 622, Name: shake
        p63.shaker:shake(p64);
    end,

    shake_once = function(p65: any, p66: number, p67: number, p68: number, p69: number) -- Line: 627, Name: shake_once
        p65.shaker:shake_once(p66, p67, p68, p69);
    end,

    fov_punch = function(p70) -- Line: 639, Name: fov_punch
        -- upvalues: dip_offset (copy), dip_duration (copy), peak_offset (copy), rise_duration (copy), settle_duration (copy)
        p70.ModifierController:punch("FOV", {
            {
                offset = dip_offset,
                duration = dip_duration
            },
            {
                offset = peak_offset,
                duration = rise_duration
            },
            {
                offset = 0,
                duration = settle_duration
            }
        });
    end
};