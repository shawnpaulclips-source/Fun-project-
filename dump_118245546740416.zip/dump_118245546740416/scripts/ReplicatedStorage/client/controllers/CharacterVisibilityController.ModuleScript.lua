-- ReplicatedStorage.client.controllers.CharacterVisibilityController
-- class: ModuleScript
-- hash: b95fc82b56ac7d8e0de5876c09b4c685a4d30be2a8e816ce8178396994a7d76b3ef9512690c7ed2d443de83952b74dbf

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local loader = require(game:GetService("ReplicatedStorage"):FindFirstChild("shared"):FindFirstChild("loader"));
local LocalPlayer = Players.LocalPlayer;

local function build_cache(p1: userdata) -- Line: 34
    local v2 = {};
    local v3 = {};
    local v4 = {};
    local v5 = {};

    for _, descendant in p1:GetDescendants() do
        if descendant:IsA("BasePart") then
            table.insert(v2, descendant);
        elseif descendant:IsA("ParticleEmitter") then
            table.insert(v3, descendant);
            v4[descendant] = descendant.Enabled;
        elseif descendant:IsA("Beam") then
            table.insert(v5, descendant);
            v4[descendant] = descendant.Enabled;
        end;
    end;

    local u6 = {
        model = p1,
        parts = v2,
        emitters = v3,
        beams = v5,
        vfx_baseline = v4,
        connections = {}
    };
    table.insert(u6.connections, p1.DescendantAdded:Connect(function(p7: userdata) -- Line: 66
        -- upvalues: u6 (copy)
        if p7:IsA("BasePart") then
            table.insert(u6.parts, p7);

            return;
        end;

        if not p7:IsA("ParticleEmitter") then
            if p7:IsA("Beam") then
                table.insert(u6.beams, p7);
                u6.vfx_baseline[p7] = p7.Enabled;
            end;

            return;
        end;

        table.insert(u6.emitters, p7);
        u6.vfx_baseline[p7] = p7.Enabled;
    end));
    table.insert(u6.connections, p1.DescendantRemoving:Connect(function(p8: userdata) -- Line: 82
        -- upvalues: u6 (copy)
        if p8:IsA("BasePart") then
            local table_find_ret = table.find(u6.parts, p8);

            if table_find_ret then
                table.remove(u6.parts, table_find_ret);
            end;
        else
            if p8:IsA("ParticleEmitter") then
                local table_find_ret = table.find(u6.emitters, p8);

                if table_find_ret then
                    table.remove(u6.emitters, table_find_ret);
                end;

                u6.vfx_baseline[p8] = nil;

                return;
            end;

            if p8:IsA("Beam") then
                local table_find_ret = table.find(u6.beams, p8);

                if table_find_ret then
                    table.remove(u6.beams, table_find_ret);
                end;

                u6.vfx_baseline[p8] = nil;
            end;
        end;
    end));

    return u6;
end;

local function release_cache(p9: table) -- Line: 106
    for _, v in p9.connections do
        v:Disconnect();
    end;
end;

local function apply_cache_transparency(p10: table, p11: number) -- Line: 116
    for _, v in p10.parts do
        if v.LocalTransparencyModifier ~= p11 then
            v.LocalTransparencyModifier = p11;
        end;
    end;
end;

local function apply_cache_vfx(p12: table, p13: boolean) -- Line: 130
    for _, v in p12.emitters do
        local v14;

        if p13 then
            v14 = false;
        else
            v14 = p12.vfx_baseline[v];
        end;

        if v.Enabled ~= v14 then
            v.Enabled = v14;
        end;
    end;

    for _, v in p12.beams do
        local v15;

        if p13 then
            v15 = false;
        else
            v15 = p12.vfx_baseline[v];
        end;

        if v.Enabled ~= v15 then
            v.Enabled = v15;
        end;
    end;
end;

return {
    GameStateController = loader.use(require(script.Parent:FindFirstChild("GameStateController"))),
    SpectateController = loader.use(require(script.Parent:FindFirstChild("SpectateController"))),
    DebugViewController = loader.use(require(script.Parent:FindFirstChild("DebugViewController"))),

    init = function(p16) -- Line: 169, Name: init
        p16.character = nil;
        p16.spectate_subject = nil;
        p16.local_cache = nil;
        p16.spectate_cache = nil;
        p16.remote_records = {};
        p16.remote_connections = {};
    end,

    start = function(u17) -- Line: 186, Name: start
        -- upvalues: apply_cache_vfx (copy), LocalPlayer (copy), Players (copy), RunService (copy)
        local function on_character(p18: userdata) -- Line: 187
            -- upvalues: u17 (copy), apply_cache_vfx (ref)
            if u17.local_cache then
                apply_cache_vfx(u17.local_cache, false);

                for _, v in u17.local_cache.connections do
                    v:Disconnect();
                end;

                u17.local_cache = nil;
            end;

            u17.character = p18;
        end;

        if LocalPlayer.Character then
            local Character = LocalPlayer.Character;

            if u17.local_cache then
                apply_cache_vfx(u17.local_cache, false);

                for _, v in u17.local_cache.connections do
                    v:Disconnect();
                end;

                u17.local_cache = nil;
            end;

            u17.character = Character;
        end;

        LocalPlayer.CharacterAdded:Connect(on_character);
        LocalPlayer.CharacterRemoving:Connect(function() -- Line: 199
            -- upvalues: u17 (copy), apply_cache_vfx (ref)
            u17.character = nil;

            if u17.local_cache then
                apply_cache_vfx(u17.local_cache, false);

                for _, v in u17.local_cache.connections do
                    v:Disconnect();
                end;

                u17.local_cache = nil;
            end;
        end);

        for _, v in Players:GetPlayers() do
            u17:setup_remote_player(v);
        end;

        Players.PlayerAdded:Connect(function(p19: userdata) -- Line: 211
            -- upvalues: u17 (copy)
            u17:setup_remote_player(p19);
        end);
        Players.PlayerRemoving:Connect(function(p20: userdata) -- Line: 214
            -- upvalues: u17 (copy)
            u17:teardown_remote_player(p20);
        end);
        RunService.RenderStepped:Connect(function() -- Line: 218
            -- upvalues: u17 (copy)
            u17:apply();
        end);
    end,

    setup_remote_player = function(u21: any, p22: userdata) -- Line: 226, Name: setup_remote_player
        -- upvalues: LocalPlayer (copy)
        if p22 == LocalPlayer or u21.remote_connections[p22] then
            return;
        end;

        local v23 = {};
        table.insert(v23, p22.CharacterAdded:Connect(function(p24: userdata) -- Line: 233
            -- upvalues: u21 (copy)
            u21:track_remote_character(p24);
        end));
        table.insert(v23, p22.CharacterRemoving:Connect(function(p25: userdata) -- Line: 239
            -- upvalues: u21 (copy)
            u21:release_remote(p25, false);
        end));
        u21.remote_connections[p22] = v23;

        if p22.Character then
            u21:track_remote_character(p22.Character);
        end;
    end,

    teardown_remote_player = function(p26: any, p27: userdata) -- Line: 252, Name: teardown_remote_player
        local v28 = p26.remote_connections[p27];

        if v28 then
            for _, v in v28 do
                v:Disconnect();
            end;

            p26.remote_connections[p27] = nil;
        end;

        if p27.Character then
            p26:release_remote(p27.Character, false);
        end;
    end,

    track_remote_character = function(p29: any, p30: userdata) -- Line: 268, Name: track_remote_character
        -- upvalues: build_cache (copy)
        if p29.remote_records[p30] then
            return;
        end;

        if p30:GetAttribute("spawn_ready") == true then
            return;
        end;

        if p30 == p29.spectate_subject then
            return;
        end;

        local v31 = build_cache(p30);

        for _, v in v31.parts do
            if v.LocalTransparencyModifier ~= 1 then
                v.LocalTransparencyModifier = 1;
            end;
        end;

        p29.remote_records[p30] = {
            cache = v31,
            deadline = os.clock() + 3
        };
    end,

    release_remote = function(p32: any, p33: userdata, p34: boolean) -- Line: 291, Name: release_remote
        local v35 = p32.remote_records[p33];

        if not v35 then
            return;
        end;

        if p34 then
            for _, v in v35.cache.parts do
                if v.LocalTransparencyModifier ~= 0 then
                    v.LocalTransparencyModifier = 0;
                end;
            end;
        end;

        for _, v in v35.cache.connections do
            v:Disconnect();
        end;

        p32.remote_records[p33] = nil;
    end,

    apply = function(p36) -- Line: 320, Name: apply
        -- upvalues: build_cache (copy), apply_cache_vfx (copy)
        local character = p36.character;

        if character and p36.GameStateController.is_in_game then
            if not p36.local_cache then
                p36.local_cache = build_cache(character);
            end;

            local v37 = not p36.DebugViewController.third_person;
            local v38 = v37 and 1 or 0;

            for _, v in p36.local_cache.parts do
                if v.LocalTransparencyModifier ~= v38 then
                    v.LocalTransparencyModifier = v38;
                end;
            end;

            apply_cache_vfx(p36.local_cache, v37);
        elseif p36.local_cache then
            for _, v in p36.local_cache.parts do
                if v.LocalTransparencyModifier ~= 0 then
                    v.LocalTransparencyModifier = 0;
                end;
            end;

            apply_cache_vfx(p36.local_cache, false);

            for _, v in p36.local_cache.connections do
                v:Disconnect();
            end;

            p36.local_cache = nil;
        end;

        local _target_character = p36.SpectateController:get_target_character();

        if _target_character ~= p36.spectate_subject then
            if p36.spectate_cache then
                for _, v in p36.spectate_cache.parts do
                    if v.LocalTransparencyModifier ~= 0 then
                        v.LocalTransparencyModifier = 0;
                    end;
                end;

                apply_cache_vfx(p36.spectate_cache, false);

                for _, v in p36.spectate_cache.connections do
                    v:Disconnect();
                end;

                p36.spectate_cache = nil;
            end;

            p36.spectate_subject = _target_character;
        end;

        if p36.spectate_subject then
            if not p36.spectate_cache then
                p36.spectate_cache = build_cache(p36.spectate_subject);
            end;

            for _, v in p36.spectate_cache.parts do
                if v.LocalTransparencyModifier ~= 1 then
                    v.LocalTransparencyModifier = 1;
                end;
            end;

            local spectate_cache = p36.spectate_cache;

            for _, v in spectate_cache.emitters do
                if v.Enabled ~= false then
                    v.Enabled = false;
                end;
            end;

            for _, v in spectate_cache.beams do
                if v.Enabled ~= false then
                    v.Enabled = false;
                end;
            end;
        end;

        for i, v in p36.remote_records do
            local v39 = os.clock() >= v.deadline;

            if i.Parent == nil or i == p36.spectate_subject then
                p36:release_remote(i, false);
            elseif v39 or i:GetAttribute("spawn_ready") == true then
                p36:release_remote(i, true);
            else
                for _, v2 in v.cache.parts do
                    if v2.LocalTransparencyModifier ~= 1 then
                        v2.LocalTransparencyModifier = 1;
                    end;
                end;
            end;
        end;
    end
};