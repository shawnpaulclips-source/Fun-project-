-- ReplicatedStorage.client.__RUNTIME_SETRUP
-- class: Script
-- hash: 0491ba85b240bc54bbc57c0ddab187a96d14d5e39ec7b1eefc77cdb5d3c4b2820c38b9e757f2585c4b5affba07a457ac

-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");

while not game.Loaded do
    task.wait();
end;

task.spawn(function() -- Line: 27
    -- upvalues: CollectionService (copy)
    for _, v in CollectionService:GetTagged("PathfindingModifierHitbox") do
        if v:IsA("BasePart") and v:IsA("BasePart") then
            v.Transparency = 1;
            v.CanCollide = false;
            v.CanQuery = false;
            v.Anchored = true;
        end;
    end;
end);
CollectionService:GetInstanceAddedSignal("PathfindingModifierHitbox"):Connect(function(p1: userdata) -- Line: 7, Name: hidePart
    if p1:IsA("BasePart") then
        p1.Transparency = 1;
        p1.CanCollide = false;
        p1.CanQuery = false;
        p1.Anchored = true;
    end;
end);
task.spawn(function() -- Line: 37
    -- upvalues: CollectionService (copy)
    for _, v in CollectionService:GetTagged("SpawnPart") do
        if v:IsA("BasePart") and v:IsA("BasePart") then
            v.Transparency = 1;
            v.CanCollide = false;
            v.CanQuery = false;
            v.Anchored = true;
            task.delay(0.1, v.ClearAllChildren, v);
        end;
    end;
end);
CollectionService:GetInstanceAddedSignal("SpawnPart"):Connect(function(p2: userdata) -- Line: 16, Name: clearAndHidePart
    if p2:IsA("BasePart") then
        p2.Transparency = 1;
        p2.CanCollide = false;
        p2.CanQuery = false;
        p2.Anchored = true;
        task.delay(0.1, p2.ClearAllChildren, p2);
    end;
end);