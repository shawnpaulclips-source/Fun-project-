-- Players.Shawnp12121.PlayerScripts.PlayerScriptsLoader
-- class: LocalScript
-- hash: 15be9c5b66fc61d4f0e798e01fd6a46004c1702b544503272b28cb6548360ff7d2d16d583551c7b779cd3015434e3b55

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("PlayerModule"));