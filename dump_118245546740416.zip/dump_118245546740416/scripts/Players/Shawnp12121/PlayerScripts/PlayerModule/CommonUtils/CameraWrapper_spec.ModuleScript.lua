-- Players.Shawnp12121.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec
-- class: ModuleScript
-- hash: 2800557e63151ab3242980484afa6a058affa2ecb75ffb54c19c177bb9af682c6b1cdb6e0abe9b279e0994118093552b

-- Decompiled with Potassium's decompiler.

local CorePackages = game:GetService("CorePackages");
local JestGlobals = require(CorePackages.Packages.Dev.JestGlobals);
local describe = JestGlobals.describe;
local expect = JestGlobals.expect;
local it = JestGlobals.it;
local waitForEvents = require(CorePackages.Workspace.Packages.TestUtils).DeferredLuaHelpers.waitForEvents;
local CameraWrapper = require(script.Parent.CameraWrapper);
describe("CameraWrapper", function() -- Line: 12
    -- upvalues: it (copy), CameraWrapper (copy), expect (copy), waitForEvents (copy)
    it("should instantiate", function() -- Line: 13
        -- upvalues: CameraWrapper (ref), expect (ref)
        expect((CameraWrapper.new())).never.toBeNil();
    end);
    it("should return updated camera", function() -- Line: 19
        -- upvalues: CameraWrapper (ref), expect (ref), waitForEvents (ref)
        local v1 = CameraWrapper.new();
        v1:Enable();
        local Camera = Instance.new("Camera");
        Camera.Parent = game.Workspace;
        expect(v1:getCamera()).toBe(game.Workspace.CurrentCamera);
        expect(v1:getCamera()).never.toBe(Camera);
        game.Workspace.CurrentCamera = Camera;
        waitForEvents();
        expect(v1:getCamera()).toBe(game.Workspace.CurrentCamera);
        expect(v1:getCamera()).toBe(Camera);
    end);
end);