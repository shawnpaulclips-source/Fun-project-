-- Players.Shawnp12121.PlayerScripts.PlayerModule.CommonUtils.FlagUtil
-- class: ModuleScript
-- hash: 035f355844f5d85578355a910a25bec6fda64d1feee1b2c08333d12dc614df579056d1cc453bc91fa3e65308d852d013

-- Decompiled with Potassium's decompiler.

return {
    getUserFlag = function(u1) -- Line: 11, Name: getUserFlag
        local success, result = pcall(function() -- Line: 12
            -- upvalues: u1 (copy)
            return UserSettings():IsUserFeatureEnabled(u1);
        end);

        return success and result;
    end
};