-- Players.Shawnp12121.PlayerScripts.PlayerModule.CameraModule.CameraUI
-- class: ModuleScript
-- hash: 33bea4df73246443d705dd6d376608f26453556236180c4f30abf8ec3f5074643a49c4a0e85fb1179586ba95548c032b

-- Decompiled with Potassium's decompiler.

local StarterGui = game:GetService("StarterGui");
local u1 = false;
local u2 = {};

function u2.setCameraModeToastEnabled(p3: boolean) -- Line: 10
    -- upvalues: u1 (ref), u2 (copy)
    if not (p3 or u1) then
        return;
    end;

    if not u1 then
        u1 = true;
    end;

    if not p3 then
        u2.setCameraModeToastOpen(false);
    end;
end;

function u2.setCameraModeToastOpen(p4: boolean) -- Line: 24
    -- upvalues: u1 (ref), StarterGui (copy)
    assert(u1);

    if p4 then
        StarterGui:SetCore(
            "SendNotification",
            {
                Title = "Camera Control Enabled",
                Text = "Right click to toggle",
                Duration = 3
            }
        );
    end;
end;

return u2;