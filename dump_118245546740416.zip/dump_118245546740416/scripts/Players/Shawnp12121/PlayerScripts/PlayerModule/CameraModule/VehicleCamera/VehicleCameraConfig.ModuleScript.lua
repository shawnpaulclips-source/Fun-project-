-- Players.Shawnp12121.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig
-- class: ModuleScript
-- hash: 37b74e98d9ea7700247f4720d6c5aee23469405840a08e899bed417a87e7ec345a5df39b44431010a22b54f38116c3b0

-- Decompiled with Potassium's decompiler.

return {
    pitchStiffness = 0.5,
    yawStiffness = 2.5,
    autocorrectDelay = 1,
    autocorrectMinCarSpeed = 16,
    autocorrectMaxCarSpeed = 32,
    autocorrectResponse = 0.5,
    cutoffMinAngularVelYaw = 60,
    cutoffMaxAngularVelYaw = 180,
    cutoffMinAngularVelPitch = 15,
    cutoffMaxAngularVelPitch = 60,
    pitchBaseAngle = 18,
    pitchDeadzoneAngle = 12,
    firstPersonResponseMul = 10,
    yawReponseDampingRising = 1,
    yawResponseDampingFalling = 3,
    pitchReponseDampingRising = 1,
    pitchResponseDampingFalling = 3,
    verticalCenterOffset = 0.33
};