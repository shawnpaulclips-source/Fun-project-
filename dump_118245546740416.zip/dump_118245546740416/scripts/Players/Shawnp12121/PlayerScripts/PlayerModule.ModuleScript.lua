-- Players.Shawnp12121.PlayerScripts.PlayerModule
-- class: ModuleScript
-- hash: 5e22d11d41a60b6c116d9ee4e349a41c2a6da40fdbfb9e307b853fdd3112ef6af9cc77ca8b5f8b1aaeb7e823909785f5

-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;

function u1.new() -- Line: 12
    -- upvalues: u1 (copy)
    local v2 = setmetatable({}, u1);
    v2.cameras = require(script:WaitForChild("CameraModule"));
    v2.controls = require(script:WaitForChild("ControlModule"));

    return v2;
end;

function u1.GetCameras(p3) -- Line: 19
    return p3.cameras;
end;

function u1.GetControls(p4) -- Line: 23
    return p4.controls;
end;

function u1.GetClickToMoveController(p5) -- Line: 27
    return p5.controls:GetClickToMoveController();
end;

return u1.new();