-- ReplicatedFirst.loading_handler
-- class: Script
-- hash: 6e3678dfec306294c723329ae9e6e00cd6bfd6dac82e6eda7c63015e6e1d1ef00bbd38d0231ddcb3041242853df242c2

-- Decompiled with Potassium's decompiler.

local ContentProvider = game:GetService("ContentProvider");
local Lighting = game:GetService("Lighting");
local Players = game:GetService("Players");
local ReplicatedFirst = game:GetService("ReplicatedFirst");
local RunService = game:GetService("RunService");
local TeleportService = game:GetService("TeleportService");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local LoadingCopyData = require(ReplicatedFirst:WaitForChild("LoadingCopyData"));
local loading_screen = require(ReplicatedFirst:WaitForChild("loading_screen"));
local TRANSITION = loading_screen.TRANSITION;

local function fade_descendants(p1: userdata, p2: userdata, p3: userdata?) -- Line: 41
    -- upvalues: TweenService (copy)
    for _, descendant in p1:GetDescendants() do
        if not (p3 and descendant:IsDescendantOf(p3)) then
            local v4 = descendant:IsA("TextLabel") and {
                TextTransparency = 1
            } or (descendant:IsA("ImageLabel") and {
                ImageTransparency = 1,
                BackgroundTransparency = 1
            } or (descendant:IsA("CanvasGroup") and {
                GroupTransparency = 1
            } or (descendant:IsA("Frame") and descendant.BackgroundTransparency < 1 and {
                BackgroundTransparency = 1
            } or (descendant:IsA("UIStroke") and {
                Transparency = 1
            } or nil))));

            if v4 then
                TweenService:Create(descendant, p2, v4):Play();
            end;
        end;
    end;
end;

local ArrivingTeleportGui = TeleportService:GetArrivingTeleportGui();
local v5 = ArrivingTeleportGui ~= nil;
local v6 = nil;
local success, result = pcall(function() -- Line: 71
    -- upvalues: TeleportService (copy)
    return TeleportService:GetLocalPlayerTeleportData();
end);
local v7;

if success and (type(result) == "table" and (type(result.ui) == "string" and LoadingCopyData.contexts[result.ui])) then
    v7 = result.ui;

    if type(result.uil) == "string" then
        v6 = result.uil;
    end;
else
    v7 = nil;
end;

ArrivingTeleportGui = ArrivingTeleportGui;
local v8;

if ArrivingTeleportGui then
    v8 = loading_screen.adopt(ArrivingTeleportGui);
else
    v8 = ArrivingTeleportGui;
end;

local v9 = v8 ~= nil;
local v10;

if v9 then
    v10 = v8:get_context();
else
    v10 = nil;
end;

if ArrivingTeleportGui and not v9 then
    local Cover = ArrivingTeleportGui:FindFirstChild("Cover");

    if Cover == nil then
        ArrivingTeleportGui.DisplayOrder = 20000;
    end;

    ArrivingTeleportGui.Parent = LocalPlayer.PlayerGui;
    task.spawn(function() -- Line: 95
        -- upvalues: Cover (copy), TweenService (copy), fade_descendants (copy), ArrivingTeleportGui (copy)
        task.wait(0.4);
        local TweenInfo_new_ret = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out);

        if Cover then
            TweenService:Create(Cover, TweenInfo_new_ret, {
                BackgroundTransparency = 1
            }):Play();
        else
            fade_descendants(ArrivingTeleportGui, TweenInfo_new_ret);
        end;

        task.wait(0.35);
        ArrivingTeleportGui:Destroy();
    end);
end;

local u11 = v8 or loading_screen.create();

if v7 then
    u11:set_context(v7, v6);
elseif not v9 then
    u11:set_context(v5 and "server" or "boot");
end;

local _context = u11:get_context();
local _line = u11:get_line();

local function follow_party_hold() -- Line: 125
    -- upvalues: LocalPlayer (copy), u11 (ref), _context (copy), _line (copy)
    if LocalPlayer:GetAttribute("Teleporting") == true and LocalPlayer:GetAttribute("TeleportingContext") == "party" then
        u11:set_context("party");

        return;
    end;

    u11:set_context(_context, _line);
end;

if LocalPlayer:GetAttribute("Teleporting") == true and LocalPlayer:GetAttribute("TeleportingContext") == "party" then
    u11:set_context("party");
else
    u11:set_context(_context, _line);
end;

local u12 = { LocalPlayer:GetAttributeChangedSignal("Teleporting"):Connect(follow_party_hold), LocalPlayer:GetAttributeChangedSignal("TeleportingContext"):Connect(follow_party_hold) };

local function disconnect_hold_follow() -- Line: 140
    -- upvalues: u12 (copy)
    for _, v in u12 do
        v:Disconnect();
    end;
end;

local gui = u11.gui;
local Root = gui:WaitForChild("Root");
local Backdrop = gui:WaitForChild("Backdrop");
local Glow = Root:WaitForChild("Glow");
Backdrop.BackgroundTransparency = 0;
gui.Parent = LocalPlayer.PlayerGui;
u11:register();
LocalPlayer:SetAttribute("LoadingArrivalProbe", (`arr={v5 and 1 or 0} adopt={v9 and 1 or 0} td={v7 or "-"} attr={v10 or "-"}`));
local u13 = nil;

local function start_layout() -- Line: 162
    -- upvalues: u11 (ref), loading_screen (copy), gui (copy), u13 (ref)
    u11:layout(loading_screen.viewport_of(gui));
    u13 = gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line: 164
        -- upvalues: u11 (ref), loading_screen (ref), gui (ref)
        u11:layout(loading_screen.viewport_of(gui));
    end);
end;

if v9 then
    task.delay(0.4, function() -- Line: 169
        -- upvalues: gui (copy), start_layout (copy)
        if gui.Parent then
            start_layout();
        end;
    end);
else
    start_layout();
end;

local BlurEffect = Instance.new("BlurEffect");
BlurEffect.Name = "LoadingBlur";
BlurEffect.Size = 0;
BlurEffect.Parent = Lighting;

if v5 then
    BlurEffect.Size = 56;
else
    TweenService:Create(BlurEffect, TRANSITION.blur_in, {
        Size = 56
    }):Play();
end;

if v5 then
    Glow.GroupTransparency = 0;
else
    Glow.GroupTransparency = 1;
    TweenService:Create(Glow, TRANSITION.mist_in, {
        GroupTransparency = 0
    }):Play();
    u11:fade_content(false);
    u11:fade_content(true, TRANSITION.content_in);
end;

local u14 = 0;
local v16 = RunService.Heartbeat:Connect(function(p15) -- Line: 206
    -- upvalues: u14 (ref), u11 (ref)
    u14 = u14 + math.min(p15, 0.03333333333333333);
    u11:step(u14);
end);
ReplicatedFirst:RemoveDefaultLoadingScreen();
local Sound = Instance.new("Sound");
Sound.Name = "Sound";
Sound.RollOffMode = Enum.RollOffMode.InverseTapered;
Sound.SoundId = "rbxassetid://118264664025756";
Sound.Volume = 0.4;
Sound.Parent = script;
task.spawn(ContentProvider.PreloadAsync, ContentProvider, { "rbxassetid://118264664025756" });
local v17, v18;

if v5 then
    v17 = nil;
    v18 = nil;
else
    task.wait(3);
    v17 = nil;
    v18 = nil;
end;

while true do
    task.wait();
    local v19 = LocalPlayer:GetAttribute("Loaded") and not LocalPlayer:GetAttribute("Redirecting") and not LocalPlayer:GetAttribute("Teleporting");

    if v19 then
        v17 = v17 or os.clock() + 8;

        if (LocalPlayer:GetAttribute("spawn_pending") == true and true or LocalPlayer.Character ~= nil) and not v18 then
            v18 = os.clock() + 3;
        end;
    else
        v17 = nil;
        v18 = nil;
    end;

    if v17 and (LocalPlayer:GetAttribute("SpawnRendered") or (v17 <= os.clock() or v18 and v18 <= os.clock())) then
        task.wait(0.2);

        if not v5 then
            task.wait(1.5);
        end;

        for _, v in u12 do
            v:Disconnect();
        end;

        LocalPlayer:SetAttribute("LoadingFadeStarted", true);

        if not gui:IsDescendantOf(LocalPlayer.PlayerGui) then
            BlurEffect:Destroy();
            v16:Disconnect();

            if u13 then
                u13:Disconnect();
            end;

            u11:destroy();

            return;
        end;

        u11:fade_content(false, TRANSITION.content_out);
        TweenService:Create(Glow, TRANSITION.scene_out, {
            GroupTransparency = 1
        }):Play();
        TweenService:Create(Backdrop, TRANSITION.scene_out, {
            BackgroundTransparency = 1
        }):Play();
        TweenService:Create(BlurEffect, TRANSITION.scene_out, {
            Size = 0
        }):Play();
        Sound:Play();
        task.wait(1.15);
        v16:Disconnect();

        if u13 then
            u13:Disconnect();
        end;

        BlurEffect:Destroy();
        u11:destroy();

        return;
    end;
end;