-- ReplicatedFirst.teleporting_handler
-- class: Script
-- hash: 946d1b59d5dc17813eda3bdfc5c770f45c83d706fd851ee0ba378478b1b41c7f6c690733b9243b890a0c42b0fb6ae445

-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedFirst = game:GetService("ReplicatedFirst");
local RunService = game:GetService("RunService");
local StarterGui = game:GetService("StarterGui");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local LoadingCopyData = require(ReplicatedFirst:WaitForChild("LoadingCopyData"));
local loading_screen = require(ReplicatedFirst:WaitForChild("loading_screen"));
local TRANSITION = loading_screen.TRANSITION;

local function is_holding() -- Line: 23
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer:GetAttribute("Teleporting") == true and true or LocalPlayer:GetAttribute("MatchFound") == true;
end;

local function restore_coregui(p1) -- Line: 59
    -- upvalues: StarterGui (copy)
    for i, v in p1 do
        StarterGui:SetCoreGuiEnabled(i, v);
    end;
end;

local function apply(p2) -- Line: 30
    -- upvalues: LocalPlayer (copy), LoadingCopyData (copy)
    if LocalPlayer:GetAttribute("MatchFound") == true then
        p2:set_context("duel");

        return;
    end;

    local Attribute = LocalPlayer:GetAttribute("TeleportingContext");
    local Attribute2 = LocalPlayer:GetAttribute("TeleportingLine");
    local v3 = (type(Attribute) ~= "string" or not LoadingCopyData.contexts[Attribute]) and "server" or Attribute;

    if type(Attribute2) ~= "string" then
        Attribute2 = nil;
    end;

    p2:set_context(v3, Attribute2);
end;

local function snapshot_coregui() -- Line: 49
    -- upvalues: StarterGui (copy)
    local v4 = {};

    for _, v in Enum.CoreGuiType:GetEnumItems() do
        if v ~= Enum.CoreGuiType.All then
            v4[v] = StarterGui:GetCoreGuiEnabled(v);
        end;
    end;

    return v4;
end;

while true do
    repeat
        task.wait(0.1);
    until LocalPlayer:GetAttribute("LoadingFadeStarted") == true and (LocalPlayer:GetAttribute("Teleporting") == true or LocalPlayer:GetAttribute("MatchFound") == true);

    local u5 = loading_screen.create();
    local gui = u5.gui;
    local Backdrop = gui.Backdrop;
    local Glow = gui.Root.Glow;
    apply(u5);
    u5:fade_content(false);
    Backdrop.BackgroundTransparency = 1;
    Glow.GroupTransparency = 1;
    gui.Parent = LocalPlayer.PlayerGui;
    u5:layout(loading_screen.viewport_of(gui));
    u5:register();
    local v6 = snapshot_coregui();
    StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All, false);
    TweenService:Create(Backdrop, TRANSITION.backdrop_in, {
        BackgroundTransparency = 0
    }):Play();
    TweenService:Create(Glow, TRANSITION.mist_in, {
        GroupTransparency = 0
    }):Play();
    u5:fade_content(true, TRANSITION.content_in);
    task.delay(0.65, function() -- Line: 94
        -- upvalues: gui (copy), u5 (copy)
        if gui.Parent then
            u5:register();
        end;
    end);
    local v7 = gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line: 101
        -- upvalues: u5 (copy), loading_screen (copy), gui (copy)
        u5:layout(loading_screen.viewport_of(gui));
    end);
    local u8 = 0;
    local v10 = RunService.Heartbeat:Connect(function(p9) -- Line: 107
        -- upvalues: u8 (ref), u5 (copy)
        u8 = u8 + math.min(p9, 0.03333333333333333);
        u5:step(u8);
    end);

    repeat
        apply(u5);
        task.wait(0.1);
    until LocalPlayer:GetAttribute("Teleporting") ~= true and LocalPlayer:GetAttribute("MatchFound") ~= true;

    u5:fade_content(false, TRANSITION.content_out);
    TweenService:Create(Backdrop, TRANSITION.hold_out, {
        BackgroundTransparency = 1
    }):Play();
    TweenService:Create(Glow, TRANSITION.hold_out, {
        GroupTransparency = 1
    }):Play();
    task.wait(0.6);
    v10:Disconnect();
    v7:Disconnect();
    u5:destroy();

    for i, v in v6 do
        StarterGui:SetCoreGuiEnabled(i, v);
    end;
end;