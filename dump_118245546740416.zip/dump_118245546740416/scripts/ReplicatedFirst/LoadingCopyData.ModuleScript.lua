-- ReplicatedFirst.LoadingCopyData
-- class: ModuleScript
-- hash: de3f79a100559eafc4ff8224ddfb328dd2d60af82d56fc1db9982b1932e17115deb82007773a1931d6158fed3f864d92

-- Decompiled with Potassium's decompiler.

local function ContextCopy(p1: table) -- Line: 21
    return p1;
end;

return {
    MAX_LINE_CHARS = 64,
    contexts = {
        boot = {
            label = "Loading…"
        },
        duel = {
            label = "Match found — joining…"
        },
        duel_cancelled = {
            label = "Duel cancelled — Not enough players connected",
            reason_label = "Duel cancelled — %s"
        },
        lobby = {
            label = "Returning to lobby…",
            reason_label = "%s — returning to lobby…"
        },
        party = {
            label = "Waiting for your party…"
        },
        ranked = {
            label = "Joining Ranked…"
        },
        standard = {
            label = "Joining server…"
        },
        server = {
            label = "Finding a new server…"
        }
    }
};