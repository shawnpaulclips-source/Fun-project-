-- ReplicatedFirst.loading_screen
-- class: ModuleScript
-- hash: e30b0b1ca914d7ca2389386b8b1449bc1d3304ab0c30b66d8709371b9fdd17ab88214c6f04d9dc6fa035684315e00f83

-- Decompiled with Potassium's decompiler.

local TeleportService = game:GetService("TeleportService");
local TweenService = game:GetService("TweenService");
local LoadingCopyData = require(script.Parent:WaitForChild("LoadingCopyData"));
local Font_new_ret = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);
local TweenInfo_new_ret = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local TweenInfo_new_ret2 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In);
local UDim2_new_ret = UDim2.new(0.5, 0, 1, 28);
local UDim2_new_ret2 = UDim2.new(0.5, 0, 1, 38);
local UDim2_new_ret3 = UDim2.new(0.5, 0, 1, 22);
local Color3_fromRGB_ret2 = Color3.fromRGB(0, 0, 0);
local ColorSequence_new_ret = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(16, 21, 28)),
    ColorSequenceKeypoint.new(0.4, Color3.fromRGB(42, 50, 61)),
    ColorSequenceKeypoint.new(0.75, Color3.fromRGB(124, 22, 34)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(158, 28, 42))
});
local Vector2_new_ret = Vector2.new(0.08, 0.06);
local Vector2_new_ret2 = Vector2.new(0.21, 0.17);
local u1 = {
    {
        name = "Layer1",
        image = "rbxassetid://131890995350909",
        transparency = 0.45,
        tile = 0.9,
        speed = 0.046,
        angle = 145,
        z = -3,
        color = Color3.fromRGB(76, 26, 37)
    },
    {
        name = "Layer2",
        image = "rbxassetid://73491225399389",
        transparency = 0.22,
        tile = 1.8,
        speed = 0.02,
        angle = 260,
        z = -2,
        color = Color3.fromRGB(0, 0, 0)
    },
    {
        name = "Layer3",
        image = "rbxassetid://131890995350909",
        transparency = 0.9,
        tile = 1.25,
        speed = 0.032,
        angle = 20,
        z = -1,
        color = Color3.fromRGB(255, 255, 255)
    }
};
local Vector2_new_ret3 = Vector2.new(1920, 1080);
local u2 = {
    TRANSITION = {
        backdrop_in = TweenInfo.new(0.3, Enum.EasingStyle.Quart, Enum.EasingDirection.Out),
        mist_in = TweenInfo.new(1.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out),
        blur_in = TweenInfo.new(0.9, Enum.EasingStyle.Quart, Enum.EasingDirection.Out),
        content_in = TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out, 0, false, 0.15),
        content_out = TweenInfo.new(0.35, Enum.EasingStyle.Quart, Enum.EasingDirection.Out),
        scene_out = TweenInfo.new(1, Enum.EasingStyle.Quart, Enum.EasingDirection.Out, 0, false, 0.15),
        hold_out = TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out, 0, false, 0.1)
    }
};
local u3 = nil;
local u4 = nil;
local u5 = nil;

local function make(p6: string, p7: string, p8: userdata?, p9: table) -- Line: 153
    local Instance_new_ret = Instance.new(p6);
    Instance_new_ret.Name = p7;

    for i, v in p9 do
        Instance_new_ret[i] = v;
    end;

    Instance_new_ret.Parent = p8;

    return Instance_new_ret;
end;

local function pose_field(p10: userdata, p11: number) -- Line: 169
    -- upvalues: Vector2_new_ret (copy), Vector2_new_ret2 (copy)
    p10.Rotation = (p11 * 6 + 35) % 360;
    p10.Offset = Vector2.new(Vector2_new_ret.X * math.sin(p11 * Vector2_new_ret2.X), Vector2_new_ret.Y * math.cos(p11 * Vector2_new_ret2.Y));
end;

local function build() -- Line: 177
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), ColorSequence_new_ret (copy), Vector2_new_ret (copy), Vector2_new_ret2 (copy), u1 (copy), Vector2_new_ret3 (copy), Font_new_ret (copy), UDim2_new_ret (copy)
    local v12 = {
        DisplayOrder = 2900,
        IgnoreGuiInset = true,
        ResetOnSpawn = false,
        ScreenInsets = Enum.ScreenInsets.None,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    };
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "LoadingScreen";

    for i, v in v12 do
        ScreenGui[i] = v;
    end;

    ScreenGui.Parent = nil;
    local v13 = {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        BackgroundColor3 = Color3_fromRGB_ret2,
        Position = UDim2.fromOffset(0, 0),
        Size = UDim2.fromOffset(10000, 10000)
    };
    local Frame = Instance.new("Frame");
    Frame.Name = "Backdrop";

    for i, v in v13 do
        Frame[i] = v;
    end;

    Frame.Parent = ScreenGui;
    local v14 = {
        BackgroundTransparency = 1,
        Position = UDim2.fromOffset(0, 0),
        Size = UDim2.fromOffset(1920, 1080)
    };
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Root";

    for i, v in v14 do
        Frame2[i] = v;
    end;

    Frame2.Parent = ScreenGui;
    local v15 = {
        BackgroundTransparency = 1,
        GroupTransparency = 0,
        ZIndex = -3,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromScale(1, 1)
    };
    local CanvasGroup = Instance.new("CanvasGroup");
    CanvasGroup.Name = "Glow";

    for i, v in v15 do
        CanvasGroup[i] = v;
    end;

    CanvasGroup.Parent = Frame2;
    local v16 = {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        ZIndex = -4,
        AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = Color3_fromRGB_ret,
        Position = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(1, 1)
    };
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Field";

    for i, v in v16 do
        Frame3[i] = v;
    end;

    Frame3.Parent = CanvasGroup;
    local v17 = {
        Color = ColorSequence_new_ret
    };
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Name = "Gradient";

    for i, v in v17 do
        UIGradient[i] = v;
    end;

    UIGradient.Parent = Frame3;
    UIGradient.Rotation = 35;
    UIGradient.Offset = Vector2.new(Vector2_new_ret.X * math.sin(0 * Vector2_new_ret2.X), Vector2_new_ret.Y * math.cos(0 * Vector2_new_ret2.Y));
    local v18 = {};

    for i, v in u1 do
        local v19 = v.tile * Vector2_new_ret3.X;
        local name = v.name;
        local v20 = {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, 0),
            Image = v.image,
            ImageColor3 = v.color,
            ImageTransparency = v.transparency,
            Position = UDim2.fromOffset(0, 0),
            ScaleType = Enum.ScaleType.Tile,
            Size = UDim2.new(1, v19, 1, v19),
            TileSize = UDim2.fromOffset(v19, v19),
            ZIndex = v.z
        };
        local ImageLabel = Instance.new("ImageLabel");
        ImageLabel.Name = name;

        for i2, v2 in v20 do
            ImageLabel[i2] = v2;
        end;

        ImageLabel.Parent = CanvasGroup;
        v18[i] = ImageLabel;
    end;

    local v21 = {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromOffset(1100, 80)
    };
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Center";

    for i, v in v21 do
        Frame4[i] = v;
    end;

    Frame4.Parent = Frame2;
    local UIScale = Instance.new("UIScale");
    UIScale.Name = "Scale";

    for i, v in {} do
        UIScale[i] = v;
    end;

    UIScale.Parent = Frame4;
    local v22 = {};

    for i = 1, 3 do
        local v23 = {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.new(0.5, (i - 2) * 112, 0.5, 0),
            Size = UDim2.fromOffset(80, 80)
        };
        local Frame5 = Instance.new("Frame");
        Frame5.Name = "Dot" .. i;

        for i2, v in v23 do
            Frame5[i2] = v;
        end;

        Frame5.Parent = Frame4;
        local v24 = {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3_fromRGB_ret,
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(1, 1)
        };
        local Frame6 = Instance.new("Frame");
        Frame6.Name = "Circle";

        for i2, v in v24 do
            Frame6[i2] = v;
        end;

        Frame6.Parent = Frame5;
        local v25 = {
            CornerRadius = UDim.new(1, 0)
        };
        local UICorner = Instance.new("UICorner");
        UICorner.Name = "UICorner";

        for i2, v in v25 do
            UICorner[i2] = v;
        end;

        UICorner.Parent = Frame6;
        v22[i] = Frame6;
    end;

    local v26 = {
        BackgroundTransparency = 1,
        Text = "",
        TextSize = 28,
        TextTransparency = 1,
        TextWrapped = true,
        AnchorPoint = Vector2.new(0.5, 0),
        FontFace = Font_new_ret,
        Position = UDim2_new_ret,
        Size = UDim2.new(1, 0, 0, 72),
        TextColor3 = Color3_fromRGB_ret,
        TextYAlignment = Enum.TextYAlignment.Top
    };
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Label";

    for i, v in v26 do
        TextLabel[i] = v;
    end;

    TextLabel.Parent = Frame4;

    return ScreenGui, {
        root = Frame2,
        layers = v18,
        field_gradient = UIGradient,
        center_scale = UIScale,
        circles = v22,
        label = TextLabel
    };
end;

local function find(p27: userdata?, p28: string, p29: string) -- Line: 291
    if p27 == nil then
        return nil;
    end;

    local v30 = p27:FindFirstChild(p28);

    if v30 and v30:IsA(p29) then
        return v30;
    end;

    return nil;
end;

local function collect(p31: userdata) -- Line: 305
    -- upvalues: u1 (copy)
    if p31.Name ~= "LoadingScreen" or not p31:IsA("ScreenGui") then
        return nil;
    end;

    local u32 = false;

    local function need(p33: userdata?, p34: string, p35: string) -- Line: 310
        -- upvalues: u32 (ref)
        local v36;

        if p33 == nil then
            v36 = nil;
        else
            v36 = p33:FindFirstChild(p34);

            if not (v36 and v36:IsA(p35)) then
                v36 = nil;
            end;
        end;

        if v36 == nil then
            u32 = true;
        end;

        return v36;
    end;

    local v37;

    if p31 == nil then
        v37 = nil;
    else
        v37 = p31:FindFirstChild("Backdrop");

        if not (v37 and v37:IsA("Frame")) then
            v37 = nil;
        end;
    end;

    local v38;

    if p31 == nil then
        v38 = nil;
    else
        v38 = p31:FindFirstChild("Root");

        if not (v38 and v38:IsA("Frame")) then
            v38 = nil;
        end;
    end;

    local v39;

    if v38 == nil then
        v39 = nil;
    else
        v39 = v38:FindFirstChild("Glow");

        if not (v39 and v39:IsA("CanvasGroup")) then
            v39 = nil;
        end;
    end;

    local v40;

    if v39 == nil then
        v40 = nil;
    else
        v40 = v39:FindFirstChild("Field");

        if not (v40 and v40:IsA("Frame")) then
            v40 = nil;
        end;
    end;

    local v41;

    if v40 == nil then
        v41 = nil;
    else
        v41 = v40:FindFirstChild("Gradient");

        if not (v41 and v41:IsA("UIGradient")) then
            v41 = nil;
        end;
    end;

    local v42;

    if v38 == nil then
        v42 = nil;
    else
        v42 = v38:FindFirstChild("Center");

        if not (v42 and v42:IsA("Frame")) then
            v42 = nil;
        end;
    end;

    local v43 = v42 == nil and true or (v41 == nil and true or (v40 == nil and true or (v39 == nil and true or (v38 == nil and true or (v37 == nil and true or u32)))));
    local v44 = {};

    for i, v in u1 do
        local name = v.name;
        local v45;

        if v39 == nil then
            v45 = nil;
        else
            v45 = v39:FindFirstChild(name);

            if not (v45 and v45:IsA("ImageLabel")) then
                v45 = nil;
            end;
        end;

        v43 = v45 == nil and true or v43;
        v44[i] = v45;
    end;

    local v46 = {};

    for i = 1, 3 do
        local v47 = "Dot" .. i;
        local v48;

        if v42 == nil then
            v48 = nil;
        else
            v48 = v42:FindFirstChild(v47);

            if not (v48 and v48:IsA("Frame")) then
                v48 = nil;
            end;
        end;

        local v49;

        if v48 == nil then
            v49 = nil;
        else
            v49 = v48:FindFirstChild("Circle");

            if not (v49 and v49:IsA("Frame")) then
                v49 = nil;
            end;
        end;

        v43 = v49 == nil and true or (v48 == nil and true or v43);
        v46[i] = v49;
        local _ = i;
    end;

    local v50 = {
        root = v38,
        layers = v44,
        field_gradient = v41
    };
    local v51;

    if v42 == nil then
        v51 = nil;
    else
        v51 = v42:FindFirstChild("Scale");

        if not (v51 and v51:IsA("UIScale")) then
            v51 = nil;
        end;
    end;

    v50.center_scale = v51;
    v50.circles = v46;
    local v52;

    if v42 == nil then
        v52 = nil;
    else
        v52 = v42:FindFirstChild("Label");

        if not (v52 and v52:IsA("TextLabel")) then
            v52 = nil;
        end;
    end;

    u32 = v52 == nil and true or (v51 == nil and true or v43);
    v50.label = v52;

    if u32 then
        return nil;
    end;

    return v50;
end;

local function truncate(p53: string) -- Line: 345
    -- upvalues: LoadingCopyData (copy)
    if utf8.len(p53) == nil then
        return nil;
    end;

    local utf8_offset_ret = utf8.offset(p53, LoadingCopyData.MAX_LINE_CHARS + 1);

    if utf8_offset_ret then
        return string.sub(p53, 1, utf8_offset_ret - 1);
    end;

    return p53;
end;

local function context_label(p54: string?, p55: string?) -- Line: 356
    -- upvalues: LoadingCopyData (copy)
    local v56;

    if p54 then
        v56 = LoadingCopyData.contexts[p54];
    else
        v56 = nil;
    end;

    if v56 == nil then
        return "";
    end;

    if p55 and v56.reason_label then
        return string.format(v56.reason_label, p55);
    end;

    return v56.label;
end;

local function try_set_teleport_gui(u57: userdata) -- Line: 367
    -- upvalues: TeleportService (copy)
    pcall(function() -- Line: 368
        -- upvalues: TeleportService (ref), u57 (copy)
        TeleportService:SetTeleportGui(u57);
    end);
end;

local function wrap(u58: userdata, u59: table) -- Line: 373
    -- upvalues: u3 (ref), TeleportService (copy), TweenService (copy), TweenInfo_new_ret (copy), UDim2_new_ret (copy), LoadingCopyData (copy), UDim2_new_ret2 (copy), TweenInfo_new_ret2 (copy), UDim2_new_ret3 (copy), u2 (copy), u1 (copy), Vector2_new_ret (copy), Vector2_new_ret2 (copy), u5 (ref)
    local Attribute = u58:GetAttribute("Context");
    local Attribute2 = u58:GetAttribute("Line");
    local Attribute3 = u58:GetAttribute("GlowElapsed");

    if type(Attribute) ~= "string" then
        Attribute = nil;
    end;

    if type(Attribute2) ~= "string" then
        Attribute2 = nil;
    end;

    local u60 = type(Attribute3) ~= "number" and 0 or Attribute3;
    local Text = u59.label.Text;
    local u61 = {};
    local u62 = false;
    local u63 = 0;

    for i, v in u59.layers do
        u61[i] = v.TileSize.X.Offset;
    end;

    local u64 = nil;

    local function on_landed(u65: number, u66: function) -- Line: 394
        -- upvalues: u62 (ref), u63 (ref)
        return function(p67) -- Line: 395
            -- upvalues: u62 (ref), u65 (copy), u63 (ref), u66 (copy)
            if u62 or (u65 ~= u63 or p67 ~= Enum.PlaybackState.Completed) then
                return;
            end;

            u66();
        end;
    end;

    local function reregister() -- Line: 404
        -- upvalues: u3 (ref), u64 (ref), u58 (copy), TeleportService (ref)
        if u3 == u64 then
            local u68 = u58;
            pcall(function() -- Line: 368
                -- upvalues: TeleportService (ref), u68 (copy)
                TeleportService:SetTeleportGui(u68);
            end);
        end;
    end;

    local function tween_in(u69: number) -- Line: 410
        -- upvalues: TweenService (ref), u59 (copy), TweenInfo_new_ret (ref), UDim2_new_ret (ref), reregister (copy), u62 (ref), u63 (ref)
        local u70 = reregister;
        TweenService:Create(u59.label, TweenInfo_new_ret, {
            TextTransparency = 0,
            Position = UDim2_new_ret
        }).Completed:Once(function(p71) -- Line: 395
            -- upvalues: u62 (ref), u69 (copy), u63 (ref), u70 (copy)
            if u62 or (u69 ~= u63 or p71 ~= Enum.PlaybackState.Completed) then
                return;
            end;

            u70();
        end);
    end;

    local function render() -- Line: 419
        -- upvalues: Attribute (ref), Attribute2 (ref), LoadingCopyData (ref), Text (ref), u63 (ref), u59 (copy), UDim2_new_ret2 (ref), tween_in (copy), TweenService (ref), TweenInfo_new_ret2 (ref), UDim2_new_ret3 (ref), u3 (ref), u64 (ref), u58 (copy), TeleportService (ref), u62 (ref)
        local v72 = Attribute;
        local v73 = Attribute2;
        local v74;

        if v72 then
            v74 = LoadingCopyData.contexts[v72];
        else
            v74 = nil;
        end;

        local u75;

        if v74 == nil then
            u75 = "";
        elseif v73 and v74.reason_label then
            u75 = string.format(v74.reason_label, v73);
        else
            u75 = v74.label;
        end;

        if u75 == Text then
            return;
        end;

        Text = u75;
        u63 = u63 + 1;
        local u76 = u63;
        local Text2 = u59.label.Text;

        if Text2 ~= "" then
            if Text2 == u75 then
                tween_in(u76);

                return;
            end;

            local function u78() -- Line: 440
                -- upvalues: u59 (ref), u75 (copy), u3 (ref), u64 (ref), u58 (ref), TeleportService (ref), UDim2_new_ret2 (ref), tween_in (ref), u76 (copy)
                u59.label.Text = u75;

                if u75 == "" then
                    if u3 == u64 then
                        local u77 = u58;
                        pcall(function() -- Line: 368
                            -- upvalues: TeleportService (ref), u77 (copy)
                            TeleportService:SetTeleportGui(u77);
                        end);
                    end;

                    return;
                end;

                u59.label.Position = UDim2_new_ret2;
                tween_in(u76);
            end;

            TweenService:Create(u59.label, TweenInfo_new_ret2, {
                TextTransparency = 1,
                Position = UDim2_new_ret3
            }).Completed:Once(function(p79) -- Line: 395
                -- upvalues: u62 (ref), u76 (copy), u63 (ref), u78 (copy)
                if u62 or (u76 ~= u63 or p79 ~= Enum.PlaybackState.Completed) then
                    return;
                end;

                u78();
            end);

            return;
        end;

        u59.label.Text = u75;
        u59.label.TextTransparency = 1;
        u59.label.Position = UDim2_new_ret2;
        tween_in(u76);
    end;

    u64 = {
        gui = u58,

        set_context = function(p80: table, p81: string?, p82: string?) -- Line: 454, Name: set_context
            -- upvalues: u62 (ref), LoadingCopyData (ref), Attribute (ref), Attribute2 (ref), u58 (copy), render (copy)
            if u62 then
                return;
            end;

            if p81 ~= nil and LoadingCopyData.contexts[p81] == nil then
                return;
            end;

            if p82 and utf8.len(p82) ~= nil then
                local utf8_offset_ret = utf8.offset(p82, LoadingCopyData.MAX_LINE_CHARS + 1);

                if utf8_offset_ret then
                    p82 = string.sub(p82, 1, utf8_offset_ret - 1);
                end;
            else
                p82 = nil;
            end;

            if p81 == Attribute and p82 == Attribute2 then
                return;
            end;

            Attribute = p81;
            Attribute2 = p82;
            u58:SetAttribute("Context", p81);
            u58:SetAttribute("Line", p82);
            render();
        end,

        get_context = function(p83: table) -- Line: 471, Name: get_context
            -- upvalues: Attribute (ref)
            return Attribute;
        end,

        get_line = function(p84: table) -- Line: 474, Name: get_line
            -- upvalues: Attribute2 (ref)
            return Attribute2;
        end,

        layout = function(p85: table, p86) -- Line: 477, Name: layout
            -- upvalues: u62 (ref), u59 (copy), u2 (ref), u1 (ref), u61 (copy)
            if u62 then
                return;
            end;

            u59.root.Size = UDim2.fromOffset(p86.X, p86.Y);
            u59.center_scale.Scale = u2.scale_for(p86);

            for i, v in u59.layers do
                local v87 = u1[i].tile * p86.X;

                if v87 ~= u61[i] then
                    u61[i] = v87;
                    v.TileSize = UDim2.fromOffset(v87, v87);
                    v.Size = UDim2.new(1, v87, 1, v87);
                end;
            end;
        end,

        step = function(p88: table, p89: number) -- Line: 492, Name: step
            -- upvalues: u62 (ref), u60 (copy), u58 (copy), u59 (copy), Vector2_new_ret (ref), Vector2_new_ret2 (ref), u1 (ref), u61 (copy)
            if u62 then
                return;
            end;

            local v90 = u60 + p89;
            u58:SetAttribute("GlowElapsed", v90);
            local field_gradient = u59.field_gradient;
            field_gradient.Rotation = (v90 * 6 + 35) % 360;
            field_gradient.Offset = Vector2.new(Vector2_new_ret.X * math.sin(v90 * Vector2_new_ret2.X), Vector2_new_ret.Y * math.cos(v90 * Vector2_new_ret2.Y));

            for i, v in u59.layers do
                local v91 = u1[i];
                local v92 = v91.speed * v90;
                local math_rad_ret = math.rad(v91.angle);
                local v93 = math.cos(math_rad_ret) * v92 % 1;
                local v94 = math.sin(math_rad_ret) * v92 % 1;
                local v95 = u61[i];
                v.Position = UDim2.fromOffset(-v93 * v95, -v94 * v95);
            end;

            for i, v in u59.circles do
                local math_sin_ret = math.sin(v90 * -3.3 + i / 3 * 2 * 3.141592653589793 * 0.24);
                local math_abs_ret = math.abs(math_sin_ret);
                local math_max_ret = math.max(0.42, math_abs_ret);
                v.Size = UDim2.fromScale(math_max_ret, math_max_ret);
            end;
        end,

        fade_content = function(p96: table, p97: boolean, p98: userdata?) -- Line: 516, Name: fade_content
            -- upvalues: u62 (ref), u63 (ref), Text (ref), u59 (copy), TweenService (ref), UDim2_new_ret (ref)
            if u62 then
                return;
            end;

            if not p97 then
                u63 = u63 + 1;
            end;

            local v99 = p97 and Text ~= "" and 0 or 1;
            local v100 = p97 and 0 or 1;

            for _, v in u59.circles do
                if p98 then
                    TweenService:Create(v, p98, {
                        BackgroundTransparency = v100
                    }):Play();
                else
                    v.BackgroundTransparency = v100;
                end;
            end;

            if p98 then
                TweenService:Create(u59.label, p98, {
                    Position = UDim2_new_ret,
                    TextTransparency = v99
                }):Play();

                return;
            end;

            u59.label.Position = UDim2_new_ret;
            u59.label.TextTransparency = v99;
        end,

        register = function(p101: table) -- Line: 545, Name: register
            -- upvalues: u62 (ref), u3 (ref), u64 (ref), u58 (copy), TeleportService (ref)
            if u62 then
                return;
            end;

            u3 = u64;
            local u102 = u58;
            pcall(function() -- Line: 368
                -- upvalues: TeleportService (ref), u102 (copy)
                TeleportService:SetTeleportGui(u102);
            end);
        end,

        destroy = function(p103: table) -- Line: 552, Name: destroy
            -- upvalues: u62 (ref), u3 (ref), u64 (ref), u5 (ref), u58 (copy)
            if u62 then
                return;
            end;

            u62 = true;

            if u3 == u64 then
                u3 = nil;
                u5();
            end;

            u58:Destroy();
        end
    };

    return u64;
end;

function u2.create() -- Line: 568
    -- upvalues: build (copy), wrap (copy)
    local v104, v105 = build();

    return wrap(v104, v105);
end;

function u2.adopt(p106: userdata) -- Line: 575
    -- upvalues: collect (copy), wrap (copy)
    local v107 = collect(p106);

    if v107 == nil then
        return nil;
    end;

    return wrap(p106, v107);
end;

function u2.scale_for(p108) -- Line: 585
    local math_log_ret = math.log(p108.X / 1920, 2);
    local v109 = 2 ^ (math_log_ret + (math.log(p108.Y / 1080, 2) - math_log_ret) * 0.5) * 0.7 + 0.3;

    return math.max(v109, 0.5);
end;

function u2.viewport_of(p110: userdata) -- Line: 594
    -- upvalues: Vector2_new_ret3 (copy)
    local AbsoluteSize = p110.AbsoluteSize;

    if AbsoluteSize.X > 0 and AbsoluteSize.Y > 0 then
        return AbsoluteSize;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;

    if workspace_CurrentCamera and (workspace_CurrentCamera.ViewportSize.X > 0 and workspace_CurrentCamera.ViewportSize.Y > 0) then
        return workspace_CurrentCamera.ViewportSize;
    end;

    return Vector2_new_ret3;
end;

u5 = function() -- Line: 607, Name: register_standby
    -- upvalues: u4 (ref), u2 (copy)
    if u4 == nil then
        u4 = u2.create();
    end;

    u4:register();
end;

return u2;